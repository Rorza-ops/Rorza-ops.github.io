// /* Standard includes. */
// #include "driverlib/pin_map.h"
// #include <stdio.h>
// #include <stdint.h>
// #include <stdbool.h>

// /* Kernel includes. */
// #include "FreeRTOS.h"
// #include "task.h"

// /* Hardware includes. */
// #include "inc/hw_ints.h"
// #include "inc/hw_memmap.h"
// #include "inc/hw_gpio.h"
// #include "inc/hw_types.h"
// #include "driverlib/sysctl.h"
// #include "drivers/rtos_hw_drivers.h"
// #include "utils/uartstdio.h"
// #include "driverlib/gpio.h"
// #include "driverlib/pwm.h"

// #include "motorlib.h"

// /*-----------------------------------------------------------*/

// /* Definitions */
// #define EDGES_PER_REV 24 // Number of edges per revolution
// #define MS_PER_MIN 6000  // No. of milliseconds per minute
// #define TIMER_PERIOD_MS 100 // Timer period in milliseconds
// #define TIMER_PERIOD (g_ui32SysClock / 1000 * TIMER_PERIOD_MS) // Timer period in clock ticks

// #define BUFFER_SIZE 10 // Size of the buffer for speed and acceleration calculations

// /* Global variables */
// // This variable is used to count the number of edges detected by the hall effect sensors
// static volatile uint32_t g_edgeCount = 0;
// // static volatile uint16_t hall_int_count = 0;
// // This variable is used to store the last state of the hall effect sensors
// volatile uint8_t  g_hallLast  = 0; 
// volatile uint8_t ha = 0;
// volatile uint8_t hb = 0;    
// volatile uint8_t hc = 0;

// /* This variable is used to define the current duty cycle of the motor */
// uint16_t start_duty = 10;
// /* This variable is used to define the starting duty cycle of the motor */
// uint16_t start_duty_period = 50;
// /* This variable is used to store the current duty cycle of the motor */
// volatile uint16_t current_duty = 0;

// /* Buffers for average speed and acceleration calculations */
// uint16_t hall_buffer[BUFFER_SIZE] = {0};
// uint16_t vel_buffer[BUFFER_SIZE] = {0};
// uint16_t acc_buffer[BUFFER_SIZE] = {0};

// /* This variable is used to store the current acceleration of the motor */
// volatile int16_t current_acceleration = 0;

// static uint32_t sumEdges            = 0;    /* running sum */
// static uint8_t  idxEdges            = 0;

// static uint16_t rpmPrev             = 0;

// /*-----------------------------------------------------------*/

// void HallSensorHandler(void)
// {
//     //3. Clear interrupt
//     GPIOIntClear(GPIO_PORTM_BASE, GPIO_PIN_3);
//     GPIOIntClear(GPIO_PORTH_BASE, GPIO_PIN_2);
//     GPIOIntClear(GPIO_PORTN_BASE, GPIO_PIN_2);

//     //1. Read hall effect sensors
//     ha = (GPIOPinRead(GPIO_PORTM_BASE, GPIO_PIN_3) >> 3 & 1);
//     hb = (GPIOPinRead(GPIO_PORTH_BASE, GPIO_PIN_2) >> 2 & 1);
//     hc = (GPIOPinRead(GPIO_PORTN_BASE, GPIO_PIN_2) >> 2 & 1);

//     uint8_t pattern = (ha | (hb << 1) | (hc << 2)); 

//     // Check if the hall effect sensor state is valid
//     if (pattern == 7)
//     {
//         // Invalid state, return
//         return;
//     }

//     g_edgeCount++;
//     // hall_int_count++;

//     // Print the hall effect sensor values
//     // UARTprintf("Hall effect sensor values: %u %u %u\r\n", ha, hb, hc);

//     //2. call update motor to change to next phase
//     updateMotor(ha, hb, hc);

// }

// void startMotor(void)
// {
//     uint16_t success = 0;
//     success = initMotorLib(start_duty_period);
//     if (success == 0)
//     {
//         UARTprintf("Motor init failed\n");
//     }
//     else
//     {
//         UARTprintf("Motor init success\n");
//     }
//     current_duty = start_duty;
//     setDuty(current_duty); // Set at >10% to get it to start
//     HallSensorHandler();   // Do an initial read of the hall effect sensor GPIO lines to get motor spinning
// }

// /* Buffers for average speed and acceleration calculations */
// static uint16_t hall_buffer[BUFFER_SIZE] = {0};
// static uint16_t vel_buffer[BUFFER_SIZE] = {0};
// static uint16_t acc_buffer[BUFFER_SIZE] = {0};

// /* This variable is used to store the current acceleration of the motor */
// static uint32_t sumEdges            = 0;    /* running sum */
// static uint8_t  idxEdges            = 0;
// static uint16_t rpmPrev             = 0;

// uint16_t getSpeedMotor(uint16_t edges_this_period)
// {
//     sumEdges -= hall_buffer[idxEdges];
//     sumEdges += edges_this_period;
//     hall_buffer[idxEdges] = edges_this_period;
//     idxEdges = (idxEdges + 1) % BUFFER_SIZE;

//     /* ----- moving-average RPM ----- */
//     /* Calculate mean edges over the last second */
//     uint32_t meanEdges = sumEdges / BUFFER_SIZE;

//     /* Convert to RPM:      edges/0.1 s × 600 / edgesPerRev       */
//     uint16_t rpmNow = (uint16_t)( (meanEdges * MS_PER_MIN/TIMER_PERIOD_MS) / EDGES_PER_REV );

//     /* 5.  Simple acceleration estimate (rpm per second)               */
//     int16_t accel = ( (int16_t)rpmNow - (int16_t)rpmPrev ) * (1000 / TIMER_PERIOD_MS);   

//     current_acceleration = accel;   /* global used by updateSpeedMotor */
//     rpmPrev = rpmNow;               /* store for next call             */

//     return rpmPrev;
    
// }
