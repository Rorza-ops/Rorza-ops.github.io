// #ifndef WIDGET_MUTEX_H_
// #define WIDGET_MUTEX_H_

// void WidgetMutexInit(void);
// void WidgetMutexGet(void);
// void WidgetMutexPut(void);

// #endif
