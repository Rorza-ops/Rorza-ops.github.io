#include <stdint.h>
#include <stdbool.h>
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/adc.h"
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "FreeRTOS.h"
#include "task.h"
#include "utils/uartstdio.h"
#include <math.h>
#include "semphr.h"

#define VREF        3.3f
#define ADC_MAX     4095.0f
#define GAIN        10.0f
#define R_SHUNT     0.007f
#define V_NOMINAL   24.0f
#define SAMPLE_PERIOD_MS 6.64
#define WINDOW_SIZE 10

static float isenbBuffer[WINDOW_SIZE] = {0};
static float isencBuffer[WINDOW_SIZE] = {0};
static int isenbIndex = 0;
static int isencIndex = 0;

static float g_fTotalCurrent = 0.0f; // Global total current (Amps) for display_task.c access

extern volatile uint16_t g_maxCurrentThreshold;
extern volatile uint16_t estop_setting;
extern SemaphoreHandle_t xMaxCurrentMutex;
extern SemaphoreHandle_t xEstopSem;

extern void setEstop(uint16_t estop);

static float getSlidingAverage(const float* buffer) {
    float sum = 0;
    for (int i = 0; i < WINDOW_SIZE; ++i) {
        sum += buffer[i];
    }
    return sum / WINDOW_SIZE;
}

void ADC1_Init_AIN5(void) {
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOD); // PD2 = AIN5

    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_ADC1)) {}

    GPIOPinTypeADC(GPIO_PORTD_BASE, GPIO_PIN_2); // PD2 → AIN5

    ADCSequenceDisable(ADC1_BASE, 3);
    ADCSequenceConfigure(ADC1_BASE, 3, ADC_TRIGGER_PROCESSOR, 0);
    ADCSequenceStepConfigure(ADC1_BASE, 3, 0, ADC_CTL_CH5 | ADC_CTL_IE | ADC_CTL_END);
    ADCSequenceEnable(ADC1_BASE, 3);
    ADCIntClear(ADC1_BASE, 3);
}

void ADC1_Init_AIN0(void) {
    SysCtlPeripheralEnable(SYSCTL_PERIPH_ADC1);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOE); // PE3 = AIN0

    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_ADC1)) {}

    GPIOPinTypeADC(GPIO_PORTE_BASE, GPIO_PIN_3); // PE3 → AIN0

    ADCSequenceDisable(ADC1_BASE, 3);
    ADCSequenceConfigure(ADC1_BASE, 3, ADC_TRIGGER_PROCESSOR, 0);
    ADCSequenceStepConfigure(ADC1_BASE, 3, 0, ADC_CTL_CH0 | ADC_CTL_IE | ADC_CTL_END);
    ADCSequenceEnable(ADC1_BASE, 3);
    ADCIntClear(ADC1_BASE, 3);
}

float getTotalCurrent(void) {
    return g_fTotalCurrent;
}

static void prvCurrentSenseTask_AIN5(void *pvParameters) {
    uint32_t adcVal;
    TickType_t xLastWakeTime = xTaskGetTickCount();

    UARTprintf("Reading and filtering AIN5 (PD2)...\n");

    while (1) {
        ADCIntClear(ADC1_BASE, 3);
        ADCProcessorTrigger(ADC1_BASE, 3);

        while (!ADCIntStatus(ADC1_BASE, 3, false)) {}

        ADCSequenceDataGet(ADC1_BASE, 3, &adcVal);
        ADCIntClear(ADC1_BASE, 3);

        float voltage = ((float)adcVal / ADC_MAX) * VREF - (VREF / 2.0f);
        float current = voltage / (GAIN * R_SHUNT);

        isenbBuffer[isenbIndex] = current;
        isenbIndex = (isenbIndex + 1) % WINDOW_SIZE;

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(SAMPLE_PERIOD_MS));
    }
}

static void prvCurrentSenseTask_AIN0(void *pvParameters) {
    uint32_t adcVal;
    TickType_t xLastWakeTime = xTaskGetTickCount();

    UARTprintf("Reading and filtering AIN0 (PE3)...\n");

    while (1) {
        ADCIntClear(ADC1_BASE, 3);
        ADCProcessorTrigger(ADC1_BASE, 3);

        while (!ADCIntStatus(ADC1_BASE, 3, false)) {}

        ADCSequenceDataGet(ADC1_BASE, 3, &adcVal);
        ADCIntClear(ADC1_BASE, 3);

        float voltage = ((float)adcVal / ADC_MAX) * VREF - (VREF / 2.0f);
        float current = voltage / (GAIN * R_SHUNT);

        isencBuffer[isencIndex] = current;
        isencIndex = (isencIndex + 1) % WINDOW_SIZE;

        float avgISENB = getSlidingAverage(isenbBuffer);
        float avgISENC = getSlidingAverage(isencBuffer);

        g_fTotalCurrent = fabsf(avgISENB) + fabsf(avgISENC); // <-- Used by display

        float power = g_fTotalCurrent * V_NOMINAL;

        uint16_t threshold = 800;
        uint16_t totalCurrent_mA = (uint16_t)((uint16_t)(fabsf(g_fTotalCurrent * 1000)) % 1000);

        if (totalCurrent_mA > threshold) {
            if (xSemaphoreTake(xEstopSem, pdMS_TO_TICKS(10)) == pdTRUE) {
                estop_setting = 1;
                xSemaphoreGive(xEstopSem);
            }
        }

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(SAMPLE_PERIOD_MS));
    }
}

void vCreateCurrentSenseTask_AIN5(void) {
    BaseType_t result = xTaskCreate(prvCurrentSenseTask_AIN5, "CurrentSense5", configMINIMAL_STACK_SIZE+125, NULL, tskIDLE_PRIORITY + 1, NULL);
    if (result != pdPASS) {
        UARTprintf("Failed to create AIN5 Task\n");
        while (1);
    }
}

void vCreateCurrentSenseTask_AIN0(void) {
    BaseType_t result = xTaskCreate(prvCurrentSenseTask_AIN0, "CurrentSense0", configMINIMAL_STACK_SIZE+125, NULL, tskIDLE_PRIORITY + 1, NULL);
    if (result != pdPASS) {
        UARTprintf("Failed to create AIN0 Task\n");
        while (1);
    }
}
