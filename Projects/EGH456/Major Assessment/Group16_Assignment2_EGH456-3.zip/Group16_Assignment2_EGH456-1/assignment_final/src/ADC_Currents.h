#ifndef ADC_CURRENTS_H_
#define ADC_CURRENTS_H_

float getTotalCurrent(void);

#endif
