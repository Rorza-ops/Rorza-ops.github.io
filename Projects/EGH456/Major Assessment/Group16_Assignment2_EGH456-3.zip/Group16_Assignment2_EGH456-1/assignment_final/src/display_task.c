/* Standard includes. */
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

/* Hardware includes. */
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "drivers/rtos_hw_drivers.h"
#include "utils/uartstdio.h"
#include "inc/hw_nvic.h"
#include "inc/hw_sysctl.h"
#include "inc/hw_types.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/flash.h"
#include "driverlib/sysctl.h"
#include "driverlib/systick.h"
#include "driverlib/uart.h"
#include "driverlib/udma.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "grlib.h"
#include "widget.h"
#include "canvas.h"
#include "checkbox.h"
#include "container.h"
#include "pushbutton.h"
#include "radiobutton.h"
#include "slider.h"
#include "utils/ustdlib.h"
#include "drivers/Kentec320x240x16_ssd2119_spi.h"
#include "drivers/touch.h"
#include "images.h"
#include "ADC_Currents.h"

/*-----------------------------------------------------------*/

//*****************************************************************************
//
// The error routine that is called if the driver library encounters an error.
//
//*****************************************************************************
#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

//*****************************************************************************
//
// Global variables used to store the frequency of the system clock and other states.
//
//*****************************************************************************
uint32_t g_ui32SysClock;
tContext sContext;

// Motor state
bool g_bMotorOn = false;
int32_t g_i32RPM = 0;
bool g_bEStop = false; // Simulated E-stop condition

// Plot data (simulated)
#define LUX_PLOT_POINTS 100                       // For continuous scrolling plots (10 seconds at 10 Hz)
uint32_t g_pui32SpeedData[LUX_PLOT_POINTS] = {0}; // Motor speed (RPM)
uint32_t g_pui32PowerData[LUX_PLOT_POINTS] = {0}; // Power usage (Watts)
uint32_t g_pui32LuxData[LUX_PLOT_POINTS] = {0};   // Light levels (lux), updated from sensor
uint32_t g_pui32AccelData[LUX_PLOT_POINTS] = {0}; // Acceleration (m/s^2)
uint32_t g_ui32LuxPlotDataIndex = 0;              // Index for updating lux plot data
uint32_t g_ui32SpeedPlotDataIndex = 0;            // Index for updating speed plot data
uint32_t g_ui32PowerPlotDataIndex = 0;            // Index for updating power plot data
uint32_t g_ui32AccelPlotDataIndex = 0;            // Index for updating accel plot data

// Thresholds
int32_t g_i32MaxCurrentThreshold = 50; // Simulated max current threshold (A)
int32_t g_i32MaxAccelThreshold = 10;   // Simulated max acceleration threshold (m/s^2)

// Simulated day/night
bool g_bIsNight = false; // Simulated night condition (< 5 lux)

// Flag to indicate if a panel switch is in progress
bool g_bSwitchingPanel = false;
#define V_NOMINAL 24.0f

// Plot visibility flags
bool g_bPlotSpeedVisible = true;
bool g_bPlotPowerVisible = true;
bool g_bPlotLuxVisible = true;
bool g_bPlotAccelVisible = true;

// Semaphore for RPM updates
SemaphoreHandle_t xCurrentRpmSemaphore;
uint16_t new_current_rpm = 0;

// Buffer for slider text
static char g_pcSliderText[20];

// Buffer for system status text
static char g_pcSystemModeText[20];

// Buffer for day/night text
static char g_pcDayNightText[20];

// Buffer for warning text
static char g_pcWarningText[40];

// Buffer for acceleration text
static char g_pcAccelText[20];

// Structure to receive sensor data (same as in Light_task.c)
typedef struct
{
    float rawLux;
    float filtLux;
    uint32_t ts;
} SensorMessage;

// Declare the queue from Light_task.c as extern
extern QueueHandle_t xSensorQ;

// Last time the plots were updated (for controlling the 10 Hz update rate)
TickType_t g_xLastLuxUpdateTime = 0;
TickType_t g_xLastSpeedUpdateTime = 0;
TickType_t g_xLastPowerUpdateTime = 0;
TickType_t g_xLastAccelUpdateTime = 0;

// Clock state variables (start at 9:30am on Thursday, May 29, 2025)
static int32_t g_i32Hours = 9;                // Starting hour (9 am)
static int32_t g_i32Minutes = 30;             // Starting minutes
static int32_t g_i32Seconds = 0;              // Starting seconds
static bool g_bIsAM = true;                   // AM/PM indicator
static int32_t g_i32DayOfWeek = 4;            // Wednesday (0=Sun, 1=Mon, ..., 3=Wed)
static int32_t g_i32Day = 29;                 // Day of month
static int32_t g_i32Month = 5;                // May (1=Jan, ..., 5=May)
static int32_t g_i32Year = 2025;              // Year
static TickType_t g_xLastClockUpdateTime = 0; // Last time the clock was updated

// Days of the week for display
static const char *g_pcDaysOfWeek[] = {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"};

// Months for determining days in month
static const int32_t g_i32DaysInMonth[] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};

// Buffers for clock text
static char g_pcClockDateText[20];
static char g_pcClockTimeText[20];

//*****************************************************************************
//
// The DMA control structure table.
//
//*****************************************************************************
#ifdef ewarm
#pragma data_alignment = 1024
tDMAControlTable psDMAControlTable[64];
#elif defined(ccs)
#pragma DATA_ALIGN(psDMAControlTable, 1024)
tDMAControlTable psDMAControlTable[64];
#else
tDMAControlTable psDMAControlTable[64] __attribute__((aligned(1024)));
#endif

//*****************************************************************************
//
// Forward declarations for the globals required to define the widgets at
// compile-time.
//
//*****************************************************************************
void OnControls(tWidget *psWidget);
void OnPlots(tWidget *psWidget);
void OnRadioChange(tWidget *psWidget, uint32_t bSelected);
void OnRPMChange(tWidget *psWidget, int32_t i32Value);
void OnMaxCurrentChange(tWidget *psWidget, int32_t i32Value);
void OnMaxAccelChange(tWidget *psWidget, int32_t i32Value);
void OnEStopAcknowledge(tWidget *psWidget);
void OnPlotSpeedToggle(tWidget *psWidget, uint32_t bSelected);
void OnPlotPowerToggle(tWidget *psWidget, uint32_t bSelected);
void OnPlotLuxToggle(tWidget *psWidget, uint32_t bSelected);
void OnPlotAccelToggle(tWidget *psWidget, uint32_t bSelected);
void OnPowerPlotPaint(tWidget *psWidget, tContext *psContext);
void OnSpeedPlotPaint(tWidget *psWidget, tContext *psContext);
void OnLuxPlotPaint(tWidget *psWidget, tContext *psContext);
void OnAccelPlotPaint(tWidget *psWidget, tContext *psContext);
extern void setDesiredRPM(uint16_t rpm);
extern tCanvasWidget g_psPanels[];

static void prvDisplayDemoTask(void *pvParameters);
void vDisplayDemoTask(void);

//*****************************************************************************
//
// The first panel (Controls), with all control elements.
//
//*****************************************************************************
// Real-time clock
Canvas(g_sClockDate, g_psPanels, 0, 0, &g_sKentec320x240x16_SSD2119, 0, 24,
       150, 20, CANVAS_STYLE_FILL | CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Thurs, May 29, 2025", 0, 0);

Canvas(g_sClockTime, g_psPanels, &g_sClockDate, 0, &g_sKentec320x240x16_SSD2119, 0, 44,
       150, 20, CANVAS_STYLE_FILL | CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm14, "9:36:00 AM AEST", 0, 0);

// System mode and status LED
Canvas(g_sSystemMode, g_psPanels, &g_sClockTime, 0, &g_sKentec320x240x16_SSD2119, 0, 64,
       120, 20, CANVAS_STYLE_TEXT, 0, 0, ClrSilver, &g_sFontCm14, "Mode: Stopped", 0, 0);
Canvas(g_sMotorStatusLED, g_psPanels, &g_sSystemMode, 0, &g_sKentec320x240x16_SSD2119, 120, 64,
       20, 20, CANVAS_STYLE_FILL, ClrGray, 0, 0, 0, 0, 0, 0);

// Warning field
Canvas(g_sWarning, g_psPanels, &g_sMotorStatusLED, 0, &g_sKentec320x240x16_SSD2119, 0, 84,
       140, 20, CANVAS_STYLE_TEXT | CANVAS_STYLE_FILL, ClrBlack, 0, ClrRed, &g_sFontCm14, "", 0, 0);

// E-stop acknowledge button
RectangularButton(g_sEStopAcknowledge, g_psPanels, &g_sWarning, 0, &g_sKentec320x240x16_SSD2119, 0, 104,
                  120, 20, PB_STYLE_TEXT | PB_STYLE_FILL, ClrGray, ClrDarkGray, 0,
                  ClrSilver, &g_sFontCm14, "Acknowledge E-Stop", 0, 0, 0, 0, OnEStopAcknowledge);

// Motor controls
Canvas(g_sMotorLabel, g_psPanels, &g_sEStopAcknowledge, 0, &g_sKentec320x240x16_SSD2119, 150, 24,
       160, 20, CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Motor Control", 0, 0);

tRadioButtonWidget g_psMotorRadioButtons[] =
    {
        RadioButtonStruct(g_psPanels, g_psMotorRadioButtons + 1, 0,
                          &g_sKentec320x240x16_SSD2119, 150, 44, 80, 40,
                          RB_STYLE_TEXT, 16, 0, ClrSilver, ClrSilver, &g_sFontCm20,
                          "Off", 0, OnRadioChange),
        RadioButtonStruct(g_psPanels, 0, 0,
                          &g_sKentec320x240x16_SSD2119, 230, 44, 80, 40,
                          RB_STYLE_TEXT, 16, 0, ClrSilver, ClrSilver, &g_sFontCm20,
                          "On", 0, OnRadioChange),
};
#define NUM_RADIO_BUTTONS (sizeof(g_psMotorRadioButtons) / sizeof(g_psMotorRadioButtons[0]))

Canvas(g_sRPMLabel, g_psPanels, g_psMotorRadioButtons, 0, &g_sKentec320x240x16_SSD2119, 150, 84,
       160, 20, CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Motor RPM", 0, 0);

tSliderWidget g_psMotorSlider[] =
    {
        SliderStruct(g_psPanels, &g_sRPMLabel, 0, &g_sKentec320x240x16_SSD2119, 150, 104, 160, 20, 0, 5000, 0, SL_STYLE_FILL | SL_STYLE_BACKG_FILL | SL_STYLE_OUTLINE | SL_STYLE_TEXT | SL_STYLE_BACKG_TEXT, ClrGray, ClrBlack, ClrSilver, ClrWhite, ClrWhite, &g_sFontCm14, "0", 0, 0, OnRPMChange),
};

// Day/Night indicator and auto headlights LED
Canvas(g_sLightDayNight, g_psPanels, g_psMotorSlider, 0, &g_sKentec320x240x16_SSD2119, 150, 124,
       120, 20, CANVAS_STYLE_TEXT | CANVAS_STYLE_FILL, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Day", 0, 0);

Canvas(g_sLightHeadlightsLED, g_psPanels, &g_sLightDayNight, 0, &g_sKentec320x240x16_SSD2119, 270, 124,
       20, 20, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0);

// Current acceleration display
Canvas(g_sCurrentAccel, g_psPanels, &g_sLightHeadlightsLED, 0, &g_sKentec320x240x16_SSD2119, 150, 144,
       140, 20, CANVAS_STYLE_TEXT | CANVAS_STYLE_FILL, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Accel: 0 m/s^2", 0, 0);

// Threshold sliders (max current, max acceleration)
Canvas(g_sMaxCurrentLabel, g_psPanels, &g_sCurrentAccel, 0, &g_sKentec320x240x16_SSD2119, 0, 124,
       140, 20, CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Max Current", 0, 0);

Canvas(g_sMaxAccelLabel, g_psPanels, &g_sMaxCurrentLabel, 0, &g_sKentec320x240x16_SSD2119, 150, 164,
       140, 20, CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm14, "Max Acceleration", 0, 0);

tSliderWidget g_psThresholdSliders[] =
    {
        SliderStruct(g_psPanels, &g_sMaxAccelLabel, 0,
                     &g_sKentec320x240x16_SSD2119, 0, 144, 140, 20,
                     0, 100, 50,
                     SL_STYLE_FILL | SL_STYLE_BACKG_FILL | SL_STYLE_OUTLINE | SL_STYLE_TEXT | SL_STYLE_BACKG_TEXT,
                     ClrGray, ClrBlack, ClrSilver, ClrWhite, ClrWhite,
                     &g_sFontCm14, "Max Current: 50A", 0, 0, OnMaxCurrentChange),
        SliderStruct(g_psPanels, g_psThresholdSliders, 0,
                     &g_sKentec320x240x16_SSD2119, 150, 184, 140, 20,
                     0, 20, 10,
                     SL_STYLE_FILL | SL_STYLE_BACKG_FILL | SL_STYLE_OUTLINE | SL_STYLE_TEXT | SL_STYLE_BACKG_TEXT,
                     ClrGray, ClrBlack, ClrSilver, ClrWhite, ClrWhite,
                     &g_sFontCm14, "Max Accel: 10m/s^2", 0, 0, OnMaxAccelChange),
};

//*****************************************************************************
//
// The second panel (Plots), with all sensor plots and toggle controls.
//
//*****************************************************************************
Canvas(g_sPlotsTitle, g_psPanels + 1, 0, 0, &g_sKentec320x240x16_SSD2119, 0, 24,
       320, 20, CANVAS_STYLE_TEXT, ClrBlack, 0, ClrSilver, &g_sFontCm16, "Sensor Plots", 0, 0);

// Checkboxes to toggle plots on/off
CheckBox(g_sPlotSpeedToggle, g_psPanels + 1, &g_sPlotsTitle, 0, &g_sKentec320x240x16_SSD2119, 0, 44,
         100, 20, CB_STYLE_TEXT, 16, ClrGreen, ClrSilver, ClrSilver, &g_sFontCm14, "Speed (RPM)", 0, OnPlotSpeedToggle);
CheckBox(g_sPlotPowerToggle, g_psPanels + 1, &g_sPlotSpeedToggle, 0, &g_sKentec320x240x16_SSD2119, 0, 64,
         100, 20, CB_STYLE_TEXT, 16, ClrRed, ClrSilver, ClrSilver, &g_sFontCm14, "Power (W)", 0, OnPlotPowerToggle);
CheckBox(g_sPlotLuxToggle, g_psPanels + 1, &g_sPlotPowerToggle, 0, &g_sKentec320x240x16_SSD2119, 0, 84,
         100, 20, CB_STYLE_TEXT, 16, ClrYellow, ClrSilver, ClrSilver, &g_sFontCm14, "Light (lux)", 0, OnPlotLuxToggle);
CheckBox(g_sPlotAccelToggle, g_psPanels + 1, &g_sPlotLuxToggle, 0, &g_sKentec320x240x16_SSD2119, 0, 104,
         100, 20, CB_STYLE_TEXT, 16, ClrBlue, ClrSilver, ClrSilver, &g_sFontCm14, "Accel (m/s^2)", 0, OnPlotAccelToggle);

// Sensor plots (stacked vertically)
Canvas(g_sSpeedPlot, g_psPanels + 1, &g_sPlotAccelToggle, 0,
       &g_sKentec320x240x16_SSD2119, 120, 24, 200, 40,
       CANVAS_STYLE_OUTLINE | CANVAS_STYLE_APP_DRAWN, 0, ClrGray, 0, 0, 0, 0,
       OnSpeedPlotPaint);
Canvas(g_sPowerPlot, g_psPanels + 1, &g_sSpeedPlot, 0,
       &g_sKentec320x240x16_SSD2119, 120, 64, 200, 40,
       CANVAS_STYLE_OUTLINE | CANVAS_STYLE_APP_DRAWN, 0, ClrGray, 0, 0, 0, 0,
       OnPowerPlotPaint);
Canvas(g_sLuxPlot, g_psPanels + 1, &g_sPowerPlot, 0,
       &g_sKentec320x240x16_SSD2119, 120, 104, 200, 40,
       CANVAS_STYLE_OUTLINE | CANVAS_STYLE_APP_DRAWN, 0, ClrGray, 0, 0, 0, 0,
       OnLuxPlotPaint);
Canvas(g_sAccelPlot, g_psPanels + 1, &g_sLuxPlot, 0,
       &g_sKentec320x240x16_SSD2119, 120, 144, 200, 40,
       CANVAS_STYLE_OUTLINE | CANVAS_STYLE_APP_DRAWN, 0, ClrGray, 0, 0, 0, 0,
       OnAccelPlotPaint);

//*****************************************************************************
//
// An array of canvas widgets, one per panel.  Each canvas is filled with
// black, overwriting the contents of the previous panel.
//
//*****************************************************************************
tCanvasWidget g_psPanels[] =
    {
        CanvasStruct(0, 0, g_psThresholdSliders + 1, &g_sKentec320x240x16_SSD2119, 0, 24,
                     320, 166, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0), // Controls
        CanvasStruct(0, 0, &g_sAccelPlot, &g_sKentec320x240x16_SSD2119, 0, 24,
                     320, 166, CANVAS_STYLE_FILL, ClrBlack, 0, 0, 0, 0, 0, 0), // Plots
};

//*****************************************************************************
//
// The number of panels.
//
//*****************************************************************************
#define NUM_PANELS 2

//*****************************************************************************
//
// The names for each of the panels, which are displayed at the bottom of the
// screen.
//
//*****************************************************************************
char *g_pcPanei32Names[] =
    {
        "CONTROLS",
        "PLOTS",
};

//*****************************************************************************
//
// The buttons and text across the bottom of the screen.
//
//*****************************************************************************
Canvas(g_sTitle, 0, 0, 0, &g_sKentec320x240x16_SSD2119, 50, 24, 220, 24,
       CANVAS_STYLE_TEXT | CANVAS_STYLE_TEXT_OPAQUE, 0, 0, ClrSilver,
       &g_sFontCm22b, 0, 0, 0);

RectangularButton(g_sControls, 0, 0, 0, &g_sKentec320x240x16_SSD2119, 0, 210,
                  160, 30, PB_STYLE_IMG | PB_STYLE_TEXT, ClrBlack, ClrBlack, 0,
                  ClrSilver, &g_sFontCm12, "CONTROLS", g_pui8Blue50x50,
                  g_pui8Blue50x50Press, 0, 0, OnControls);

RectangularButton(g_sPlots, 0, 0, 0, &g_sKentec320x240x16_SSD2119, 160, 210,
                  160, 30, PB_STYLE_IMG | PB_STYLE_TEXT, ClrBlack, ClrBlack, 0, ClrSilver,
                  &g_sFontCm12, "PLOTS", g_pui8Blue50x50, g_pui8Blue50x50Press, 0, 0,
                  OnPlots);

//*****************************************************************************
//
// The panel that is currently being displayed.
//
//*****************************************************************************
uint32_t g_ui32Panel;

// Helper function to determine if a year is a leap year
static bool IsLeapYear(int32_t year)
{
    return (year % 4 == 0 && year % 100 != 0) || (year % 400 == 0);
}

// Helper function to get the number of days in the current month
static int32_t GetDaysInMonth(int32_t month, int32_t year)
{
    if (month == 2 && IsLeapYear(year))
    {
        return 29;
    }
    return g_i32DaysInMonth[month - 1];
}

// Function to update the clock state and display
static void UpdateClock(void)
{
    // Increment seconds
    g_i32Seconds++;
    if (g_i32Seconds >= 60)
    {
        g_i32Seconds = 0;
        g_i32Minutes++;
        if (g_i32Minutes >= 60)
        {
            g_i32Minutes = 0;
            g_i32Hours++;
            if (g_i32Hours == 12)
            {
                g_bIsAM = !g_bIsAM;
            }
            else if (g_i32Hours > 12)
            {
                g_i32Hours = 1;
            }
            if (g_i32Hours == 12 && g_i32Minutes == 0 && g_i32Seconds == 0 && g_bIsAM) // Midnight
            {
                // Increment date
                g_i32DayOfWeek = (g_i32DayOfWeek + 1) % 7;
                g_i32Day++;
                int32_t daysInMonth = GetDaysInMonth(g_i32Month, g_i32Year);
                if (g_i32Day > daysInMonth)
                {
                    g_i32Day = 1;
                    g_i32Month++;
                    if (g_i32Month > 12)
                    {
                        g_i32Month = 1;
                        g_i32Year++;
                    }
                }
            }
        }
    }

    // Format the date string (e.g., "Wed, May 28, 2025")
    usprintf(g_pcClockDateText, "%s, May %d, %d", g_pcDaysOfWeek[g_i32DayOfWeek], g_i32Day, g_i32Year);

    // Format the time string (e.g., "11:46:00 PM AEST")
    usprintf(g_pcClockTimeText, "%02d:%02d:%02d %s AEST",
             (g_i32Hours == 12 ? 12 : g_i32Hours % 12), g_i32Minutes, g_i32Seconds, g_bIsAM ? "AM" : "PM");

    // Update the clock widgets
    CanvasTextSet(&g_sClockDate, g_pcClockDateText);
    CanvasTextSet(&g_sClockTime, g_pcClockTimeText);

    // Repaint the clock widgets only if on the Controls panel
    if (g_ui32Panel == 0 && !g_bSwitchingPanel)
    {
        WidgetPaint((tWidget *)&g_sClockDate);
        WidgetPaint((tWidget *)&g_sClockTime);
    }
}

void SwitchToPanel(uint32_t ui32NewPanel)
{
    if (g_ui32Panel == ui32NewPanel)
    {
        return;
    }

    // Indicate that a panel switch is in progress
    g_bSwitchingPanel = true;
    UARTprintf("SwitchToPanel: Starting panel switch to %d\n", ui32NewPanel);

    // Process any pending messages before switching to ensure the current widget tree handles them
    UARTprintf("SwitchToPanel: Processing messages before switch\n");
    WidgetMessageQueueProcess();

    // Remove the current panel
    UARTprintf("SwitchToPanel: Removing panel %d\n", g_ui32Panel);
    WidgetRemove((tWidget *)(g_psPanels + g_ui32Panel));

    // Set the new panel index
    g_ui32Panel = ui32NewPanel;

    // Add and draw the new panel
    UARTprintf("SwitchToPanel: Adding and painting panel %d\n", g_ui32Panel);
    WidgetAdd(WIDGET_ROOT, (tWidget *)(g_psPanels + g_ui32Panel));
    WidgetPaint((tWidget *)(g_psPanels + g_ui32Panel));

    // Reset slider values to their respective global variables
    if (g_ui32Panel == 0) // Controls panel
    {
        // Reset max current slider
        UARTprintf("Switching to Controls panel: Resetting Max Current slider to %d\n", g_i32MaxCurrentThreshold);
        SliderValueSet(&g_psThresholdSliders[0], g_i32MaxCurrentThreshold);
        usprintf(g_pcSliderText, "Max Current: %dA", g_i32MaxCurrentThreshold);
        SliderTextSet(&g_psThresholdSliders[0], g_pcSliderText);
        WidgetPaint((tWidget *)&g_psThresholdSliders[0]);

        // Reset max acceleration slider
        SliderValueSet(&g_psThresholdSliders[1], g_i32MaxAccelThreshold);
        usprintf(g_pcSliderText, "Max Accel: %dm/s^2", g_i32MaxAccelThreshold);
        SliderTextSet(&g_psThresholdSliders[1], g_pcSliderText);
        WidgetPaint((tWidget *)&g_psThresholdSliders[1]);

        // Reset RPM slider
        UARTprintf("Switching to Controls panel: Resetting RPM slider to %d\n", g_i32RPM);
        SliderValueSet(&g_psMotorSlider[0], g_i32RPM);
        usprintf(g_pcSliderText, "%d", g_i32RPM);
        SliderTextSet(&g_psMotorSlider[0], g_pcSliderText);
        WidgetPaint((tWidget *)&g_psMotorSlider[0]);

        // Update system mode text and LED
        usprintf(g_pcSystemModeText, "%s", g_bEStop ? "Mode: E-stop" : (g_bMotorOn ? "Mode: Running" : "Mode: Stopped"));
        UARTprintf("SwitchToPanel: Setting system status to '%s' (g_bMotorOn = %d, g_bEStop = %d)\n",
                   g_pcSystemModeText, g_bMotorOn, g_bEStop);
        CanvasTextSet(&g_sSystemMode, g_pcSystemModeText);
        CanvasFillColorSet(&g_sMotorStatusLED, g_bEStop ? ClrRed : (g_bMotorOn ? ClrGreen : ClrGray));
        WidgetPaint((tWidget *)&g_sSystemMode);
        WidgetPaint((tWidget *)&g_sMotorStatusLED);

        // Update day/night indicator and LED
        usprintf(g_pcDayNightText, "%s", g_bIsNight ? "Night" : "Day");
        CanvasTextSet(&g_sLightDayNight, g_pcDayNightText);
        CanvasFillColorSet(&g_sLightHeadlightsLED, g_bIsNight ? ClrYellow : ClrBlack);
        WidgetPaint((tWidget *)&g_sLightDayNight);
        WidgetPaint((tWidget *)&g_sLightHeadlightsLED);

        // Enable/disable the e-stop acknowledge button based on g_bEStop
        if (g_bEStop)
        {
            PushButtonFillColorSet(&g_sEStopAcknowledge, ClrGray);
            PushButtonFillColorPressedSet(&g_sEStopAcknowledge, ClrDarkGray);
        }
        else
        {
            PushButtonFillColorSet(&g_sEStopAcknowledge, ClrDarkGray);
            PushButtonFillColorPressedSet(&g_sEStopAcknowledge, ClrDarkGray);
        }
        WidgetPaint((tWidget *)&g_sEStopAcknowledge);
    }

    // Clear the title area
    tRectangle titleRect;
    titleRect.i16XMin = 50;
    titleRect.i16YMin = 24;
    titleRect.i16XMax = 50 + 220 - 1;
    titleRect.i16YMax = 24 + 24 - 1;
    GrContextForegroundSet(&sContext, ClrBlack);
    GrRectFill(&sContext, &titleRect);

    // Set the title of this panel
    CanvasTextSet(&g_sTitle, g_pcPanei32Names[g_ui32Panel]);
    WidgetPaint((tWidget *)&g_sTitle);

    // Update button states (set states but do not repaint individually)
    PushButtonFillOn(&g_sControls);
    PushButtonImageOff(&g_sControls);
    PushButtonTextOff(&g_sControls);
    if (g_ui32Panel != 0)
    {
        PushButtonFillOff(&g_sControls);
        PushButtonImageOn(&g_sControls);
        PushButtonTextOn(&g_sControls);
    }

    PushButtonFillOn(&g_sPlots);
    PushButtonImageOff(&g_sPlots);
    PushButtonTextOff(&g_sPlots);
    if (g_ui32Panel != 1)
    {
        PushButtonFillOff(&g_sPlots);
        PushButtonImageOn(&g_sPlots);
        PushButtonTextOn(&g_sPlots);
    }

    // Force an immediate repaint of the entire widget tree to ensure the panel switch is visible
    UARTprintf("SwitchToPanel: Repainting entire widget tree\n");
    WidgetPaint(WIDGET_ROOT);

    // Add a short delay to allow the display to settle before processing new messages
    UARTprintf("SwitchToPanel: Delaying to allow display to settle\n");
    vTaskDelay(pdMS_TO_TICKS(50));

    // Panel switch is complete
    g_bSwitchingPanel = false;
    UARTprintf("SwitchToPanel: Panel switch completed\n");
}

//*****************************************************************************
//
// Handles presses of the Controls button.
//
//*****************************************************************************
void OnControls(tWidget *psWidget)
{
    UARTprintf("OnControls: Switching to panel %d (%s)\n", 0, g_pcPanei32Names[0]);
    SwitchToPanel(0);
}

//*****************************************************************************
//
// Handles presses of the Plots button.
//
//*****************************************************************************
void OnPlots(tWidget *psWidget)
{
    UARTprintf("OnPlots: Switching to panel %d (%s)\n", 1, g_pcPanei32Names[1]);
    SwitchToPanel(1);
}

//*****************************************************************************
//
// Handles presses of the E-Stop Acknowledge button (Controls panel). Currently disabled.
//
//*****************************************************************************
void OnEStopAcknowledge(tWidget *psWidget)
{
    // Functionality disabled as per request
    UARTprintf("E-Stop Acknowledge button pressed (no functionality)\n");
}

//*****************************************************************************
//
// Handles change notifications for the radio buttons (On/Off).
//
//*****************************************************************************
void OnRadioChange(tWidget *psWidget, uint32_t bSelected)
{
    uint32_t ui32Idx;

    // Find the index of this radio button
    for (ui32Idx = 0; ui32Idx < NUM_RADIO_BUTTONS; ui32Idx++)
    {
        if (psWidget == (tWidget *)(g_psMotorRadioButtons + ui32Idx))
        {
            break;
        }
    }

    // Return if the radio button could not be found
    if (ui32Idx == NUM_RADIO_BUTTONS)
    {
        return;
    }

    // Prevent motor start if E-stop is active
    if (g_bEStop)
    {
        UARTprintf("OnRadioChange: E-stop active, motor state change blocked\n");
        return;
    }

    // Update motor state based on which button was selected
    if (ui32Idx == 0) // "Off" button
    {
        g_bMotorOn = false;
        // Reset speed plot data and index when motor is turned off
        for (uint32_t i = 0; i < LUX_PLOT_POINTS; i++)
        {
            g_pui32SpeedData[i] = 0;
        }
        g_ui32SpeedPlotDataIndex = 0; // Reset index for new data
    }
    else if (ui32Idx == 1) // "On" button
    {
        g_bMotorOn = true;
    }

    // Log the state change
    UARTprintf("OnRadioChange: Motor state: %s\n", g_bMotorOn ? "On" : "Off");

    // Update system mode text immediately
    usprintf(g_pcSystemModeText, "%s", g_bEStop ? "Mode: E-stop" : (g_bMotorOn ? "Mode: Running" : "Mode: Stopped"));
    UARTprintf("OnRadioChange: Setting system status to '%s' (g_bMotorOn = %d, g_bEStop = %d)\n",
               g_pcSystemModeText, g_bMotorOn, g_bEStop);
    CanvasTextSet(&g_sSystemMode, g_pcSystemModeText);
    CanvasFillColorSet(&g_sMotorStatusLED, g_bEStop ? ClrRed : (g_bMotorOn ? ClrGreen : ClrGray));

    // If on Controls panel, update status widgets
    if (g_ui32Panel == 0)
    {
        UARTprintf("OnRadioChange: On Controls panel, updating status\n");
        WidgetPaint((tWidget *)&g_sSystemMode);
        WidgetPaint((tWidget *)&g_sMotorStatusLED);
    }
}

//*****************************************************************************
//
// Handles notifications from the RPM slider (Controls panel).
//
//*****************************************************************************
void OnRPMChange(tWidget *psWidget, int32_t i32Value)
{
    UARTprintf("RPM slider triggered on Controls panel: Value = %d\n", i32Value);

    // Snap to 0 if the value is very low to ensure the slider can reach 0
    if (i32Value < 10)
    {
        i32Value = 0;
    }

    // Update the RPM value
    g_i32RPM = i32Value;

    // Log the new RPM value
    UARTprintf("RPM set to: %d\n", g_i32RPM);

    // Send updated RPM to the motor control logic
    setDesiredRPM((uint16_t)g_i32RPM);

    // Update the slider text to show the RPM value
    usprintf(g_pcSliderText, "%d", g_i32RPM);
    SliderTextSet(&g_psMotorSlider[0], g_pcSliderText);
    WidgetPaint((tWidget *)&g_psMotorSlider[0]);
}

//*****************************************************************************
//
// Handles notifications from the Max Current slider (Controls panel).
//
//*****************************************************************************
void OnMaxCurrentChange(tWidget *psWidget, int32_t i32Value)
{
    UARTprintf("Max Current slider triggered on Controls panel: Value = %d\n", i32Value);

    // Update the max current threshold
    g_i32MaxCurrentThreshold = i32Value;

    // Update the slider text
    usprintf(g_pcSliderText, "Max Current: %dA", g_i32MaxCurrentThreshold);
    SliderTextSet(&g_psThresholdSliders[0], g_pcSliderText);
    WidgetPaint((tWidget *)&g_psThresholdSliders[0]);
}

//*****************************************************************************
//
// Handles notifications from the Max Acceleration slider (Controls panel).
//
//*****************************************************************************
void OnMaxAccelChange(tWidget *psWidget, int32_t i32Value)
{
    UARTprintf("Max Accel slider triggered on Controls panel: Value = %d\n", i32Value);

    // Update the max acceleration threshold
    g_i32MaxAccelThreshold = i32Value;

    // Update the slider text
    usprintf(g_pcSliderText, "Max Accel: %dm/s^2", g_i32MaxAccelThreshold);
    SliderTextSet(&g_psThresholdSliders[1], g_pcSliderText);
    WidgetPaint((tWidget *)&g_psThresholdSliders[1]);
}

//*****************************************************************************
//
// Handles toggle notifications for the Speed plot checkbox.
//
//*****************************************************************************
void OnPlotSpeedToggle(tWidget *psWidget, uint32_t bSelected)
{
    g_bPlotSpeedVisible = bSelected;
    UARTprintf("Speed plot toggle: %s\n", bSelected ? "On" : "Off");
    if (g_ui32Panel == 1) // Plots panel
    {
        WidgetPaint((tWidget *)&g_sSpeedPlot);
    }
}

//*****************************************************************************
//
// Handles toggle notifications for the Power plot checkbox.
//
//*****************************************************************************
void OnPlotPowerToggle(tWidget *psWidget, uint32_t bSelected)
{
    g_bPlotPowerVisible = bSelected;
    UARTprintf("Power plot toggle: %s\n", bSelected ? "On" : "Off");
    if (g_ui32Panel == 1) // Plots panel
    {
        WidgetPaint((tWidget *)&g_sPowerPlot);
    }
}

//*****************************************************************************
//
// Handles toggle notifications for the Lux plot checkbox.
//
//*****************************************************************************
void OnPlotLuxToggle(tWidget *psWidget, uint32_t bSelected)
{
    g_bPlotLuxVisible = bSelected;
    UARTprintf("Lux plot toggle: %s\n", bSelected ? "On" : "Off");
    if (g_ui32Panel == 1) // Plots panel
    {
        WidgetPaint((tWidget *)&g_sLuxPlot);
    }
}

//*****************************************************************************
//
// Handles toggle notifications for the Acceleration plot checkbox.
//
//*****************************************************************************
void OnPlotAccelToggle(tWidget *psWidget, uint32_t bSelected)
{
    g_bPlotAccelVisible = bSelected;
    UARTprintf("Accel plot toggle: %s\n", bSelected ? "On" : "Off");
    if (g_ui32Panel == 1) // Plots panel
    {
        WidgetPaint((tWidget *)&g_sAccelPlot);
    }
}

//*****************************************************************************
//
// Handles paint requests for the Power plot canvas (Plots panel).
//
//*****************************************************************************
void OnPowerPlotPaint(tWidget *psWidget, tContext *psContext)
{
    if (!g_bPlotPowerVisible)
    {
        // Clear the plot area if not visible
        GrContextForegroundSet(psContext, ClrBlack);
        tRectangle plotArea = {120, 64, 319, 103};
        GrRectFill(psContext, &plotArea);
        return;
    }

    // Draw the plot axes and labels
    uint32_t xMax = LUX_PLOT_POINTS - 1; // 0 to 99 (100 points)
    uint32_t yMax = 50;                  // Max power (Watts, based on Max Current slider: 1A = 1W)
    GrContextFontSet(psContext, &g_sFontCm12);
    GrContextForegroundSet(psContext, ClrSilver);
    GrStringDraw(psContext, "0", -1, 110, 100, 0);   // Y-axis: 0
    GrStringDraw(psContext, "100", -1, 110, 64, 0);  // Y-axis: 100 (Watts max)
    GrStringDraw(psContext, "0s", -1, 120, 110, 0);  // X-axis: 0s
    GrStringDraw(psContext, "10s", -1, 310, 110, 0); // X-axis: 10s

    // Define plot area (matches canvas: 120, 64, 200, 40)
    uint32_t plotXMin = 120;
    uint32_t plotXRange = 200;
    uint32_t plotYMin = 64;
    uint32_t plotYRange = 40;

    // Clear the plot area
    GrContextForegroundSet(psContext, ClrBlack);
    tRectangle plotArea = {plotXMin, plotYMin, plotXMin + plotXRange - 1, plotYMin + plotYRange - 1};
    GrRectFill(psContext, &plotArea);

    // Draw the outline
    GrContextForegroundSet(psContext, ClrGray);
    GrRectDraw(psContext, &plotArea);

    // Draw the power data as a continuous line
    GrContextForegroundSet(psContext, ClrRed);
    for (uint32_t i = 1; i < LUX_PLOT_POINTS; i++)
    {
        // Compute x positions (time)
        float x1 = (i - 1) / (float)xMax * plotXRange + plotXMin;
        float x2 = i / (float)xMax * plotXRange + plotXMin;

        // Compute y positions (power in Watts)
        float y1 = plotYMin + plotYRange - (g_pui32PowerData[(g_ui32PowerPlotDataIndex + i - 1) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;
        float y2 = plotYMin + plotYRange - (g_pui32PowerData[(g_ui32PowerPlotDataIndex + i) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;

        // Draw line between points
        GrLineDraw(psContext, (int16_t)x1, (int16_t)y1, (int16_t)x2, (int16_t)y2);
    }
}

//*****************************************************************************
//
// Handles paint requests for the Speed plot canvas (Plots panel).
//
//*****************************************************************************
void OnSpeedPlotPaint(tWidget *psWidget, tContext *psContext)
{
    if (!g_bPlotSpeedVisible)
    {
        // Clear the plot area if not visible
        GrContextForegroundSet(psContext, ClrBlack);
        tRectangle plotArea = {120, 24, 319, 63};
        GrRectFill(psContext, &plotArea);
        return;
    }

    // Draw the plot axes and labels
    uint32_t xMax = LUX_PLOT_POINTS - 1; // 0 to 99 (100 points)
    uint32_t yMax = 5000;                // Max RPM set to 5000
    GrContextFontSet(psContext, &g_sFontCm12);
    GrContextForegroundSet(psContext, ClrSilver);
    GrStringDraw(psContext, "0", -1, 110, 60, 0);    // Y-axis: 0
    GrStringDraw(psContext, "5000", -1, 110, 24, 0); // Y-axis: 5000
    GrStringDraw(psContext, "0s", -1, 120, 70, 0);   // X-axis: 0s
    GrStringDraw(psContext, "10s", -1, 310, 70, 0);  // X-axis: 10s

    // Define plot area (matches canvas: 120, 24, 200, 40)
    uint32_t plotXMin = 120;
    uint32_t plotXRange = 200;
    uint32_t plotYMin = 24;
    uint32_t plotYRange = 40;

    // Clear the plot area
    GrContextForegroundSet(psContext, ClrBlack);
    tRectangle plotArea = {plotXMin, plotYMin, plotXMin + plotXRange - 1, plotYMin + plotYRange - 1};
    GrRectFill(psContext, &plotArea);

    // Draw the outline
    GrContextForegroundSet(psContext, ClrGray);
    GrRectDraw(psContext, &plotArea);

    // Draw the speed data as a continuous line
    GrContextForegroundSet(psContext, ClrGreen);
    for (uint32_t i = 1; i < LUX_PLOT_POINTS; i++)
    {
        // Compute x positions (time)
        float x1 = (i - 1) / (float)xMax * plotXRange + plotXMin;
        float x2 = i / (float)xMax * plotXRange + plotXMin;

        // Compute y positions (RPM)
        float y1 = plotYMin + plotYRange - (g_pui32SpeedData[(g_ui32SpeedPlotDataIndex + i - 1) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;
        float y2 = plotYMin + plotYRange - (g_pui32SpeedData[(g_ui32SpeedPlotDataIndex + i) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;

        // Draw line between points
        GrLineDraw(psContext, (int16_t)x1, (int16_t)y1, (int16_t)x2, (int16_t)y2);
    }
}

//*****************************************************************************
//
// Handles paint requests for the Lux plot canvas (Plots panel).
//
//*****************************************************************************
void OnLuxPlotPaint(tWidget *psWidget, tContext *psContext)
{
    if (!g_bPlotLuxVisible)
    {
        // Clear the plot area if not visible
        GrContextForegroundSet(psContext, ClrBlack);
        tRectangle plotArea = {120, 104, 319, 143};
        GrRectFill(psContext, &plotArea);
        return;
    }

    // Draw the plot axes and labels
    uint32_t xMax = LUX_PLOT_POINTS - 1;       // 0 to 99 (100 points)
    uint32_t yMax = 2000;                      // Max lux (scaled for sensor data)
    GrContextFontSet(psContext, &g_sFontCm12); // Smaller font for axis labels
    GrContextForegroundSet(psContext, ClrSilver);
    GrStringDraw(psContext, "0", -1, 110, 140, 0);    // Y-axis: 0
    GrStringDraw(psContext, "2000", -1, 110, 104, 0); // Y-axis: 1000
    GrStringDraw(psContext, "0s", -1, 120, 150, 0);   // X-axis: 0s
    GrStringDraw(psContext, "10s", -1, 310, 150, 0);  // X-axis: 10s

    // Define plot area (matches canvas: 120, 104, 200, 40)
    uint32_t plotXMin = 120;
    uint32_t plotXRange = 200;
    uint32_t plotYMin = 104;
    uint32_t plotYRange = 40;

    // Clear the plot area
    GrContextForegroundSet(psContext, ClrBlack);
    tRectangle plotArea = {plotXMin, plotYMin, plotXMin + plotXRange - 1, plotYMin + plotYRange - 1};
    GrRectFill(psContext, &plotArea);

    // Draw the outline
    GrContextForegroundSet(psContext, ClrGray);
    GrRectDraw(psContext, &plotArea);

    // Draw the lux data as a continuous line
    GrContextForegroundSet(psContext, ClrYellow);
    for (uint32_t i = 1; i < LUX_PLOT_POINTS; i++)
    {
        // Compute x positions (time)
        float x1 = (i - 1) / (float)xMax * plotXRange + plotXMin;
        float x2 = i / (float)xMax * plotXRange + plotXMin;

        // Compute y positions (lux)
        float y1 = plotYMin + plotYRange - (g_pui32LuxData[(g_ui32LuxPlotDataIndex + i - 1) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;
        float y2 = plotYMin + plotYRange - (g_pui32LuxData[(g_ui32LuxPlotDataIndex + i) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;

        // Draw line between points
        GrLineDraw(psContext, (int16_t)x1, (int16_t)y1, (int16_t)x2, (int16_t)y2);
    }
}

//*****************************************************************************
//
// Handles paint requests for the Acceleration plot canvas (Plots panel).
//
//*****************************************************************************
void OnAccelPlotPaint(tWidget *psWidget, tContext *psContext)
{
    if (!g_bPlotAccelVisible)
    {
        // Clear the plot area if not visible
        GrContextForegroundSet(psContext, ClrBlack);
        tRectangle plotArea = {120, 144, 319, 183};
        GrRectFill(psContext, &plotArea);
        return;
    }

    // Draw the plot axes and labels
    uint32_t xMax = LUX_PLOT_POINTS - 1; // 0 to 99 (100 points)
    uint32_t yMax = 20;                  // Max acceleration (m/s^2, based on Max Accel slider)
    GrContextFontSet(psContext, &g_sFontCm12);
    GrContextForegroundSet(psContext, ClrSilver);
    GrStringDraw(psContext, "0", -1, 110, 180, 0);   // Y-axis: 0
    GrStringDraw(psContext, "20", -1, 110, 144, 0);  // Y-axis: 20 (m/s^2 max)
    GrStringDraw(psContext, "0s", -1, 120, 190, 0);  // X-axis: 0s
    GrStringDraw(psContext, "10s", -1, 310, 190, 0); // X-axis: 10s

    // Define plot area (matches canvas: 120, 144, 200, 40)
    uint32_t plotXMin = 120;
    uint32_t plotXRange = 200;
    uint32_t plotYMin = 144;
    uint32_t plotYRange = 40;

    // Clear the plot area
    GrContextForegroundSet(psContext, ClrBlack);
    tRectangle plotArea = {plotXMin, plotYMin, plotXMin + plotXRange - 1, plotYMin + plotYRange - 1};
    GrRectFill(psContext, &plotArea);

    // Draw the outline
    GrContextForegroundSet(psContext, ClrGray);
    GrRectDraw(psContext, &plotArea);

    // Draw the acceleration data as a continuous line
    GrContextForegroundSet(psContext, ClrBlue);
    for (uint32_t i = 1; i < LUX_PLOT_POINTS; i++)
    {
        // Compute x positions (time)
        float x1 = (i - 1) / (float)xMax * plotXRange + plotXMin;
        float x2 = i / (float)xMax * plotXRange + plotXMin;

        // Compute y positions (acceleration in m/s^2)
        float y1 = plotYMin + plotYRange - (g_pui32AccelData[(g_ui32AccelPlotDataIndex + i - 1) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;
        float y2 = plotYMin + plotYRange - (g_pui32AccelData[(g_ui32AccelPlotDataIndex + i) % LUX_PLOT_POINTS] / (float)yMax) * plotYRange;

        // Draw line between points
        GrLineDraw(psContext, (int16_t)x1, (int16_t)y1, (int16_t)x2, (int16_t)y2);
    }
}

void setCurrentRPM(uint16_t current_rpm)
{
    if (xCurrentRpmSemaphore != NULL)
    {
        if (xSemaphoreTake(xCurrentRpmSemaphore, pdMS_TO_TICKS(10)) == pdTRUE)
        {
            new_current_rpm = current_rpm;
            xSemaphoreGive(xCurrentRpmSemaphore);
        }
    }
}

void vDisplayDemoTask(void)
{
    // Create the semaphore for RPM updates
    xCurrentRpmSemaphore = xSemaphoreCreateMutex();
    if (xCurrentRpmSemaphore == NULL)
    {
        UARTprintf("Failed to create Current RPM semaphore\n");
        while (1)
            ;
    }

    /* Create the display task as described in the comments at the top of this file. */
    xTaskCreate(prvDisplayDemoTask,
                "Display",
                configMINIMAL_STACK_SIZE,
                NULL,
                tskIDLE_PRIORITY + 1,
                NULL);
}
/*-----------------------------------------------------------*/
static void prvDisplayDemoTask(void *pvParameters)
{
    tRectangle sRect;
    TickType_t xLastWakeTime = xTaskGetTickCount();
    bool bLastNightState = g_bIsNight;

    FPUEnable();
    FPULazyStackingEnable();

    Kentec320x240x16_SSD2119Init(configCPU_CLOCK_HZ);
    GrContextInit(&sContext, &g_sKentec320x240x16_SSD2119);

    sRect.i16XMin = 0;
    sRect.i16YMin = 0;
    sRect.i16XMax = GrContextDpyWidthGet(&sContext) - 1;
    sRect.i16YMax = 23;
    GrContextForegroundSet(&sContext, ClrDarkBlue);
    GrRectFill(&sContext, &sRect);
    GrContextForegroundSet(&sContext, ClrWhite);
    GrRectDraw(&sContext, &sRect);
    GrContextFontSet(&sContext, &g_sFontCm20);
    GrStringDrawCentered(&sContext, "TESLA CYBER TRUCK", -1,
                         GrContextDpyWidthGet(&sContext) / 2, 8, 0);

    TouchScreenInit(configCPU_CLOCK_HZ);
    TouchScreenCallbackSet(WidgetPointerMessage);

    WidgetAdd(WIDGET_ROOT, (tWidget *)&g_sControls);
    WidgetAdd(WIDGET_ROOT, (tWidget *)&g_sPlots);
    WidgetAdd(WIDGET_ROOT, (tWidget *)&g_sTitle);

    g_ui32Panel = 0;
    WidgetAdd(WIDGET_ROOT, (tWidget *)g_psPanels);
    CanvasTextSet(&g_sTitle, g_pcPanei32Names[0]);
    WidgetPaint(WIDGET_ROOT);
    SwitchToPanel(0);

    for (;;)
    {
        WidgetMessageQueueProcess();

        TickType_t xCurrentTime = xTaskGetTickCount();
        if ((xCurrentTime - g_xLastClockUpdateTime) >= pdMS_TO_TICKS(1000))
        {
            UpdateClock();
            g_xLastClockUpdateTime = xCurrentTime;
        }

        if (g_ui32Panel == 1 && !g_bSwitchingPanel)
        {
            // --- FIRST: Update Lux plot ---
            if ((xCurrentTime - g_xLastLuxUpdateTime) >= pdMS_TO_TICKS(100))
            {
                SensorMessage msg;
                bool bUpdated = false;

                while (xQueueReceive(xSensorQ, &msg, 0) == pdPASS)
                {
                    g_pui32LuxData[g_ui32LuxPlotDataIndex] = ((uint32_t)msg.filtLux) * 5;
                    g_ui32LuxPlotDataIndex = (g_ui32LuxPlotDataIndex + 1) % LUX_PLOT_POINTS;
                    bUpdated = true;

                    g_bIsNight = (msg.filtLux < 5.0f);
                    if (g_bIsNight != bLastNightState)
                    {
                        usprintf(g_pcDayNightText, "%s", g_bIsNight ? "Night" : "Day");
                        CanvasTextSet(&g_sLightDayNight, g_pcDayNightText);
                        CanvasFillColorSet(&g_sLightHeadlightsLED, g_bIsNight ? ClrYellow : ClrBlack);
                        UARTprintf("Day/Night state changed: %s (Lux: %d)\n", g_pcDayNightText, (int)msg.filtLux);
                        bLastNightState = g_bIsNight;

                        if (g_ui32Panel == 0)
                        {
                            WidgetPaint((tWidget *)&g_sLightDayNight);
                            WidgetPaint((tWidget *)&g_sLightHeadlightsLED);
                        }
                    }
                }

                if (bUpdated && g_bPlotLuxVisible)
                {
                    WidgetPaint((tWidget *)&g_sLuxPlot);
                }

                g_xLastLuxUpdateTime = xCurrentTime;
            }

            // --- THEN: Update Power, Speed, Accel ---
            if ((xCurrentTime - g_xLastPowerUpdateTime) >= pdMS_TO_TICKS(100))
            {
                float current = getTotalCurrent();                                            // in Amps
                g_pui32PowerData[g_ui32PowerPlotDataIndex] = (uint32_t)(current * V_NOMINAL); // Convert to Watts

                g_ui32PowerPlotDataIndex = (g_ui32PowerPlotDataIndex + 1) % LUX_PLOT_POINTS;

                if (xSemaphoreTake(xCurrentRpmSemaphore, pdMS_TO_TICKS(10)) == pdTRUE)
                {
                    g_pui32SpeedData[g_ui32SpeedPlotDataIndex] = (uint32_t)new_current_rpm;
                    g_ui32SpeedPlotDataIndex = (g_ui32SpeedPlotDataIndex + 1) % LUX_PLOT_POINTS;
                    xSemaphoreGive(xCurrentRpmSemaphore);
                }

                g_pui32AccelData[g_ui32AccelPlotDataIndex] = (uint32_t)g_i32MaxAccelThreshold;
                g_ui32AccelPlotDataIndex = (g_ui32AccelPlotDataIndex + 1) % LUX_PLOT_POINTS;

                if (g_bPlotSpeedVisible)
                    WidgetPaint((tWidget *)&g_sSpeedPlot);
                if (g_bPlotPowerVisible)
                    WidgetPaint((tWidget *)&g_sPowerPlot);
                if (g_bPlotAccelVisible)
                    WidgetPaint((tWidget *)&g_sAccelPlot);

                g_xLastPowerUpdateTime = xCurrentTime;
            }
        }
        else
        {
            SensorMessage msg;
            while (xQueueReceive(xSensorQ, &msg, 0) == pdPASS)
            {
                // Discard to prevent queue overflow
            }
        }

        vTaskDelayUntil(&xLastWakeTime, pdMS_TO_TICKS(10));
    }
}

/*-----------------------------------------------------------*/

void vApplicationTickHook(void)
{
    /* This function will be called by each tick interrupt if
        configUSE_TICK_HOOK is set to 1 in FreeRTOSConfig.h.  User code can be
        added here, but the tick hook is called from an interrupt context, so
        code must not attempt to block, and only the interrupt safe FreeRTOS API
        functions can be used (those that end in FromISR()). */
}