/* --------------------------------------------------------------------------
 *  queue_task.c  –  Task-C
 * -------------------------------------------------------------------------*/
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "utils/uartstdio.h"

/* Hardware includes. */
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "drivers/opt3001.h"
#include "drivers/i2cOptDriver.h"
#include "drivers/rtos_hw_drivers.h"

#include "event_groups.h"

/* --------------------------------------------------------------------------
 *  Globals & RTOS objects
 * -------------------------------------------------------------------------*/
#define FILTER_SIZE 5

/* --- event bits ------------------------------------------------------- */
#define EVT_HIGH (1 << 0)
#define EVT_LOW (1 << 1)
#define EVT_TGL (1 << 2)

/* --- high/low thresholds (lux) ----------------------------------- */
#define HIGH_LUX 4000.0f
#define LOW_LUX 50.0f

uint8_t day = 0;
uint8_t night = 0;

typedef struct
{
    float rawLux;
    float filtLux;
    uint32_t ts;
} SensorMessage;

// Declare xSensorQ as a global variable accessible to other files
QueueHandle_t xSensorQ;
static SemaphoreHandle_t xUART;

/* event group handle */
static EventGroupHandle_t xEvt;

static uint32_t g_ui32TimeStamp = 0;

/* --------------------------------------------------------------------------
 *  Forward decl.
 * -------------------------------------------------------------------------*/
static void vSensorSamplingTask(void *p);

// static void xButtonsHandler(void *p);

/* --------------------------------------------------------------------------
 *  Public API called from main()
 * -------------------------------------------------------------------------*/
void vcreateQueueTasks(void)
{
    /* --- Create RTOS objects ------------------------------------------ */
    xSensorQ = xQueueCreate(10, sizeof(SensorMessage));
    xUART = xSemaphoreCreateMutex();
    xEvt = xEventGroupCreate();
    configASSERT(xEvt); /* stop here if allocation fails */

    /* --- Create tasks -------------------------------------------------- */
    xTaskCreate(vSensorSamplingTask, "SNS", configMINIMAL_STACK_SIZE + 120,
                NULL, tskIDLE_PRIORITY + 3, NULL);
}

/* --------------------------------------------------------------------------
 *  Safe printf
 * -------------------------------------------------------------------------*/
static void safeUART(const char *fmt, ...)
{
    va_list args;
    va_start(args, fmt);
    if (xSemaphoreTake(xUART, portMAX_DELAY) == pdTRUE)
    {
        UARTvprintf(fmt, args);
        xSemaphoreGive(xUART);
    }
    va_end(args);
}

/* --------------------------------------------------------------------------
 *  Sensor Sampling Task
 * -------------------------------------------------------------------------*/

/* Helper Function */
bool sensorOpt3001ReadLux(float *pLux)
/* Returns true on success, false on I²C error. */
{
    uint16_t raw;
    if (readI2C(0x47, 0x00, (uint8_t *)&raw)) /* REG_RESULT = 0x00 */
    {
        raw = (raw >> 8) | (raw << 8);   /* endian swap       */
        sensorOpt3001Convert(raw, pLux); /* driver function   */
        if (*pLux < 0)
            *pLux = 0; /* clamp negative    */
        return true;
    }
    return false;
}

static void vSensorSamplingTask(void *p)
{
    float buf[FILTER_SIZE] = {0}, sum = 0;
    int idx = 0;
    TickType_t last = xTaskGetTickCount();
    SensorMessage msg;

    sensorOpt3001Init();
    vTaskDelay(pdMS_TO_TICKS(500));

    for (;;)
    {
        uint16_t raw;
        float lux = 0;

        if (sensorOpt3001ReadLux(&lux) == false)
            lux = buf[(idx - 1) & (FILTER_SIZE - 1)];

        /* --- moving average ------------------------------------------ */
        sum -= buf[idx];
        sum += lux;
        buf[idx] = lux;
        idx = (idx + 1) % FILTER_SIZE;

        /* ---- HIGH / LOW threshold detection ------------------------- */
        if (msg.rawLux > 50.0f) {
            // set high event bit
            xEventGroupSetBits(xEvt, EVT_HIGH);
        }
        else if (msg.rawLux < LOW_LUX) {
            // set low event bit
            xEventGroupSetBits(xEvt, EVT_LOW);
        }

        msg.rawLux = lux;
        msg.filtLux = sum / FILTER_SIZE;
        msg.ts = xTaskGetTickCount();

        // UARTprintf(">Raw: %d.%02d, Filtered: %d.%02d, Day: %d, Night: %d\r\n",
        //            (int)msg.rawLux, (int)(msg.rawLux * 100) % 100,
        //            (int)msg.filtLux, (int)(msg.filtLux * 100) % 100, day, night);

        xQueueSend(xSensorQ, &msg, portMAX_DELAY);
        vTaskDelayUntil(&last, pdMS_TO_TICKS(100)); /* 10 Hz */
    }
}