// #include "FreeRTOS.h"
// #include "semphr.h"
// #include "widget_mutex.h"

// static SemaphoreHandle_t xWidgetMutex;

// void WidgetMutexInit(void)
// {
//     xWidgetMutex = xSemaphoreCreateMutex();
//     configASSERT(xWidgetMutex != NULL);  // Halts if mutex creation fails
// }

// void WidgetMutexGet(void)
// {
//     xSemaphoreTake(xWidgetMutex, portMAX_DELAY);
// }

// void WidgetMutexPut(void)
// {
//     xSemaphoreGive(xWidgetMutex);
// }
