/* Standard includes. */
#include "driverlib/pin_map.h"
#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "timers.h"

/* Hardware includes. */
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_gpio.h"
#include "inc/hw_types.h"

#include "driverlib/sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/timer.h"

#include "drivers/rtos_hw_drivers.h"

#include "utils/uartstdio.h"

#include "driverlib/gpio.h"
#include "driverlib/pwm.h"

#include "motorlib.h"

#define EDGES_PER_REV 24
#define MS_PER_MIN 60000
#define TIMER_PERIOD_MS 10
#define TIMER_PERIOD (g_ui32SysClock / 1000 * TIMER_PERIOD_MS)
#define BUFFER_SIZE 10
#define DESIRED_RPM 2000

#define MAX_ACCELERATION 250
#define MAX_DECELERATION 250
#define ACCELERATION_STEP   MAX_ACCELERATION/TIMER_PERIOD_MS
#define DECELERATION_STEP   MAX_DECELERATION/TIMER_PERIOD_MS

extern uint32_t g_ui32SysClock;

static volatile uint32_t g_edgeCount = 0;
volatile uint32_t g_edgeCount_cur = 0;
volatile uint32_t g_edgeCount_prev = 0;
volatile uint8_t g_hallLast = 0;
volatile uint8_t ha = 0, hb = 0, hc = 0;

volatile uint16_t rpm = 0;
int16_t current_acceleration = 0;

volatile uint16_t duty_value = 0;
uint16_t duty_value_init = 6;
uint8_t maximum_duty = 50;
uint16_t new_desired_rpm = DESIRED_RPM;
uint16_t ctrl_des_rpm = 0;
volatile uint16_t current_duty = 0;

uint16_t accelStep = ACCELERATION_STEP;
uint16_t accelStepFast = 100; // fast acceleration step
uint16_t accelStepSlow = 10; // slow acceleration step
uint16_t decelStep = DECELERATION_STEP;
uint16_t decelStepFast = 100; // fast deceleration step
uint16_t decelStepSlow = 10; // slow deceleration step

// int16_t set_duty_its = 10;
int16_t set_duty_its_inc_slow = 10;
int16_t set_duty_its_inc_fast = 5;
int16_t set_duty_its_dec_slow = 10;
int16_t set_duty_its_dec_fast = 5;
int16_t set_duty_its_estop = 1;


uint16_t duty_value_counter = 0;
uint16_t inc_slow_duty_value_counter = 0;
uint16_t inc_fast_duty_value_counter = 0;
uint16_t dec_slow_duty_value_counter = 0;
uint16_t dec_fast_duty_value_counter = 0;

SemaphoreHandle_t xDesiredRpmSemaphore;
extern void setCurrentRPM(uint16_t rpm);
static void prvMotorTask(void *pvParameters);
void vCreateMotorTask(void);
void HallSensorHandler(void);
uint16_t getSpeedMotor(uint16_t edges_per_period);
void updateSpeedMotor(uint16_t current_rpm, uint16_t desired_rpm);
void startMotor(void);
void setDesiredRPM(uint16_t rpm);
void prvConfigureMotorTimer(void);
void updateSpeedEstop(uint16_t current_rpm, uint16_t desired_rpm);

uint16_t hall_buffer[BUFFER_SIZE] = {0};
static uint32_t sumEdges = 0;
static uint8_t idxEdges = 0;
static uint16_t rpmPrev = 0;

QueueHandle_t xSpeedSensorQueue;

volatile uint16_t motor_state = 0; // 0 = off, 1 = on, 2 = stopping, 3 = estop
QueueHandle_t xMotorStateQueue = NULL;

SemaphoreHandle_t xEstopSemaphore = NULL;

uint16_t estop = 0;
uint16_t estop_set = 0;
uint16_t new_decceleration = 0;

/* ----------- shared globals -------------------------------------- */
volatile uint16_t g_maxCurrentThreshold = 1;   /* default 1 A */
volatile uint16_t estop_setting = 0;         /* default 0 */
SemaphoreHandle_t xMaxCurrentMutex = NULL;      /* protects the variable */
SemaphoreHandle_t xEstopSem        = NULL;      /* E-stop sem flag */

#define ESTOP_DECEL_RPM_PER_SEC  1000
#define ESTOP_STEP_RPM           (ESTOP_DECEL_RPM_PER_SEC / TIMER_PERIOD_MS)
// static bool estopActive = false;


int NumLeadingZeros(uint32_t x)
{
    if (x == 0)
        return 32;
    return __builtin_clz(x);
}



void vCreateMotorTask(void)
{
    /* Setup Hardware */
    prvConfigureMotorTimer();

    xMaxCurrentMutex = xSemaphoreCreateMutex();
    xEstopSem        = xSemaphoreCreateMutex();
    if (xEstopSem == NULL)
    {
        UARTprintf("Failed to create estop semaphore\n");
        while (1);
    }
    // configASSERT(xMaxCurrentMutex && xEstopSem);

    xDesiredRpmSemaphore = xSemaphoreCreateMutex();
    if (xDesiredRpmSemaphore == NULL)
    {
        UARTprintf("Failed to create desired RPM semaphore\n");
        while (1);
    }

    // xEstopSemaphore = xSemaphoreCreateMutex();
    // if (xEstopSemaphore == NULL)
    // {
    //     UARTprintf("Failed to create desired estop semaphore\n");
    //     while (1);
    // }

    /* length 5 buffer queue for 16-bit edge counts */
    xSpeedSensorQueue = xQueueCreate(10, sizeof(uint16_t));
    configASSERT(xSpeedSensorQueue);

    xTaskCreate(prvMotorTask, "MotorTask",
                configMINIMAL_STACK_SIZE, NULL,
                tskIDLE_PRIORITY + 1, NULL);
}

uint16_t estop_counter = 0;

static void prvMotorTask(void *pvParameters)
{
    uint16_t edges_this_period;
    uint16_t last_edges = 0;

    startMotor();

    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(100));

        // this if state
        if (xQueueReceive(xSpeedSensorQueue,
                          &edges_this_period,
                          pdMS_TO_TICKS(10)) == pdPASS)
        {

            if (xSpeedSensorQueue == NULL)
            {
                UARTprintf("Failed to create queues\n");
            }

            while (xQueueReceive(xSpeedSensorQueue,&edges_this_period,0) == pdPASS)
                last_edges = edges_this_period;

            // rpm = getSpeedMotor(edges_this_period);
            rpm = getSpeedMotor(last_edges);

            uint16_t desired_rpm_local = DESIRED_RPM;
        
            if (xSemaphoreTake(xDesiredRpmSemaphore, pdMS_TO_TICKS(10)) == pdTRUE)
            {
                desired_rpm_local = new_desired_rpm;
                xSemaphoreGive(xDesiredRpmSemaphore);
            }

            // if (xSemaphoreTake(xEstopSem, pdMS_TO_TICKS(10)) == pdPASS)
            // {
            //     estop_set = estop_setting;
            //     // xSemaphoreGive(xEstopSem);
            //     UARTprintf("E-stop flag recieved by motor!\n");
            // }

            // if (estop_counter >= 150)
            // {
            //     estop_set = 1;
            //     // estop_counter = 0; // reset counter after 10 seconds
            // }
            
            if (estop_set == 1)
            {
                desired_rpm_local = 0; // E-stop active, set desired RPM to 0
                updateSpeedEstop(rpm, 0);
                // UARTprintf("E-stop active, decelerating...\n");
            }
            else
            {
                updateSpeedMotor(rpm, desired_rpm_local);
            }

            setCurrentRPM((uint16_t)rpm);

            // UARTprintf(">rpm:%u,desired_rpm:%u\r\n", rpm, desired_rpm_local);
            
            // estop_counter++;

        }

    }
}

void HallSensorHandler(void)
{
    ha = (GPIOPinRead(GPIO_PORTM_BASE, GPIO_PIN_3) >> 3) & 1;
    hb = (GPIOPinRead(GPIO_PORTH_BASE, GPIO_PIN_2) >> 2) & 1;
    hc = (GPIOPinRead(GPIO_PORTN_BASE, GPIO_PIN_2) >> 2) & 1;

    g_edgeCount_cur++;
    updateMotor(ha, hb, hc);

    GPIOIntClear(GPIO_PORTM_BASE, GPIO_PIN_3);
    GPIOIntClear(GPIO_PORTH_BASE, GPIO_PIN_2);
    GPIOIntClear(GPIO_PORTN_BASE, GPIO_PIN_2);
}

void Timer3AHandler(void)
{
    /*----- 1. Clear the interrupt -----*/
    TimerIntClear(TIMER3_BASE, TIMER_TIMA_TIMEOUT);

    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    /*----- 2. Compute edges in this 10 ms slice -----*/
    uint16_t edges_this_period = g_edgeCount_cur - g_edgeCount_prev;
    g_edgeCount_prev = g_edgeCount_cur;

    /*----- 3. Push to queue for the MotorTask -----*/
    xQueueSendFromISR(xSpeedSensorQueue, &edges_this_period, &xHigherPriorityTaskWoken);

    /*----- 4. Context switch if needed -----*/
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

void prvConfigureMotorTimer(void)
{
    /* 10 ms periodic “speed snapshot” timer – Timer3A */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);

    /* 32-bit periodic mode */
    TimerConfigure(TIMER3_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER3_BASE, TIMER_A, g_ui32SysClock / 100);   // 100 Hz

    /* Interrupt enable */
    IntEnable(INT_TIMER3A);
    TimerIntEnable(TIMER3_BASE, TIMER_TIMA_TIMEOUT);

    /* Start */
    TimerEnable(TIMER3_BASE, TIMER_A);

    /* Enable the timer interrupt in the NVIC. */
    IntMasterEnable();
}


void startMotor(void)
{
    if (!initMotorLib(maximum_duty))
    {
        UARTprintf("Motor init failed\n");
    }
    else
    {
        UARTprintf("Motor init success\n");
    }
    setDuty(duty_value_init);
    HallSensorHandler();
}

uint16_t getSpeedMotor(uint16_t edges_per_period)
{
    sumEdges -= hall_buffer[idxEdges];
    sumEdges += edges_per_period;
    hall_buffer[idxEdges] = edges_per_period;
    idxEdges = (idxEdges + 1) % BUFFER_SIZE;

    uint32_t meanEdges = sumEdges;
    uint32_t rpmNow = (uint32_t)(meanEdges * (MS_PER_MIN / 100) / EDGES_PER_REV);
    int16_t accel = ((int16_t)rpmNow - (int16_t)rpmPrev) * (1000 / TIMER_PERIOD_MS);

    current_acceleration = accel;
    rpmPrev = rpmNow;

    return rpmPrev;
}

void updateSpeedMotor(uint16_t current_rpm, uint16_t desired_rpm)
{
    if (current_rpm < desired_rpm - accelStep || current_rpm > desired_rpm + decelStep)
    {
        if (current_rpm < desired_rpm - accelStep)
        {
            // uint16_t error = desired_rpm - current_rpm;
            ctrl_des_rpm = current_rpm + accelStep;
            // UARTprintf("Increasing desired RPM: %u\n", ctrl_des_rpm);
            // UARTprintf("accelStep: %u\n", accelStep);

            inc_fast_duty_value_counter++;
            if (inc_fast_duty_value_counter >= set_duty_its_inc_fast)
            {
                current_duty++;
                //UARTprintf("Increasing duty: %u\n", current_duty);
                setDuty(current_duty);
                inc_fast_duty_value_counter = 0;
            }
        }
        else if (current_rpm < desired_rpm && current_rpm >= desired_rpm - accelStep) {

            inc_slow_duty_value_counter++;
            if (inc_slow_duty_value_counter >= set_duty_its_inc_slow)
            {
                current_duty++;
                //UARTprintf("Increasing duty: %u\n", current_duty);
                setDuty(current_duty);
                inc_slow_duty_value_counter = 0;
            }

        }
        else if (current_rpm >= desired_rpm + decelStep)
        {
            ctrl_des_rpm = current_rpm - decelStep;
            //UARTprintf("Decreasing desired RPM: %u\n", ctrl_des_rpm);

            dec_fast_duty_value_counter++;
            if (dec_fast_duty_value_counter >= set_duty_its_dec_fast)
            {
                current_duty--;
                //UARTprintf("Decreasing duty: %u\n", current_duty);
                setDuty(current_duty);
                dec_fast_duty_value_counter = 0;
            }
        }
        else if (current_rpm > desired_rpm && current_rpm <= desired_rpm - decelStep) {

            dec_slow_duty_value_counter++;
            if (dec_slow_duty_value_counter >= set_duty_its_dec_slow)
            {
                current_duty--;
                //UARTprintf("Increasing duty: %u\n", current_duty);
                setDuty(current_duty);
                dec_slow_duty_value_counter = 0;
            }
        }
    }
}

void updateSpeedEstop(uint16_t current_rpm, uint16_t desired_rpm)
{
    if (current_rpm > desired_rpm + ESTOP_STEP_RPM && current_rpm > 250)
    {
        ctrl_des_rpm = current_rpm - ESTOP_STEP_RPM;
        current_duty--;
        setDuty(current_duty);
    }
    else
    {
        ctrl_des_rpm = 0; // E-stop active, set desired RPM to 0
        current_duty = 0;
        setDuty(current_duty);
        stopMotor(1); // disable PWM < 250 RPM
        estop_set = 0; // allow restart
        // xSemaphoreGive(xEstopSem); // give the semaphore back
        UARTprintf("E-stop complete, motor stopped\n");
    }
}

void setDesiredRPM(uint16_t rpm)
{
    if (xDesiredRpmSemaphore != NULL)
    {
        if (xSemaphoreTake(xDesiredRpmSemaphore, pdMS_TO_TICKS(10)) == pdTRUE)
        {
            new_desired_rpm = rpm;
            xSemaphoreGive(xDesiredRpmSemaphore);
        }
    }
}

void setEstop(uint16_t estop)
{

    if (xSemaphoreTake(xEstopSemaphore, pdMS_TO_TICKS(10)) == pdTRUE)
    {
        // estop_set = estop;
        xSemaphoreGive(xEstopSemaphore);
    }
    
}
