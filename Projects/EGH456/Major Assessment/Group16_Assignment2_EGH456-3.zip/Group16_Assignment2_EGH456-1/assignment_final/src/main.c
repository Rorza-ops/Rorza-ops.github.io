/*
 * hello
 *
 * Copyright (C) 2022 Texas Instruments Incorporated
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

/******************************************************************************
 *
 * This motor test project provides an example of how to use the motor library
 * with a platformio / freeRTOS project. The main script initialises the hall 
 * sensor interrupt, which run the update_motor function. The program also launches 
 * a task that initialises the motors before ramping the speed from 10% to 100%.
 * Once the speed reaches 100%, the motor is stopped and the program ends.
 * 
 */

extern void ADC1_Init(void);
extern void vCurrentSenseTask(void *);

/* Standard includes. */

#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "semphr.h"
#include "widget_mutex.h"
/* Hardware includes. */
#include "driverlib/pin_map.h"
#include "inc/hw_memmap.h"
#include "inc/hw_sysctl.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "drivers/rtos_hw_drivers.h"
#include "utils/uartstdio.h"
#include "driverlib/gpio.h"
#include "driverlib/pwm.h"
#include "driverlib/timer.h"

// Motor lib
#include <motorlib.h>

/*-----------------------------------------------------------*/

/* The system clock frequency. */
uint32_t g_ui32SysClock;

/* Set up the hardware ready to run this demo. */
static void prvSetupHardware( void );

/* This function sets up UART0 to be used for a console to display information
 * as the example is running. */
static void prvConfigureUART(void);

/* API to trigger the 'Hello world' task. */
extern void vCreateMotorTask( void );

/* API to configure the hall effect sensor interrupts. */
static void prvConfigureHallInts( void );

/* API to configure the motor timer. */
// static void prvConfigureMotorTimer(void);

/* API to configure the hall effect sensor interrupts. */
extern void HallSensorHandler(void);

extern void prvEdgePrintTask(void *pvParameters);


extern void ADC1_Init_AIN5(void);
extern void ADC1_Init_AIN0(void);

extern void vCreateCurrentSenseTask_AIN5(void);
extern void vCreateCurrentSenseTask_AIN0(void);
extern void vcreateQueueTasks(void);
/* GUI Task*/
extern void vDisplayDemoTask(void);
/* Configure the buttons. */
static void ConfigureButtons(void);
SemaphoreHandle_t xButtonSemaphore = NULL;
/*-----------------------------------------------------------*/

int main( void )
{
    prvSetupHardware();
    ConfigureButtons();
    vCreateMotorTask();
    xButtonSemaphore = xSemaphoreCreateBinary();
    ADC1_Init_AIN5();
    vCreateCurrentSenseTask_AIN5();

    ADC1_Init_AIN0();
    vCreateCurrentSenseTask_AIN0();
    vcreateQueueTasks();

    vDisplayDemoTask();
    /* Create the Hello task to output a message over UART. */
    

    // xTaskCreate(prvEdgePrintTask, "EdgePrint", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);
    //WidgetMutexInit();


    /* Start the tasks and timer running. */
    vTaskStartScheduler();

    /* If all is well, the scheduler will now be running, and the following
    line will never be reached.  If the following line does execute, then
    there was insufficient FreeRTOS heap memory available for the idle and/or
    timer tasks to be created.  See the memory management section on the
    FreeRTOS web site for more details. */
    for( ;; );
}
/*-----------------------------------------------------------*/
static void prvConfigureUART(void)
{
    /* Enable GPIO port A which is used for UART0 pins.
     * TODO: change this to whichever GPIO port you are using. */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Configure the pin muxing for UART0 functions on port A0 and A1.
     * This step is not necessary if your part does not support pin muxing.
     * TODO: change this to select the port/pin you are using. */
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    /* Enable UART0 so that we can configure the clock. */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Use the internal 16MHz oscillator as the UART clock source. */
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    /* Select the alternate (UART) function for these pins.
     * TODO: change this to select the port/pin you are using. */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    /* Initialize the UART for console I/O. */
    UARTStdioConfig(0, 9600, 16000000);


}
/*-----------------------------------------------------------*/

static void prvSetupHardware(void)
{
    /* Run from the PLL at configCPU_CLOCK_HZ MHz. */
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
            SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
            SYSCTL_CFG_VCO_240), configCPU_CLOCK_HZ);

    /* Configure device pins. */
    PinoutSet(false, false);

    /* Configure UART0 to send messages to terminal. */
    prvConfigureUART();

    /* Initialize the hardware timer for motor. */
    // prvConfigureMotorTimer();
    
    /* Set-up interrupts for hall sensors */
    prvConfigureHallInts();

    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C2);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);

    /* Reset the I2C0 peripheral to ensure a clean state */
    // SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C2);

    /* Add a longer delay to ensure peripherals are ready */
    SysCtlDelay(g_ui32SysClock / 3); /* ~1 second delay at 120MHz */
    GPIOPinConfigure(GPIO_PN5_I2C2SCL);
    GPIOPinConfigure(GPIO_PN4_I2C2SDA);

    /* Select the I2C function for these pins */
    // GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
    // GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);

    GPIOPinTypeI2CSCL(GPIO_PORTN_BASE, GPIO_PIN_5); // GPIO_PN5_I2C2SCL
    GPIOPinTypeI2C(GPIO_PORTN_BASE, GPIO_PIN_4);    // GPIO_PN4_I2C2SDA

    /* Initialize I2C master */
    I2CMasterInitExpClk(I2C2_BASE, g_ui32SysClock, false);

    /* Initialize the I2C driver (semaphore and interrupts) */
    i2cOptDriverInit();

}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook( void )
{
    /* vApplicationMallocFailedHook() will only be called if
    configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h.  It is a hook
    function that will get called if a call to pvPortMalloc() fails.
    pvPortMalloc() is called internally by the kernel whenever a task, queue,
    timer or semaphore is created.  It is also called by various parts of the
    demo application.  If heap_1.c or heap_2.c are used, then the size of the
    heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
    FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
    to query the size of free heap space that remains (although it does not
    provide information on how the remaining heap might be fragmented). */
    IntMasterDisable();
    for( ;; );
}
/*-----------------------------------------------------------*/
static void prvConfigureHallInts( void )
{

    /* ----------------------------------------------------------------------------- */
    /* Configure GPIO ports to trigger an interrupt on rising/falling or both edges. */
    /* ----------------------------------------------------------------------------  */

    /* Configure GPIO ports to trigger an interrupt on rising/falling or both edges. */
    MAP_GPIOPinTypeGPIOInput(GPIO_PORTM_BASE, GPIO_PIN_3);
    MAP_GPIOPinTypeGPIOInput(GPIO_PORTH_BASE, GPIO_PIN_2);
    MAP_GPIOPinTypeGPIOInput(GPIO_PORTN_BASE, GPIO_PIN_2);

    /* Configure the interrupts for the hall effect sensors */
    MAP_GPIOIntTypeSet(GPIO_PORTM_BASE, GPIO_PIN_3, GPIO_BOTH_EDGES);
    MAP_GPIOIntTypeSet(GPIO_PORTH_BASE, GPIO_PIN_2, GPIO_BOTH_EDGES);
    MAP_GPIOIntTypeSet(GPIO_PORTN_BASE, GPIO_PIN_2, GPIO_BOTH_EDGES);

    /* Enable the interrupt for LaunchPad GPIO Port in the GPIO peripheral. */
    MAP_GPIOIntEnable(GPIO_PORTM_BASE, GPIO_PIN_3);
    MAP_GPIOIntEnable(GPIO_PORTH_BASE, GPIO_PIN_2);
    MAP_GPIOIntEnable(GPIO_PORTN_BASE, GPIO_PIN_2);

    /* Enable the Ports interrupt in the NVIC. */
    MAP_IntEnable(INT_GPIOM);
    MAP_IntEnable(INT_GPIOH);
    MAP_IntEnable(INT_GPION);

    // /* Set up the timer that will check the speed to run at 100Hz */ 
    // SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);
    // TimerConfigure(TIMER3_BASE, TIMER_CFG_PERIODIC);
    // TimerLoadSet(TIMER3_BASE, TIMER_A, g_ui32SysClock / 100);
    // IntEnable(INT_TIMER3A);

    // TimerIntEnable(TIMER3_BASE, TIMER_TIMA_TIMEOUT);
    // TimerEnable(TIMER3_BASE, TIMER_A);

    /* Enable the interrupt in the NVIC. */
    IntMasterEnable();

}

/*-----------------------------------------------------------*/

// void prvConfigureMotorTimer(void)
// {
//     /* 10 ms periodic “speed snapshot” timer – Timer3A */
//     SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER3);

//     /* 32-bit periodic mode */
//     TimerConfigure(TIMER3_BASE, TIMER_CFG_PERIODIC);
//     TimerLoadSet(TIMER3_BASE, TIMER_A, g_ui32SysClock / 100);   // 100 Hz

//     /* Interrupt enable */
//     IntEnable(INT_TIMER3A);
//     TimerIntEnable(TIMER3_BASE, TIMER_TIMA_TIMEOUT);

//     /* Start */
//     TimerEnable(TIMER3_BASE, TIMER_A);

//     /* Enable the timer interrupt in the NVIC. */
//     IntMasterEnable();
// }

/*-----------------------------------------------------------*/

void vApplicationIdleHook( void )
{
    /* vApplicationIdleHook() will only be called if configUSE_IDLE_HOOK is set
    to 1 in FreeRTOSConfig.h.  It will be called on each iteration of the idle
    task.  It is essential that code added to this hook function never attempts
    to block in any way (for example, call xQueueReceive() with a block time
    specified, or call vTaskDelay()).  If the application makes use of the
    vTaskDelete() API function (as this demo application does) then it is also
    important that vApplicationIdleHook() is permitted to return to its calling
    function, because it is the responsibility of the idle task to clean up
    memory allocated by the kernel to any task that has since been deleted. */
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook( TaskHandle_t pxTask, char *pcTaskName )
{
    ( void ) pcTaskName;
    ( void ) pxTask;

    /* Run time stack overflow checking is performed if
    configCHECK_FOR_STACK_OVERFLOW is defined to 1 or 2.  This hook
    function is called if a stack overflow is detected. */
    IntMasterDisable();
    for( ;; );
}
/*-----------------------------------------------------------*/

void *malloc( size_t xSize )
{
    /* There should not be a heap defined, so trap any attempts to call
    malloc. */
    IntMasterDisable();
    for( ;; );
}
/*-----------------------------------------------------------*/


static void ConfigureButtons(void)
{
    // BUTTON INTERRUPTS
    /* Initialize the LaunchPad Buttons. */
    ButtonsInit();

    // Configure both switches to trigger an interrupt on a falling edge.
    GPIOIntTypeSet(BUTTONS_GPIO_BASE, ALL_BUTTONS, GPIO_FALLING_EDGE);

    // Enable the interrupt for LaunchPad GPIO Port in the GPIO peripheral.
    GPIOIntEnable(BUTTONS_GPIO_BASE, ALL_BUTTONS);

    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOJ);

    // Enable the Port J interrupt in the NVIC. FOR BUTTONS
    IntEnable(INT_GPIOJ);

    //
    // Enable all interrupts to the processor.
    //
    IntMasterEnable();
}

/*-----------------------------------------------------------*/
