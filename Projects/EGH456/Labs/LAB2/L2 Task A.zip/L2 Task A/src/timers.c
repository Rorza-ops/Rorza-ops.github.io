#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/debug.h"
#include "driverlib/fpu.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/timer.h"
#include "driverlib/uart.h"
#include "utils/uartstdio.h"
#include "utils/ustdlib.h"
#include "grlib.h"
#include "widget.h"
#include "canvas.h"
#include "drivers/Kentec320x240x16_ssd2119_spi.h"
#include "drivers/touch.h"

// Global variables
uint32_t g_ui32SysClock;
uint32_t g_ui32Timer1Count = 0;
uint32_t g_ui32Timer2Count = 0;
uint32_t g_ui32Flags;
tContext sContext;
tRectangle sRect;

#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line)
{
}
#endif

// Timer 1 interrupt handler (Timer 1 = 0.125Hz)
void Timer0IntHandler(void)
{
    char cTimer1[5], cTimer2[5];

    // Clear the timer interrupt
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    //
    // Toggle the flag for the first timer.
    //
    HWREGBITW(&g_ui32Flags, 0) ^= 1;

    //
    // Use the flags to Toggle the LED for this timer
    //
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_0, g_ui32Flags);

    // Increment Timer 1 counter and reset if it reaches 10
    g_ui32Timer1Count++;
    if (g_ui32Timer1Count >= 10)
    {
        g_ui32Timer1Count = 0;
    }

    // Format the counter values as strings
    usprintf(cTimer1, "%u", g_ui32Timer1Count);
    usprintf(cTimer2, "%u", g_ui32Timer2Count);

    // Clear the region for Timer 1 and Timer 2
    sRect.i16XMin = 0;
    sRect.i16YMin = 30; // Y position for Timer 1 counter
    sRect.i16XMax = GrContextDpyWidthGet(&sContext) - 1;
    sRect.i16YMax = 60;                          // Y position for Timer 2 counter
    GrContextForegroundSet(&sContext, ClrWhite); // Background color
    GrRectFill(&sContext, &sRect);               // Clear the region for both counters

    // Display Timer 1 count
    GrContextForegroundSet(&sContext, ClrBlack); // Text color
    GrStringDraw(&sContext, "Timer 1 Count:", -1, 10, 30, 0);
    GrStringDraw(&sContext, cTimer1, -1, 150, 30, 0);

    // Display Timer 2 count
    GrStringDraw(&sContext, "Timer 2 Count:", -1, 10, 60, 0);
    GrStringDraw(&sContext, cTimer2, -1, 150, 60, 0);

    // Update UART with current counter values
    IntMasterDisable();
    UARTprintf("\rT1: %u  T2: %u", g_ui32Timer1Count, g_ui32Timer2Count);
    IntMasterEnable();
}

// Timer 2 interrupt handler (Timer 2 = 0.25Hz)
void Timer1IntHandler(void)
{
    char cTimer1[5], cTimer2[5];

    // Clear the timer interrupt
    TimerIntClear(TIMER1_BASE, TIMER_TIMA_TIMEOUT);
    //
    // Toggle the flag for the second timer.
    //
    HWREGBITW(&g_ui32Flags, 1) ^= 1;

    //
    // Use the flags to Toggle the LED for this timer
    //
    GPIOPinWrite(GPIO_PORTN_BASE, GPIO_PIN_1, g_ui32Flags);

    // Increment Timer 2 counter and reset if it reaches 10
    g_ui32Timer2Count++;
    if (g_ui32Timer2Count >= 10)
    {
        g_ui32Timer2Count = 0;
    }

    // Format the counter values as strings
    usprintf(cTimer1, "%u", g_ui32Timer1Count);
    usprintf(cTimer2, "%u", g_ui32Timer2Count);

    // Clear the region for Timer 1 and Timer 2
    sRect.i16XMin = 0;
    sRect.i16YMin = 30; // Y position for Timer 1 counter
    sRect.i16XMax = GrContextDpyWidthGet(&sContext) - 1;
    sRect.i16YMax = 90;                          // Y position for Timer 2 counter
    GrContextForegroundSet(&sContext, ClrWhite); // Background color
    GrRectFill(&sContext, &sRect);               // Clear the region for both counters

    // Display Timer 1 count
    GrContextForegroundSet(&sContext, ClrBlack); // Text color
    GrStringDraw(&sContext, "Timer 1 Count:", -1, 10, 30, 0);
    GrStringDraw(&sContext, cTimer1, -1, 150, 30, 0);

    // Display Timer 2 count
    GrStringDraw(&sContext, "Timer 2 Count:", -1, 10, 60, 0);
    GrStringDraw(&sContext, cTimer2, -1, 150, 60, 0);

    // Update UART with current counter values
    IntMasterDisable();
    UARTprintf("\rT1: %u  T2: %u", g_ui32Timer1Count, g_ui32Timer2Count);
    IntMasterEnable();
}

// Configure the UART
void ConfigureUART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTStdioConfig(0, 9600, g_ui32SysClock);
}

int main(void)
{
    // Initialize FPU and Lazy Stacking
    FPUEnable();
    FPULazyStackingEnable();

    // Set System Clock to 120 MHz
    g_ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                                         SYSCTL_OSC_MAIN |
                                         SYSCTL_USE_PLL |
                                         SYSCTL_CFG_VCO_240),
                                        120000000);

    // Initialize the display
    Kentec320x240x16_SSD2119Init(g_ui32SysClock);

    // Initialize graphics context
    GrContextInit(&sContext, &g_sKentec320x240x16_SSD2119);

    // Fill the top 24 rows of the screen with blue to create the banner
    sRect.i16XMin = 0;
    sRect.i16YMin = 0;
    sRect.i16XMax = GrContextDpyWidthGet(&sContext) - 1;
    sRect.i16YMax = 23;
    GrContextForegroundSet(&sContext, ClrCyan);
    GrRectFill(&sContext, &sRect);

    // Draw a border around the banner
    GrContextForegroundSet(&sContext, ClrBlack);
    GrRectDraw(&sContext, &sRect);

    // Display a title in the banner
    GrContextFontSet(&sContext, &g_sFontCm20);
    GrStringDrawCentered(&sContext, "Rory, n10773398", -1,
                         GrContextDpyWidthGet(&sContext) / 2, 8, 0);

    // Configure UART
    ConfigureUART();

    UARTprintf("\033[2JTimers example\n");
    UARTprintf("T1: 0  T2: 0");

    // Enable the GPIO port used for the on-board LEDs
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPION);

    // Enable the GPIO pins for the LEDs (PN0 & PN1)
    GPIOPinTypeGPIOOutput(GPIO_PORTN_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    // Enable the peripherals used by this example
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER1);

    // Enable processor interrupts
    IntMasterEnable();

    // Configure the timers
    TimerConfigure(TIMER0_BASE, TIMER_CFG_PERIODIC);
    TimerConfigure(TIMER1_BASE, TIMER_CFG_PERIODIC);
    TimerLoadSet(TIMER0_BASE, TIMER_A, g_ui32SysClock * 8); // Timer 1: 0.125Hz (8 seconds)
    TimerLoadSet(TIMER1_BASE, TIMER_A, g_ui32SysClock * 4); // Timer 2: 0.25Hz (4 seconds)

    // Setup the interrupts for the timer timeouts
    IntEnable(INT_TIMER0A);
    IntEnable(INT_TIMER1A);
    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    TimerIntEnable(TIMER1_BASE, TIMER_TIMA_TIMEOUT);

    // Enable the timers
    TimerEnable(TIMER0_BASE, TIMER_A);
    TimerEnable(TIMER1_BASE, TIMER_A);

    // Loop forever while the timers run
    while (1)
    {
    }
}
