#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "drivers/rtos_hw_drivers.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"

volatile uint32_t g_ui32TimeStamp = 0;
volatile static uint32_t g_pui32ButtonPressed = NULL;
extern SemaphoreHandle_t xButtonSemaphore;
SemaphoreHandle_t xSW1Semaphore;
SemaphoreHandle_t xSW2Semaphore;
static volatile uint8_t ui8LEDIndex = 0;
static void prvLEDShiftRightTask(void *pvParameters);
static void prvLEDShiftLeftTask(void *pvParameters);
static void prvStatusTask(void *pvParameters);
void vCreateLEDTask(void);
static void prvConfigureLED(void);
static void prvConfigureButton(void);
static void prvLEDShiftRightTask(void *pvParameters);
static void prvLEDShiftLeftTask(void *pvParameters);

void vCreateLEDTask(void)
{
    prvConfigureLED();
    prvConfigureButton();
    /* UART Setup */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTStdioConfig(0, 9600, 16000000);
    xSW1Semaphore = xSemaphoreCreateBinary();
    xSW2Semaphore = xSemaphoreCreateBinary();
    xTaskCreate(prvLEDShiftRightTask, "ShiftRight", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);
    xTaskCreate(prvLEDShiftLeftTask, "ShiftLeft", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);
    xTaskCreate(prvStatusTask, "Status", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY, NULL);
}

static void prvLEDShiftRightTask(void *pvParameters)
{
    for (;;)
    {
        if (xSemaphoreTake(xSW1Semaphore, portMAX_DELAY) == pdPASS)
        {
            taskENTER_CRITICAL(); /* Protect shared ui8LEDIndex */
            ui8LEDIndex = (ui8LEDIndex == 3) ? 0 : ui8LEDIndex + 1;
            LEDWrite(LED_D1 | LED_D2 | LED_D3 | LED_D4, 0); /* Turn off all LEDs */
            switch (ui8LEDIndex)
            {
            case 0:
                LEDWrite(LED_D1, LED_D1);
                break;
            case 1:
                LEDWrite(LED_D2, LED_D2);
                break;
            case 2:
                LEDWrite(LED_D3, LED_D3);
                break;
            case 3:
                LEDWrite(LED_D4, LED_D4);
                break;
            }
            taskEXIT_CRITICAL();
        }
    }
}

static void prvLEDShiftLeftTask(void *pvParameters)
{
    for (;;)
    {
        if (xSemaphoreTake(xSW2Semaphore, portMAX_DELAY) == pdPASS)
        {
            taskENTER_CRITICAL(); /* Protect shared ui8LEDIndex */
            ui8LEDIndex = (ui8LEDIndex == 0) ? 3 : ui8LEDIndex - 1;
            LEDWrite(LED_D1 | LED_D2 | LED_D3 | LED_D4, 0); /* Turn off all LEDs */
            switch (ui8LEDIndex)
            {
            case 0:
                LEDWrite(LED_D1, LED_D1);
                break;
            case 1:
                LEDWrite(LED_D2, LED_D2);
                break;
            case 2:
                LEDWrite(LED_D3, LED_D3);
                break;
            case 3:
                LEDWrite(LED_D4, LED_D4);
                break;
            }
            taskEXIT_CRITICAL();
        }
    }
}

static void prvStatusTask(void *pvParameters)
{
    const char *statusMsg = "System OK\r\n";
    for (;;)
    {
        /* Print status message */
        while (*statusMsg)
        {
            UARTCharPut(UART0_BASE, *statusMsg++);
        }
        vTaskDelay(pdMS_TO_TICKS(1000)); /* Delay 1 second */
        statusMsg = "System OK\r\n";     /* Reset pointer */
    }
}

static void prvConfigureLED(void)
{
    /* Configure initial LED state.  PinoutSet() has already configured
     * LED I/O. */
    LEDWrite(0, 0);
}
/*-----------------------------------------------------------*/

static void prvConfigureButton(void)
{
    /* Initialize the LaunchPad Buttons. */
    ButtonsInit();

    /* Configure both switches to trigger an interrupt on a falling edge. */
    GPIOIntTypeSet(BUTTONS_GPIO_BASE, ALL_BUTTONS, GPIO_FALLING_EDGE);

    /* Enable the interrupt for LaunchPad GPIO Port in the GPIO peripheral. */
    GPIOIntEnable(BUTTONS_GPIO_BASE, ALL_BUTTONS);

    /* Enable the Port F interrupt in the NVIC. */
    IntEnable(INT_GPIOJ);

    /* Enable global interrupts in the NVIC. */
    IntMasterEnable();
}
/*-----------------------------------------------------------*/

void xButtonsHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint32_t ui32Status;
    ui32Status = GPIOIntStatus(BUTTONS_GPIO_BASE, true);
    GPIOIntClear(BUTTONS_GPIO_BASE, ui32Status);
    if ((xTaskGetTickCount() - g_ui32TimeStamp) > 100) /* Debounce */
    {
        if ((ui32Status & USR_SW1) == USR_SW1)
        {
            xSemaphoreGiveFromISR(xSW1Semaphore, &xHigherPriorityTaskWoken);
        }
        else if ((ui32Status & USR_SW2) == USR_SW2)
        {
            xSemaphoreGiveFromISR(xSW2Semaphore, &xHigherPriorityTaskWoken);
        }
        g_ui32TimeStamp = xTaskGetTickCount();
    }
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}
/*-----------------------------------------------------------*/
