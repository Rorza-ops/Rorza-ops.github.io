#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include <stdlib.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "inc/hw_types.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/sysctl.h"
#include "driverlib/rom_map.h"
#include "driverlib/timer.h"
#include "utils/ustdlib.h"
#include "drivers/rtos_hw_drivers.h"
#include "grlib.h"
#include "widget.h"
#include "canvas.h"
#include "drivers/Kentec320x240x16_ssd2119_spi.h"
#include "drivers/touch.h"

// Game state definitions
typedef enum
{
    STATE_INTRO,
    STATE_PLAYING,
    STATE_GAME_OVER
} GameState;

// Fruit structure
typedef struct
{
    uint32_t xPos;
    uint32_t yPos;
    bool active;
} Fruit;

// Shared variables protected by semaphore
volatile GameState gameSTATE = STATE_INTRO;
volatile int basketDIR = 0; // -1: LEFT, +1: RIGHT, 0: NONE
volatile int basketPOS = 0; // Basket x-position
volatile int gameSCORE = 0;
volatile int gameLIVES = 3;
volatile Fruit fruits[5];         // Array for up to 5 fruits
volatile uint32_t fruitCount = 0; // Number of active fruits
volatile bool timersINT = false;

// Constants
#define MAX_FRUITS 5
#define SCREEN_WIDTH GrContextDpyWidthGet(&sContext)
#define SCREEN_HEIGHT GrContextDpyHeightGet(&sContext)
#define BASKET_WIDTH 70
#define BASKET_HEIGHT 10
#define FRUIT_WIDTH 10
#define FRUIT_HEIGHT 10
#define PLAYER_SPEED 40 // Pixels per update (~100 pixels/sec at 20Hz)
#define FRUIT_SPEED 3   // Pixels per update (240px in ~4s at 20Hz)

// Global variables
volatile uint32_t g_ui32TimeStamp = 0;
extern volatile uint32_t g_ui32SysClock;
extern SemaphoreHandle_t xButtonSemaphore;
SemaphoreHandle_t xGameSemaphore;
tContext sContext;
tRectangle sRect;

// Function prototypes
static void prvDisplayTask(void *pvParameters);
static void prvLogicTask(void *pvParameters);
static void prvConfigureLED(void);
static void prvConfigureHWTimer(void);
static void prvConfigureButton(void);
void xTimer0AHandler(void);
void xTimer0BHandler(void);
void initGame(void);

// Task creation functions
void vCreateDisplayTask(void)
{
    prvConfigureLED();
    prvConfigureButton();
    prvConfigureHWTimer();
    xGameSemaphore = xSemaphoreCreateMutex();
    xTaskCreate(prvDisplayTask, "DISPLAYS", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 2, NULL);
    xTaskCreate(prvLogicTask, "LOGIC", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);
}

// Hardware configuration
static void prvConfigureLED(void)
{
    LEDWrite(LED_D1, LED_D1); // Indicate system is on
}

static void prvConfigureButton(void)
{
    ButtonsInit();
    GPIOIntTypeSet(BUTTONS_GPIO_BASE, ALL_BUTTONS, GPIO_FALLING_EDGE);
    GPIOIntEnable(BUTTONS_GPIO_BASE, ALL_BUTTONS);
    IntEnable(INT_GPIOJ);
    IntMasterEnable();
}

static void prvConfigureHWTimer(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_TIMER0);
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_TIMER0))
    {
    }
    TimerConfigure(TIMER0_BASE, TIMER_CFG_SPLIT_PAIR | TIMER_CFG_A_PERIODIC | TIMER_CFG_B_PERIODIC);

    // Timer0A: 50ms period for falling
    TimerPrescaleSet(TIMER0_BASE, TIMER_A, 99);    // Divide by 100
    uint32_t timerA_load = (120000000 / 100) / 20; // 60,000 cycles = 50ms
    TimerLoadSet(TIMER0_BASE, TIMER_A, timerA_load);

    // Timer0B: 2s period for spawning
    TimerPrescaleSet(TIMER0_BASE, TIMER_B, 99);   // Divide by 100
    uint32_t timerB_load = (120000000 / 100) * 2; // 2,400,000 cycles = 2s
    TimerLoadSet(TIMER0_BASE, TIMER_B, timerB_load);

    TimerIntEnable(TIMER0_BASE, TIMER_TIMA_TIMEOUT | TIMER_TIMB_TIMEOUT);
    IntPrioritySet(INT_TIMER0A, 0x20);
    IntPrioritySet(INT_TIMER0B, 0x20);
    IntEnable(INT_TIMER0A);
    IntEnable(INT_TIMER0B);
    IntMasterEnable();

    TimerIntClear(TIMER0_BASE, TIMER_TIMB_TIMEOUT);
    TimerEnable(TIMER0_BASE, TIMER_A | TIMER_B);
    timersINT = true;
    LEDWrite(LED_D2, LED_D2);
}

// Interrupt handlers
void xButtonsHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint32_t ui32Status = GPIOIntStatus(BUTTONS_GPIO_BASE, true);
    GPIOIntClear(BUTTONS_GPIO_BASE, ui32Status);

    if ((xTaskGetTickCount() - g_ui32TimeStamp) > 100)
    {
        xSemaphoreTakeFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
        if ((ui32Status & USR_SW2) == USR_SW2)
        {
            basketDIR = -1; // LEFT
        }
        else if ((ui32Status & USR_SW1) == USR_SW1)
        {
            basketDIR = 1; // RIGHT
        }
        xSemaphoreGiveFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
        xSemaphoreGiveFromISR(xButtonSemaphore, &xHigherPriorityTaskWoken);
        portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
    }
    g_ui32TimeStamp = xTaskGetTickCount();
}

// Fruit Dropping
void xTimer0AHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    TimerIntClear(TIMER0_BASE, TIMER_TIMA_TIMEOUT);
    xSemaphoreTakeFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
    if (timersINT)
    {
        for (uint32_t i = 0; i < MAX_FRUITS; i++)
        {
            if (fruits[i].active)
            {
                fruits[i].yPos += FRUIT_SPEED;
                if (fruits[i].yPos > SCREEN_HEIGHT)
                {
                    fruits[i].active = false;
                    fruitCount--;
                    if (gameSTATE == STATE_PLAYING)
                    {
                        gameLIVES--;
                        if (gameLIVES <= 0)
                        {
                            xSemaphoreTakeFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
                            gameSTATE = STATE_GAME_OVER;
                            // Clear any pending button signals
                            while (xSemaphoreTakeFromISR(xButtonSemaphore, NULL) == pdTRUE)
                            {
                            }
                            xSemaphoreGiveFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
                        }
                    }
                }
            }
        }
    }
    xSemaphoreGiveFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

// Fruit Spawning
void xTimer0BHandler(void)
{
    static TickType_t lastSpawnTime = 0;
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    TimerIntClear(TIMER0_BASE, TIMER_TIMB_TIMEOUT);
    xSemaphoreTakeFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);

    TickType_t currentTime = xTaskGetTickCountFromISR();
    if (gameSTATE == STATE_PLAYING && timersINT && fruitCount < MAX_FRUITS &&
        (currentTime - lastSpawnTime >= pdMS_TO_TICKS(2000)))
    {
        for (uint32_t i = 0; i < MAX_FRUITS; i++)
        {
            if (!fruits[i].active)
            {
                fruits[i].xPos = rand() % (SCREEN_WIDTH - FRUIT_WIDTH);
                fruits[i].yPos = 0;
                fruits[i].active = true;
                fruitCount++;
                LEDWrite(LED_D3, LED_D3);
                LEDWrite(LED_D3, 0);
                lastSpawnTime = currentTime;
                break;
            }
        }
    }
    xSemaphoreGiveFromISR(xGameSemaphore, &xHigherPriorityTaskWoken);
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

// Game initialization
void initGame(void)
{
    xSemaphoreTake(xGameSemaphore, portMAX_DELAY);
    srand(xTaskGetTickCount());
    gameSCORE = 0;
    gameLIVES = 3;
    basketPOS = (SCREEN_WIDTH - BASKET_WIDTH) / 2;
    for (uint32_t i = 0; i < MAX_FRUITS; i++)
    {
        fruits[i].xPos = 0;
        fruits[i].yPos = 0;
        fruits[i].active = false;
    }
    fruitCount = 0;
    basketDIR = 0;
    xSemaphoreGive(xGameSemaphore);
}

// Logic task
static void prvLogicTask(void *pvParameters)
{
    xSemaphoreTake(xGameSemaphore, portMAX_DELAY);
    srand(xTaskGetTickCount());
    gameSCORE = 0;
    gameLIVES = 3;
    basketPOS = (SCREEN_WIDTH - BASKET_WIDTH) / 2;
    for (uint32_t i = 0; i < MAX_FRUITS; i++)
    {
        fruits[i].xPos = 0;
        fruits[i].yPos = 0;
        fruits[i].active = false;
    }
    fruitCount = 0;
    basketDIR = 0;
    xSemaphoreGive(xGameSemaphore);
    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(50));
        xSemaphoreTake(xGameSemaphore, portMAX_DELAY);

        if (gameSTATE == STATE_PLAYING)
        {
            // Update basket position
            basketPOS += basketDIR * PLAYER_SPEED;
            if (basketPOS < 0)
                basketPOS = 0;
            else if (basketPOS > SCREEN_WIDTH - BASKET_WIDTH)
                basketPOS = SCREEN_WIDTH - BASKET_WIDTH;

            // Check all fruits for catching
            for (uint32_t i = 0; i < MAX_FRUITS; i++)
            {
                if (fruits[i].active)
                {
                    if (fruits[i].yPos + FRUIT_HEIGHT >= SCREEN_HEIGHT - BASKET_HEIGHT &&
                        fruits[i].yPos <= SCREEN_HEIGHT &&
                        fruits[i].xPos + FRUIT_WIDTH >= basketPOS &&
                        fruits[i].xPos <= basketPOS + BASKET_WIDTH)
                    {
                        gameSCORE++;
                        fruits[i].active = false;
                        fruitCount--;
                    }
                }
            }
        }
        basketDIR = 0;
        xSemaphoreGive(xGameSemaphore);
    }
}

// Display task
static void prvDisplayTask(void *pvParameters)
{
    Kentec320x240x16_SSD2119Init(g_ui32SysClock);
    GrContextInit(&sContext, &g_sKentec320x240x16_SSD2119);
    sRect.i16XMin = 0;
    sRect.i16YMin = 0;
    sRect.i16XMax = SCREEN_WIDTH - 1;
    sRect.i16YMax = SCREEN_HEIGHT - 1;

    for (;;)
    {
        vTaskDelay(pdMS_TO_TICKS(50));
        xSemaphoreTake(xGameSemaphore, portMAX_DELAY);
        GameState localState = gameSTATE;
        int localPlayerX = basketPOS;
        Fruit localFruits[MAX_FRUITS];
        for (uint32_t i = 0; i < MAX_FRUITS; i++)
        {
            localFruits[i] = fruits[i];
        }
        int localScore = gameSCORE;
        int localLives = gameLIVES;
        xSemaphoreGive(xGameSemaphore);

        GrContextForegroundSet(&sContext, ClrDarkBlue);
        GrRectFill(&sContext, &sRect);

        if (localState == STATE_INTRO)
        {
            GrContextForegroundSet(&sContext, ClrWhite);
            GrContextFontSet(&sContext, &g_sFontCm40);
            GrStringDrawCentered(&sContext, "Falling Fruit", -1, SCREEN_WIDTH / 2, 40, 0);
            GrContextFontSet(&sContext, &g_sFontCm20);
            GrStringDrawCentered(&sContext, "SW2 = LEFT", -1, SCREEN_WIDTH / 2, 80, 0);
            GrStringDrawCentered(&sContext, "SW1 = RIGHT", -1, SCREEN_WIDTH / 2, 120, 0);
            GrStringDrawCentered(&sContext, "Press to Start", -1, SCREEN_WIDTH / 2, 160, 0);
            if (xSemaphoreTake(xButtonSemaphore, pdMS_TO_TICKS(50)) == pdPASS)
            {
                xSemaphoreTake(xGameSemaphore, portMAX_DELAY);
                initGame();
                gameSTATE = STATE_PLAYING;
                xSemaphoreGive(xGameSemaphore);
            }
        }
        else if (localState == STATE_PLAYING)
        {
            // DISPLAY BASKET
            GrContextForegroundSet(&sContext, ClrWhite);
            GrRectFill(&sContext, &(tRectangle){localPlayerX, SCREEN_HEIGHT - BASKET_HEIGHT,
                                                localPlayerX + BASKET_WIDTH, SCREEN_HEIGHT});

            // DISPLAY FRUITS
            GrContextForegroundSet(&sContext, ClrRed);
            for (uint32_t i = 0; i < MAX_FRUITS; i++)
            {
                if (localFruits[i].active && localFruits[i].yPos <= SCREEN_HEIGHT)
                {
                    GrRectFill(&sContext, &(tRectangle){localFruits[i].xPos, localFruits[i].yPos,
                                                        localFruits[i].xPos + FRUIT_WIDTH,
                                                        localFruits[i].yPos + FRUIT_HEIGHT});
                }
            }
            char displayStr[20];
            usprintf(displayStr, "Score: %d Lives: %d", localScore, localLives);
            GrContextForegroundSet(&sContext, ClrWhite);
            GrContextFontSet(&sContext, &g_sFontCm20);
            GrStringDrawCentered(&sContext, displayStr, -1, SCREEN_WIDTH / 2, 10, 0);
        }
        else if (localState == STATE_GAME_OVER)
        {
            GrContextForegroundSet(&sContext, ClrWhite);
            GrContextFontSet(&sContext, &g_sFontCm40);
            GrStringDrawCentered(&sContext, "Game Over", -1, SCREEN_WIDTH / 2, 40, 0);
            char scoreStr[20];
            usprintf(scoreStr, "Score: %d", localScore);
            GrContextFontSet(&sContext, &g_sFontCm20);
            GrStringDrawCentered(&sContext, scoreStr, -1, SCREEN_WIDTH / 2, 80, 0);
            GrStringDrawCentered(&sContext, "Press to Restart", -1, SCREEN_WIDTH / 2, 120, 0);
            if (xSemaphoreTake(xButtonSemaphore, pdMS_TO_TICKS(50)) == pdPASS)
            {
                xSemaphoreTake(xGameSemaphore, portMAX_DELAY);
                gameSTATE = STATE_INTRO;
                xSemaphoreGive(xGameSemaphore);
            }
        }
    }
}