#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "inc/hw_memmap.h"
#include "inc/hw_sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "drivers/rtos_hw_drivers.h"
#include "driverlib/pin_map.h"
#include "utils/uartstdio.h"
#include "driverlib/uart.h"
#include "driverlib/gpio.h"

volatile uint32_t g_ui32SysClock;
SemaphoreHandle_t xButtonSemaphore = NULL;
static void prvSetupHardware(void);
extern void vCreateDisplayTask(void);
extern void vCreateLogicTask(void);
static void prvConfigureUART(void);

int main(void)
{
    prvSetupHardware();
    xButtonSemaphore = xSemaphoreCreateBinary();
    if (xButtonSemaphore != NULL)
    {
        vCreateDisplayTask();
        vTaskStartScheduler();
    }
    for (;;)
        ;
}

static void prvConfigureUART(void)
{
    /* Enable GPIO port A which is used for UART0 pins.
     * TODO: change this to whichever GPIO port you are using. */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Configure the pin muxing for UART0 functions on port A0 and A1.
     * This step is not necessary if your part does not support pin muxing.
     * TODO: change this to select the port/pin you are using. */
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    /* Enable UART0 so that we can configure the clock. */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Use the internal 16MHz oscillator as the UART clock source. */
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_PIOSC);

    /* Select the alternate (UART) function for these pins.
     * TODO: change this to select the port/pin you are using. */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    /* Initialize the UART for console I/O. */
    UARTStdioConfig(0, 9600, 16000000);
}

static void prvSetupHardware(void)
{
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                                             SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
                                             SYSCTL_CFG_VCO_240),
                                            configCPU_CLOCK_HZ);
    PinoutSet(false, false);
    prvConfigureUART();
}

void vApplicationMallocFailedHook(void)
{
    IntMasterDisable();
    for (;;)
        ;
}

void vApplicationIdleHook(void)
{
}

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
    (void)pcTaskName;
    (void)pxTask;
    IntMasterDisable();
    for (;;)
        ;
}

void *malloc(size_t xSize)
{
    IntMasterDisable();
    for (;;)
        ;
}

void vApplicationTickHook(void)
{
}
