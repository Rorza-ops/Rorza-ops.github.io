#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "FreeRTOS.h"
#include "task.h"
#include "driverlib/sysctl.h"
#include "drivers/opt3001.h"
#include "drivers/i2cOptDriver.h"
#include "utils/uartstdio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/i2c.h"
#include "driverlib/interrupt.h"
#include "drivers/rtos_hw_drivers.h"

/* Define constants matching the values in opt3001.c, as they are not exposed in opt3001.h */
#define OPT3001_I2C_ADDRESS 0x47
#define REG_MANUFACTURER_ID 0x7E
#define REG_DEVICE_ID 0x7F

extern uint32_t g_ui32SysClock;

static void prvSensorReadTask(void *pvParameters);
static void prvConfigureUART(void);

void vCreateSensorTask(void)
{
    /* Configure UART before creating the task */
    prvConfigureUART();

    /* Create the sensor read task */
    xTaskCreate(prvSensorReadTask, "SensorRead", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);
}

static void prvConfigureUART(void)
{
    /* Enable GPIO port A which is used for UART0 pins */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Configure the pin muxing for UART0 functions on port A0 and A1 */
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    /*Embedded Systems: Laboratory 3 – RTOS and Real-Time Data Plotting Page 10 of 12
     * Enable UART0 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Use the system clock for UART */
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_SYSTEM);

    /* Select the alternate (UART) function for these pins */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    /* Initialize the UART for console I/O */
    UARTStdioConfig(0, 9600, g_ui32SysClock);

    /* Small delay to ensure UART is ready */
    SysCtlDelay(g_ui32SysClock); /* ~1 second delay at 120MHz */
}

static void prvSensorReadTask(void *pvParameters)
{
    bool success;
    uint16_t rawData = 0;
    float convertedLux = 0;

    /* Initialize the OPT3001 sensor */
    sensorOpt3001Init();

    /* Add a delay to ensure the sensor is ready (per datasheet recommendation) */
    vTaskDelay(pdMS_TO_TICKS(500)); /* 500ms delay after power-up */

    /* Test the defined slave address (0x47) */
    {
        uint16_t val;

        // Check manufacturer ID
        readI2C(OPT3001_I2C_ADDRESS, REG_MANUFACTURER_ID, (uint8_t *)&val);
        val = (val >> 8) | (val << 8);
        UARTprintf("Manufacturer ID Read: 0x%04x (Expected: 0x5449)\n", val);

        // Check device ID
        readI2C(OPT3001_I2C_ADDRESS, REG_DEVICE_ID, (uint8_t *)&val);
        val = (val >> 8) | (val << 8);
        UARTprintf("Device ID Read: 0x%04x (Expected: 0x3001)\n", val);
    }

    /* Test that the sensor is set up correctly */
    UARTprintf("Testing OPT3001 Sensor:\n");
    success = sensorOpt3001Test();

    /* Stay here until the sensor is working */
    while (!success)
    {
        vTaskDelay(pdMS_TO_TICKS(1000)); /* Delay 1 second before retrying */
        UARTprintf("Test Failed, Trying again\n");
        success = sensorOpt3001Test();
    }

    UARTprintf("All Tests Passed!\n\n");

    /* Small delay to allow SerialPlot to connect before data streaming */
    vTaskDelay(pdMS_TO_TICKS(2000)); /* 2-second delay */

    /* Continuously read and output lux values */
    for (;;)
    {
        /* Initialize lux value to 0 in case of failure */
        convertedLux = 0;

        /* Read and convert OPT3001 values */
        success = sensorOpt3001Read(&rawData);

        if (success)
        {
            sensorOpt3001Convert(rawData, &convertedLux);
        }

        /* Ensure the value is non-negative for SerialPlot */
        if (convertedLux < 0)
        {
            convertedLux = 0;
        }

        /* Output the lux value as a number for SerialPlot */
        UARTprintf("%d\n", (int)convertedLux);

        /* Delay for 100ms to attempt the fastest rate (sensor internally limits to 800ms) */
        vTaskDelay(pdMS_TO_TICKS(100));
    }
}