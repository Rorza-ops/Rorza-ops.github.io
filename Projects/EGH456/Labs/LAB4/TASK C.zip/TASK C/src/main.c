/*
 * semaphore_example
 *
 * Copyright (C) 2022 Texas Instruments Incorporated
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 */

/******************************************************************************
 *
 * This project integrates the OPT3001 demo into a FreeRTOS environment.
 * It sets up the I2C peripheral for the OPT3001 sensor and starts the FreeRTOS
 * scheduler with a sensor read task.
 *
 */

/* Standard includes. */
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>

/* Kernel includes. */
#include "FreeRTOS.h"
#include "task.h"

/* Hardware includes. */
#include "inc/hw_memmap.h"
#include "inc/hw_sysctl.h"
#include "driverlib/interrupt.h"
#include "driverlib/rom.h"
#include "driverlib/rom_map.h"
#include "driverlib/sysctl.h"
#include "driverlib/i2c.h"
#include "driverlib/gpio.h"
#include "drivers/rtos_hw_drivers.h"
#include "driverlib/pin_map.h"
#include "driverlib/uart.h"
#include "drivers/i2cOptDriver.h"
/*-----------------------------------------------------------*/

/* The system clock frequency. */
uint32_t g_ui32SysClock;

/* Set up the clock and pin configurations to run this example. */
static void prvSetupHardware(void);

/* Create the sensor task. */
extern void vCreateSensorTask(void);
/*-----------------------------------------------------------*/

int main(void)
{
    /* Prepare the hardware to run this example. */
    prvSetupHardware();

    /* Initialize the sensor task */
    vCreateSensorTask();

    /* Enable global interrupts after all setups */
    IntMasterEnable();

    /* Start the tasks */
    vTaskStartScheduler();

    /* If all is well, the scheduler will now be running, and the following
    line will never be reached.  If the following line does execute, then
    there was insufficient FreeRTOS heap memory available for the idle and/or
    timer tasks to be created.  See the memory management section on the
    FreeRTOS web site for more details. */
    for (;;)
        ;
}
/*-----------------------------------------------------------*/
static void prvSetupHardware(void)
{
    /* Run from the PLL at 120 MHz to match OPT3001 demo requirements. */
    g_ui32SysClock = MAP_SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                                             SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
                                             SYSCTL_CFG_VCO_240),
                                            120000000);

    /* Initialize I2C0 peripheral for OPT3001 sensor */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

    /* Reset the I2C0 peripheral to ensure a clean state */
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);

    /* Add a longer delay to ensure peripherals are ready */
    SysCtlDelay(g_ui32SysClock / 3); /* ~1 second delay at 120MHz */

    /* Configure the pin muxing for I2C0 functions on port B2 and B3 */
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);

    /* Select the I2C function for these pins */
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);

    /* Initialize I2C master */
    I2CMasterInitExpClk(I2C0_BASE, g_ui32SysClock, false);

    /* Initialize the I2C driver (semaphore and interrupts) */
    i2cOptDriverInit();

    /* Comment out PinoutSet to avoid potential pin conflicts */
    // PinoutSet(false, false);
}
/*-----------------------------------------------------------*/

void vApplicationMallocFailedHook(void)
{
    IntMasterDisable();
    for (;;)
        ;
}
/*-----------------------------------------------------------*/

void vApplicationIdleHook(void)
{
}
/*-----------------------------------------------------------*/

void vApplicationTickHook(void)
{
}
/*-----------------------------------------------------------*/

void vApplicationStackOverflowHook(TaskHandle_t pxTask, char *pcTaskName)
{
    (void)pcTaskName;
    (void)pxTask;

    IntMasterDisable();
    for (;;)
        ;
}
/*-----------------------------------------------------------*/

void *malloc(size_t xSize)
{
    IntMasterDisable();
    for (;;)
        ;
}
/*-----------------------------------------------------------*/