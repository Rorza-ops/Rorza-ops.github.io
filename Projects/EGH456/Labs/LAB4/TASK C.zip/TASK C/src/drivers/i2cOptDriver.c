/**************************************************************************************************
 *  Filename:       i2cOptDriver.c
 *  By:             Jesse Haviland
 *  Created:        1 February 2019
 *  Revised:        23 March 2019
 *  Revision:       2.0
 *
 *  Description:    i2c Driver for use with opt3001.c and the TI OP3001 Optical Sensor
 *************************************************************************************************/

// ----------------------- Includes -----------------------
#include "i2cOptDriver.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h" /* Added explicitly for INT_I2C0 */
#include "driverlib/i2c.h"
#include "driverlib/interrupt.h"
#include "utils/uartstdio.h"
#include "driverlib/sysctl.h"
#include "FreeRTOS.h"
#include "semphr.h"

// ----------------------- Global Variables -----------------------
static SemaphoreHandle_t xI2CSemaphore = NULL;
static volatile bool g_bI2CError = false; /* Flag to indicate I2C error in ISR */

// ----------------------- Function Definitions -----------------------
void i2cOptDriverInit(void)
{
    /* Create the binary semaphore for I2C synchronization */
    xI2CSemaphore = xSemaphoreCreateBinary();
    if (xI2CSemaphore == NULL)
    {
        UARTprintf("Failed to create I2C semaphore\n");
        while (1)
            ; /* Fatal error */
    }

    /* Enable I2C0 interrupts */
    I2CMasterIntEnable(I2C0_BASE);

    /* Register the ISR for I2C0 */
    IntRegister(INT_I2C0, I2C0IntHandler);

    /* Enable I2C0 interrupts in the NVIC */
    IntEnable(INT_I2C0);
}

/*
 * Sets slave address to ui8Addr
 * Puts ui8Reg followed by two data bytes in *data and transfers
 * over i2c
 */
bool writeI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data)
{
    /* Reset error flag */
    g_bI2CError = false;

    /* Load device slave address */
    I2CMasterSlaveAddrSet(I2C0_BASE, ui8Addr, false);

    /* Place the register to be sent in the data register */
    I2CMasterDataPut(I2C0_BASE, ui8Reg);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_START);

    /* Wait for the operation to complete */
    if (xSemaphoreTake(xI2CSemaphore, pdMS_TO_TICKS(1000)) != pdTRUE)
    {
        UARTprintf("writeI2C: Timeout waiting for semaphore (reg)\n");
        return false;
    }

    if (g_bI2CError)
    {
        UARTprintf("writeI2C: I2C error during register write\n");
        return false;
    }

    /* Send first data byte */
    I2CMasterDataPut(I2C0_BASE, data[0]);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_CONT);

    if (xSemaphoreTake(xI2CSemaphore, pdMS_TO_TICKS(1000)) != pdTRUE)
    {
        UARTprintf("writeI2C: Timeout waiting for semaphore (data[0])\n");
        return false;
    }

    if (g_bI2CError)
    {
        UARTprintf("writeI2C: I2C error during data[0] write\n");
        return false;
    }

    /* Send second data byte */
    I2CMasterDataPut(I2C0_BASE, data[1]);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);

    if (xSemaphoreTake(xI2CSemaphore, pdMS_TO_TICKS(1000)) != pdTRUE)
    {
        UARTprintf("writeI2C: Timeout waiting for semaphore (data[1])\n");
        return false;
    }

    if (g_bI2CError)
    {
        UARTprintf("writeI2C: I2C error during data[1] write\n");
        return false;
    }

    return true;
}

/*
 * Sets slave address to ui8Addr
 * Writes ui8Reg over i2c to specify register being read from
 * Reads three bytes from i2c slave. The third is redundant but
 * helps to flush the i2c register
 * Stores first two received bytes into *data
 */
bool readI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data)
{
    /* Reset error flag */
    g_bI2CError = false;

    /* Load device slave address and change I2C to write */
    I2CMasterSlaveAddrSet(I2C0_BASE, ui8Addr, false);

    /* Place the register to be sent in the data register */
    I2CMasterDataPut(I2C0_BASE, ui8Reg);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND);

    /* Wait for the operation to complete */
    if (xSemaphoreTake(xI2CSemaphore, pdMS_TO_TICKS(1000)) != pdTRUE)
    {
        UARTprintf("readI2C: Timeout waiting for semaphore (reg)\n");
        return false;
    }

    if (g_bI2CError)
    {
        UARTprintf("readI2C: I2C error during register write\n");
        return false;
    }

    /* Load device slave address and change I2C to read */
    I2CMasterSlaveAddrSet(I2C0_BASE, ui8Addr, true);

    /* Read first byte */
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);

    if (xSemaphoreTake(xI2CSemaphore, pdMS_TO_TICKS(1000)) != pdTRUE)
    {
        UARTprintf("readI2C: Timeout waiting for semaphore (data[0])\n");
        return false;
    }

    if (g_bI2CError)
    {
        UARTprintf("readI2C: I2C error during data[0] read\n");
        return false;
    }

    data[0] = I2CMasterDataGet(I2C0_BASE);

    /* Read second byte */
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);

    if (xSemaphoreTake(xI2CSemaphore, pdMS_TO_TICKS(1000)) != pdTRUE)
    {
        UARTprintf("readI2C: Timeout waiting for semaphore (data[1])\n");
        return false;
    }

    if (g_bI2CError)
    {
        UARTprintf("readI2C: I2C error during data[1] read\n");
        return false;
    }

    data[1] = I2CMasterDataGet(I2C0_BASE);

    return true;
}

/*
 * ISR for I2C0 interrupts
 */
void I2C0IntHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    /* Get the interrupt status */
    uint32_t ui32Status = I2CMasterIntStatus(I2C0_BASE, true);

    /* Clear the interrupt */
    I2CMasterIntClear(I2C0_BASE);

    /* Check for errors */
    uint32_t ui32Error = I2CMasterErr(I2C0_BASE);
    if (ui32Error != I2C_MASTER_ERR_NONE)
    {
        g_bI2CError = true;
        if (ui32Error & I2C_MASTER_ERR_ADDR_ACK)
        {
            UARTprintf("I2C ISR: Address not acknowledged\n");
        }
        if (ui32Error & I2C_MASTER_ERR_DATA_ACK)
        {
            UARTprintf("I2C ISR: Data not acknowledged\n");
        }
        if (ui32Error & I2C_MASTER_ERR_ARB_LOST)
        {
            UARTprintf("I2C ISR: Arbitration lost\n");
        }
    }

    /* Signal the task that the I2C operation has completed */
    xSemaphoreGiveFromISR(xI2CSemaphore, &xHigherPriorityTaskWoken);

    /* Yield if a higher priority task was woken */
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}