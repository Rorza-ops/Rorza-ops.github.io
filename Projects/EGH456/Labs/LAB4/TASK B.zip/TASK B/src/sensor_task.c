#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "driverlib/sysctl.h"
#include "drivers/opt3001.h"
#include "drivers/i2cOptDriver.h"
#include "utils/uartstdio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/i2c.h"
#include "driverlib/interrupt.h"
#include "drivers/rtos_hw_drivers.h"

/* Define constants matching the values in opt3001.c, as they are not exposed in opt3001.h */
#define OPT3001_I2C_ADDRESS 0x47
#define REG_MANUFACTURER_ID 0x7E
#define REG_DEVICE_ID 0x7F

extern uint32_t g_ui32SysClock;
extern SemaphoreHandle_t xButtonSemaphore; /* Use the semaphore from main.c */

static void prvSensorReadTask(void *pvParameters);
static void prvConfigureUART(void);
static void prvConfigureButton(void);
static void prvDebugI2CBusState(void); /* Re-added for debugging */

static volatile bool g_bSensorReadingEnabled = false; /* Flag to toggle sensor reading */
static volatile uint32_t g_ui32TimeStamp = 0;         /* For button debouncing */

void vCreateSensorTask(void)
{
    /* Configure UART before creating the task */
    prvConfigureUART();

    /* Configure buttons */
    prvConfigureButton();

    /* Create the sensor read task */
    xTaskCreate(prvSensorReadTask, "SensorRead", configMINIMAL_STACK_SIZE, NULL, tskIDLE_PRIORITY + 1, NULL);
}

static void prvConfigureUART(void)
{
    /* Enable GPIO port A which is used for UART0 pins */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Configure the pin muxing for UART0 functions on port A0 and A1 */
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    /* Enable UART0 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Use the system clock for UART */
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_SYSTEM);

    /* Select the alternate (UART) function for these pins */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    /* Initialize the UART for console I/O */
    UARTStdioConfig(0, 9600, g_ui32SysClock);

    /* Small delay to ensure UART is ready */
    SysCtlDelay(g_ui32SysClock); /* ~1 second delay at 120MHz */
}

static void prvDebugI2CBusState(void)
{
    /* Temporarily configure SCL and SDA as GPIO inputs to read their state */
    GPIOPinTypeGPIOInput(GPIO_PORTB_BASE, GPIO_PIN_2 | GPIO_PIN_3);

    /* Read the pin states */
    uint32_t ui32SCL = GPIOPinRead(GPIO_PORTB_BASE, GPIO_PIN_2);
    uint32_t ui32SDA = GPIOPinRead(GPIO_PORTB_BASE, GPIO_PIN_3);

    /* Restore I2C pin functions */
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);
}

static void prvConfigureButton(void)
{
    /* Initialize the LaunchPad Buttons */
    ButtonsInit();

    /* Configure both switches to trigger an interrupt on a falling edge */
    GPIOIntTypeSet(BUTTONS_GPIO_BASE, ALL_BUTTONS, GPIO_FALLING_EDGE);

    /* Enable the interrupt for LaunchPad GPIO Port in the GPIO peripheral */
    GPIOIntEnable(BUTTONS_GPIO_BASE, ALL_BUTTONS);

    /* Enable the Port J interrupt in the NVIC */
    IntEnable(INT_GPIOJ);

    /* Enable global interrupts in the NVIC */
    IntMasterEnable();
}

void xButtonsHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;
    uint32_t ui32Status;
    ui32Status = GPIOIntStatus(BUTTONS_GPIO_BASE, true);
    GPIOIntClear(BUTTONS_GPIO_BASE, ui32Status);
    if ((xTaskGetTickCount() - g_ui32TimeStamp) > 100) /* Debounce */
    {
        if ((ui32Status & USR_SW1) == USR_SW1)
        {
            /* Toggle the sensor reading state */
            g_bSensorReadingEnabled = !g_bSensorReadingEnabled;
            UARTprintf("Sensor reading %s\n", g_bSensorReadingEnabled ? "enabled" : "disabled");
            xSemaphoreGiveFromISR(xButtonSemaphore, &xHigherPriorityTaskWoken);
        }
        g_ui32TimeStamp = xTaskGetTickCount();
    }
    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

static void prvSensorReadTask(void *pvParameters)
{
    bool success;
    uint16_t rawData = 0;
    float convertedLux = 0;

    /* Debug: Check I2C bus state before starting */
    prvDebugI2CBusState();

    /* Initialize the OPT3001 sensor */
    sensorOpt3001Init();

    /* Add a delay to ensure the sensor is ready (per datasheet recommendation) */
    vTaskDelay(pdMS_TO_TICKS(500)); /* 500ms delay after power-up */

    /* Test the defined slave address (0x47) */
    {
        uint16_t val;

        // Check manufacturer ID
        readI2C(OPT3001_I2C_ADDRESS, REG_MANUFACTURER_ID, (uint8_t *)&val);
        val = (val >> 8) | (val << 8);
        UARTprintf("Manufacturer ID Read: 0x%04x (Expected: 0x5449)\n", val);

        // Check device ID
        readI2C(OPT3001_I2C_ADDRESS, REG_DEVICE_ID, (uint8_t *)&val);
        val = (val >> 8) | (val << 8);
        UARTprintf("Device ID Read: 0x%04x (Expected: 0x3001)\n", val);
    }

    /* Test that the sensor is set up correctly */
    success = sensorOpt3001Test();

    /* Stay here until the sensor is working */
    while (!success)
    {
        vTaskDelay(pdMS_TO_TICKS(1000)); /* Delay 1 second before retrying */
        UARTprintf("Test Failed, Trying again\n");
        success = sensorOpt3001Test();
    }

    UARTprintf("All Tests Passed!\n\n");

    /* Loop forever to handle sensor reading */
    for (;;)
    {
        /* Wait for a button press to start reading */
        xSemaphoreTake(xButtonSemaphore, portMAX_DELAY);

        /* Continuously read while enabled */
        while (g_bSensorReadingEnabled)
        {
            /* Read and convert OPT3001 values */
            success = sensorOpt3001Read(&rawData);

            if (success)
            {
                sensorOpt3001Convert(rawData, &convertedLux);

                /* Construct and print the lux value */
                int lux_int = (int)convertedLux;
                UARTprintf("Lux: %5d\n", lux_int);
            }
            else
            {
                UARTprintf("Sensor read failed\n");
            }

            /* Delay for 100ms to match the original demo's timing */
            vTaskDelay(pdMS_TO_TICKS(100));

            /* Check if a button press occurred to stop reading */
            if (xSemaphoreTake(xButtonSemaphore, 0) == pdTRUE)
            {
                /* Semaphore was given, meaning the button was pressed to toggle */
                break; /* Exit the reading loop */
            }
        }
    }
}