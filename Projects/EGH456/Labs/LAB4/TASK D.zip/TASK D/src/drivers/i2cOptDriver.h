/**************************************************************************************************
 *  Filename:       i2cOptDriver.h
 *  By:             Jesse Haviland
 *  Created:        1 February 2019
 *  Revised:        23 March 2019
 *  Revision:       2.0
 *
 *  Description:    Header for i2c Driver for use with opt3001.c and the TI OP3001 Optical Sensor
 *************************************************************************************************/

#ifndef I2COPTDRIVER_H
#define I2COPTDRIVER_H

#include <stdbool.h>
#include <stdint.h>

void i2cOptDriverInit(void); /* Added: Initialize semaphore and interrupts */
bool writeI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data);
bool readI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data);
void I2C0IntHandler(void); /* Added: ISR for I2C0 interrupts */

#endif /* I2COPTDRIVER_H */