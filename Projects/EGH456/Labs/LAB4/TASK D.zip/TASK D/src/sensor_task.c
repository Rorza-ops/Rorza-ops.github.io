#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "FreeRTOS.h"
#include "task.h"
#include "semphr.h"
#include "driverlib/sysctl.h"
#include "drivers/opt3001.h"
#include "drivers/i2cOptDriver.h"
#include "utils/uartstdio.h"
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/gpio.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "driverlib/i2c.h"
#include "driverlib/interrupt.h"
#include "drivers/rtos_hw_drivers.h"

/* Define constants matching the values in opt3001.c, as they are not exposed in opt3001.h */
#define OPT3001_I2C_ADDRESS 0x47
#define REG_MANUFACTURER_ID 0x7E
#define REG_DEVICE_ID 0x7F
#define REG_CONFIGURATION 0x01
#define REG_RESULT 0x00
#define REG_LOW_LIMIT 0x02
#define REG_HIGH_LIMIT 0x03

/* Configuration register flags */
#define FLAG_HIGH 0x0040    // Bit 6: FH
#define FLAG_LOW 0x0020     // Bit 5: FL
#define DATA_RDY_BIT 0x0080 // Bit 7: CRF (data ready)

extern uint32_t g_ui32SysClock;

/* Declare the semaphore as extern, defined in main.c */
extern SemaphoreHandle_t xLightEventSemaphore;

static void prvSensorReadTask(void *pvParameters);
static void prvConfigureUART(void);
static void prvConfigureInterruptPin(void);

void vCreateSensorTask(void)
{
    /* Configure UART before creating the task */
    prvConfigureUART();

    /* Ensure the semaphore exists */
    if (xLightEventSemaphore == NULL)
    {
        UARTprintf("Light event semaphore not available\n");
        while (1)
            ; /* Fatal error */
    }

    /* Configure the interrupt pin (PF0) */
    prvConfigureInterruptPin();

    /* Create the sensor read task with larger stack size */
    xTaskCreate(prvSensorReadTask, "SensorRead", 512, NULL, tskIDLE_PRIORITY + 1, NULL);
}

static void prvConfigureUART(void)
{
    /* Enable GPIO port A which is used for UART0 pins */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Configure the pin muxing for UART0 functions on port A0 and A1 */
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    /* Enable UART0 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Use the system clock for UART */
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_SYSTEM);

    /* Select the alternate (UART) function for these pins */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    /* Initialize the UART for console I/O */
    UARTStdioConfig(0, 9600, g_ui32SysClock);

    /* Small delay to ensure UART is ready */
    SysCtlDelay(g_ui32SysClock); /* ~1 second delay at 120MHz */
}

static void prvConfigureInterruptPin(void)
{
    /* Enable GPIO Port F */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOF);

    /* Configure PF0 as input with pull-up resistor */
    GPIOPinTypeGPIOInput(GPIO_PORTF_BASE, GPIO_PIN_0);
    GPIOPadConfigSet(GPIO_PORTF_BASE, GPIO_PIN_0, GPIO_STRENGTH_2MA, GPIO_PIN_TYPE_STD_WPU);

    /* Configure interrupt on falling edge */
    GPIOIntTypeSet(GPIO_PORTF_BASE, GPIO_PIN_0, GPIO_FALLING_EDGE);

    /* Enable the interrupt for PF0 in the GPIO peripheral */
    GPIOIntEnable(GPIO_PORTF_BASE, GPIO_PIN_0);

    /* Set interrupt priority to be safe for FreeRTOS API calls */
    IntPrioritySet(INT_GPIOF, 0xE0); // Priority 7 (lowest)

    /* Enable the Port F interrupt in the NVIC */
    IntEnable(INT_GPIOF);

    /* Enable global interrupts in the NVIC */
    IntMasterEnable();
}

/* ISR for OPT3001 INT pin (PF0) */
void LightEventHandler(void)
{
    BaseType_t xHigherPriorityTaskWoken = pdFALSE;

    /* Clear the interrupt */
    GPIOIntClear(GPIO_PORTF_BASE, GPIO_PIN_0);

    /* Debug print to confirm ISR is triggered */
    UARTprintf("INT pin triggered\n");

    /* Signal the task to process the light event */
    xSemaphoreGiveFromISR(xLightEventSemaphore, &xHigherPriorityTaskWoken);

    portYIELD_FROM_ISR(xHigherPriorityTaskWoken);
}

static void prvSensorReadTask(void *pvParameters)
{
    bool success;
    uint16_t rawData = 0;
    float convertedLux = 0;
    float lastValidLux = 0; /* Store the last valid lux value */

    /* Manually configure the OPT3001 sensor */
    uint8_t config_data[2] = {0xCC, 0xCA}; // 0xCACC (RN=0xC, CT=1, M=11, L=1, POL=1, FC=00), sent LSB-first
    if (!writeI2C(OPT3001_I2C_ADDRESS, REG_CONFIGURATION, config_data))
    {
        UARTprintf("Failed to configure OPT3001\n");
        while (1)
            ;
    }

    /* Manually set the low and high limit registers with correct byte order */
    uint8_t low_limit_data[2] = {0x0F, 0xFF}; // 0x0FFF (E=0, M=4095 for 40.95 lux)
    if (!writeI2C(OPT3001_I2C_ADDRESS, REG_LOW_LIMIT, low_limit_data))
    {
        UARTprintf("Failed to set low limit\n");
        while (1)
            ;
    }

    uint8_t high_limit_data[2] = {0x07, 0xA1}; // 0x7A1 (E=7, M=1953 for 2500 lux)
    if (!writeI2C(OPT3001_I2C_ADDRESS, REG_HIGH_LIMIT, high_limit_data))
    {
        UARTprintf("Failed to set high limit\n");
        while (1)
            ;
    }

    /* Add a delay to ensure the sensor completes its first conversion */
    vTaskDelay(pdMS_TO_TICKS(1500)); /* 1500ms delay to allow first conversion and interrupt */

    /* Test the defined slave address (0x47) */
    {
        uint16_t val;

        // Check manufacturer ID
        readI2C(OPT3001_I2C_ADDRESS, REG_MANUFACTURER_ID, (uint8_t *)&val);
        val = (val >> 8) | (val << 8);
        UARTprintf("Manufacturer ID Read: 0x%04x (Expected: 0x5449)\n", val);

        // Check device ID
        readI2C(OPT3001_I2C_ADDRESS, REG_DEVICE_ID, (uint8_t *)&val);
        val = (val >> 8) | (val << 8);
        UARTprintf("Device ID Read: 0x%04x (Expected: 0x3001)\n", val);
    }

    /* Test that the sensor is set up correctly */
    UARTprintf("Testing OPT3001 Sensor:\n");
    success = sensorOpt3001Test();

    /* Stay here until the sensor is working */
    while (!success)
    {
        vTaskDelay(pdMS_TO_TICKS(1000)); /* Delay 1 second before retrying */
        UARTprintf("Test Failed, Trying again\n");
        success = sensorOpt3001Test();
    }

    UARTprintf("All Tests Passed!\n\n");

    /* Small delay to allow SerialPlot to connect before data streaming */
    vTaskDelay(pdMS_TO_TICKS(2000)); /* 2-second delay */

    /* Continuously read and output lux values */
    for (;;)
    {
        /* Read and convert OPT3001 values */
        bool data_ready = false;
        uint16_t val;
        int retries = 5; // Retry up to 5 times

        // Retry until data is ready or retries are exhausted
        while (retries > 0 && !data_ready)
        {
            if (readI2C(OPT3001_I2C_ADDRESS, REG_CONFIGURATION, (uint8_t *)&val))
            {
                // Convert from little-endian if necessary
                val = (val >> 8) | (val << 8);

                // DATA_RDY is bit 7 of LSB
                data_ready = (val & DATA_RDY_BIT) != 0;

                // Check for interrupt flags (FH or FL) and clear them by reading result
                if (val & (FLAG_HIGH | FLAG_LOW))
                {
                    uint16_t dummy;
                    readI2C(OPT3001_I2C_ADDRESS, REG_RESULT, (uint8_t *)&dummy); // Clear interrupt
                }
            }
            else
            {
                UARTprintf("Failed to read configuration register\n");
                break;
            }

            if (!data_ready)
            {
                // Wait 200 ms before retrying (800 ms total conversion time)
                vTaskDelay(pdMS_TO_TICKS(200));
                retries--;
            }
        }

        if (data_ready)
        {
            if (readI2C(OPT3001_I2C_ADDRESS, REG_RESULT, (uint8_t *)&val))
            {
                // Swap bytes (big-endian to little-endian)
                rawData = (val >> 8) | (val << 8);
                sensorOpt3001Convert(rawData, &convertedLux);
                if (convertedLux < 0)
                {
                    convertedLux = 0;
                }
                lastValidLux = convertedLux; /* Update the last valid value */
            }
            else
            {
                UARTprintf("Failed to read result register\n");
                convertedLux = lastValidLux; /* Use the last valid value */
            }
        }

        /* Convert lux to integer representation (lux * 100) */
        uint32_t luxScaled = (uint32_t)(convertedLux * 100);
        uint32_t luxWhole = luxScaled / 100;
        uint32_t luxFraction = luxScaled % 100;

        /* Check lux value against thresholds and print event messages */
        if (convertedLux < 40.95)
        {
            UARTprintf("Low Light Event: %d.%02d Lux\n", luxWhole, luxFraction);
        }
        else if (convertedLux > 500.0)
        {
            UARTprintf("High Light Event: %d.%02d Lux\n", luxWhole, luxFraction);
        }

        /* Normal output */
        UARTprintf("%d.%02d Lux\n", luxWhole, luxFraction);
    }
}