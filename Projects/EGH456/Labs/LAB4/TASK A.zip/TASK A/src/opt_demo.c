#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "inc/hw_memmap.h"
#include "inc/hw_ints.h"
#include "driverlib/debug.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/pin_map.h"
#include "driverlib/rom.h"
#include "driverlib/sysctl.h"
#include "driverlib/uart.h"
#include "driverlib/i2c.h"
#include "utils/uartstdio.h"
#include "utils/ustdlib.h"
#include "drivers/bmi160.h"

#define SYSTICKS_PER_SECOND 1
#define SYSTICK_PERIOD_MS (1000 / SYSTICKS_PER_SECOND)

volatile uint32_t g_ui32SysClock;

#ifdef DEBUG
void __error__(char *pcFilename, uint32_t ui32Line) {}
#endif

void ConfigureUART(void)
{
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);
    UARTStdioConfig(0, 9600, g_ui32SysClock);
    SysCtlDelay(g_ui32SysClock);
}

void scanI2CAddresses(void)
{
    UARTprintf("Scanning I2C addresses...\n");
    uint8_t testAddresses[] = {0x47, 0x68, 0x69};
    for (uint8_t i = 0; i < sizeof(testAddresses); i++)
    {
        uint8_t addr = testAddresses[i];
        I2CMasterSlaveAddrSet(I2C0_BASE, addr, false);
        I2CMasterDataPut(I2C0_BASE, 0x00);
        I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND);
        SysCtlDelay(g_ui32SysClock / 10000);
        while (I2CMasterBusy(I2C0_BASE))
        {
        }
        uint32_t err = I2CMasterErr(I2C0_BASE);
        if (err == I2C_MASTER_ERR_NONE)
        {
            UARTprintf("Device found at address: 0x%02x\n", addr);
        }
        else
        {
            UARTprintf("No device at address: 0x%02x (err=0x%04x)\n", addr, err);
        }
        SysCtlDelay(g_ui32SysClock / 10000);
    }
    UARTprintf("Scan complete\n");
}

int main(void)
{
    bool success;
    int16_t accelData[3];
    float absAccel = 0;

    // Configure system clock
    g_ui32SysClock = SysCtlClockFreqSet((SYSCTL_XTAL_25MHZ |
                                         SYSCTL_OSC_MAIN | SYSCTL_USE_PLL |
                                         SYSCTL_CFG_VCO_480),
                                        120000000);

    // Initialize UART
    ConfigureUART();
    UARTprintf("BMI160 Absolute Acceleration Example\n");

    // Reset I2C0 peripheral
    SysCtlPeripheralReset(SYSCTL_PERIPH_I2C0);
    SysCtlDelay(g_ui32SysClock / 1000);

    // Enable I2C0 peripheral
    SysCtlPeripheralEnable(SYSCTL_PERIPH_I2C0);
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOB);

    // Wait for peripherals
    while (!SysCtlPeripheralReady(SYSCTL_PERIPH_I2C0) || !SysCtlPeripheralReady(SYSCTL_PERIPH_GPIOB))
    {
        UARTprintf("Waiting for I2C0/GPIOB to be ready\n");
        SysCtlDelay(g_ui32SysClock / 100);
    }

    // Configure I2C pins
    GPIOPinConfigure(GPIO_PB2_I2C0SCL);
    GPIOPinConfigure(GPIO_PB3_I2C0SDA);
    GPIOPinTypeI2CSCL(GPIO_PORTB_BASE, GPIO_PIN_2);
    GPIOPinTypeI2C(GPIO_PORTB_BASE, GPIO_PIN_3);

    // Initialize I2C master (100 kHz)
    I2CMasterInitExpClk(I2C0_BASE, g_ui32SysClock, false);
    UARTprintf("I2C Initialized\n");

    // Scan I2C addresses
    scanI2CAddresses();

    // Initialize sensor
    UARTprintf("Initializing BMI160 at 0x%02x...\n", BMI160_I2C_ADDRESS);
    success = sensorBmi160Init();
    if (!success)
    {
        UARTprintf("BMI160 initialization failed at 0x%02x\n", BMI160_I2C_ADDRESS);
        // Try alternative address (0x69)
        UARTprintf("Trying address 0x69...\n");
#undef BMI160_I2C_ADDRESS
#define BMI160_I2C_ADDRESS 0x69
        success = sensorBmi160Init();
        if (!success)
        {
            UARTprintf("BMI160 initialization failed at 0x69\n");
            while (1)
            {
                UARTprintf("Initialization failed. Check BMI160 power, SA0 pin, or replace BoosterPack.\n");
                SysCtlDelay(g_ui32SysClock);
            }
        }
    }

    // Test sensor
    UARTprintf("Testing BMI160 Sensor:\n");
    success = sensorBmi160Test();
    while (!success)
    {
        SysCtlDelay(g_ui32SysClock);
        UARTprintf("Test Failed, Trying again\n");
        success = sensorBmi160Test();
    }
    UARTprintf("All Tests Passed!\n\n");

    // Loop forever
    while (1)
    {
        SysCtlDelay(g_ui32SysClock / 50); // ~20ms, 50 Hz polling

        success = sensorBmi160ReadAccel(accelData);
        if (success)
        {
            UARTprintf("Raw Accel: X=%d, Y=%d, Z=%d\n", accelData[0], accelData[1], accelData[2]);
            sensorBmi160ConvertAccel(accelData, &absAccel);
            int centi_g = (int)(absAccel * 100);
            UARTprintf("Absolute Acceleration: %d.%02d g\n", centi_g / 100, centi_g % 100);
        }
        else
        {
            UARTprintf("Failed to read accelerometer data\n");
        }
    }
}