#include "i2cOptDriver.h"
#include "inc/hw_memmap.h"
#include "driverlib/i2c.h"
#include "utils/uartstdio.h"
#include "driverlib/sysctl.h"

bool writeI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data)
{
    uint8_t retries = 3;
    uint32_t err;

    while (retries--)
    {
        // Send register address
        I2CMasterSlaveAddrSet(I2C0_BASE, ui8Addr, false);
        I2CMasterDataPut(I2C0_BASE, ui8Reg);
        I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_START);
        while (I2CMasterBusy(I2C0_BASE))
        {
        }

        err = I2CMasterErr(I2C0_BASE);
        if (err == I2C_MASTER_ERR_NONE)
        {
            break;
        }
        UARTprintf("I2C Write Error (reg, addr=0x%02x, reg=0x%02x): 0x%04x\n", ui8Addr, ui8Reg, err);
        SysCtlDelay(100000); // Brief delay before retry
    }
    if (err != I2C_MASTER_ERR_NONE)
    {
        return false;
    }

    // Send first data byte
    I2CMasterDataPut(I2C0_BASE, data[0]);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_CONT);
    while (I2CMasterBusy(I2C0_BASE))
    {
    }

    err = I2CMasterErr(I2C0_BASE);
    if (err != I2C_MASTER_ERR_NONE)
    {
        UARTprintf("I2C Write Error (data[0], addr=0x%02x, reg=0x%02x): 0x%04x\n", ui8Addr, ui8Reg, err);
        return false;
    }

    // Send second data byte
    I2CMasterDataPut(I2C0_BASE, data[1]);
    I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_SEND_FINISH);
    while (I2CMasterBusBusy(I2C0_BASE))
    {
    }

    err = I2CMasterErr(I2C0_BASE);
    if (err != I2C_MASTER_ERR_NONE)
    {
        UARTprintf("I2C Write Error (data[1], addr=0x%02x, reg=0x%02x): 0x%04x\n", ui8Addr, ui8Reg, err);
        return false;
    }

    return true;
}

bool readI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data, uint8_t length)
{
    uint8_t retries = 3;
    uint32_t err;

    while (retries--)
    {
        I2CMasterSlaveAddrSet(I2C0_BASE, ui8Addr, false);
        I2CMasterDataPut(I2C0_BASE, ui8Reg);
        I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_SINGLE_SEND);
        while (I2CMasterBusy(I2C0_BASE))
        {
        }

        err = I2CMasterErr(I2C0_BASE);
        if (err == I2C_MASTER_ERR_NONE)
        {
            break;
        }
        UARTprintf("I2C Write Error (reg, addr=0x%02x, reg=0x%02x): 0x%04x\n", ui8Addr, ui8Reg, err);
        SysCtlDelay(100000);
    }
    if (err != I2C_MASTER_ERR_NONE)
    {
        return false;
    }

    I2CMasterSlaveAddrSet(I2C0_BASE, ui8Addr, true);
    for (uint8_t i = 0; i < length; i++)
    {
        if (i == 0)
        {
            I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_START);
        }
        else if (i == length - 1)
        {
            I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_FINISH);
        }
        else
        {
            I2CMasterControl(I2C0_BASE, I2C_MASTER_CMD_BURST_RECEIVE_CONT);
        }
        while (I2CMasterBusy(I2C0_BASE))
        {
        }
        data[i] = I2CMasterDataGet(I2C0_BASE);
    }

    err = I2CMasterErr(I2C0_BASE);
    if (err != I2C_MASTER_ERR_NONE)
    {
        UARTprintf("I2C Read Error (addr=0x%02x, reg=0x%02x): 0x%04x\n", ui8Addr, ui8Reg, err);
        return false;
    }

    return true;
}