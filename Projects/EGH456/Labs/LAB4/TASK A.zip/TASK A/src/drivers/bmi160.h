#ifndef BMI160_H
#define BMI160_H

#include <stdbool.h>
#include <stdint.h>

#define BMI160_I2C_ADDRESS 0x68 // Try 0x68 (SA0 = 0); fallback to 0x69 in code

extern bool sensorBmi160Init(void);
extern void sensorBmi160Enable(bool enable);
extern bool sensorBmi160ReadAccel(int16_t *accelData);
extern void sensorBmi160ConvertAccel(int16_t *accelData, float *absAccel);
extern bool sensorBmi160Test(void);

#endif /* BMI160_H */