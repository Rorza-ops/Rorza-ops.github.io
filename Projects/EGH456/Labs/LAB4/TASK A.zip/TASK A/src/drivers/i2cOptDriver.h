#ifndef _I2COPTDRIVER_H_
#define _I2COPTDRIVER_H_

#include <stdbool.h>
#include <stdint.h>

extern bool writeI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data);
extern bool readI2C(uint8_t ui8Addr, uint8_t ui8Reg, uint8_t *data, uint8_t length);

#endif /* _I2COPTDRIVER_H_ */