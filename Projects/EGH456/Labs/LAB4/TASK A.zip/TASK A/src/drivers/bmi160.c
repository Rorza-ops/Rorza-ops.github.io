#include "bmi160.h"
#include "i2cOptDriver.h"
#include "utils/uartstdio.h"
#include <math.h>
#include "driverlib/sysctl.h"

// Register addresses
#define REG_CHIP_ID 0x00
#define REG_ACCEL_CONFIG 0x40
#define REG_ACCEL_RANGE 0x41
#define REG_ACCEL_DATA_X_LSB 0x12
#define REG_PMU_STATUS 0x03
#define REG_CMD 0x7E
#define REG_STATUS 0x1B

// Register values
#define CHIP_ID 0xD1
#define ACCEL_NORMAL_MODE 0x11 // Normal mode
#define ACCEL_RANGE_4G 0x05	   // ±4g range
#define CMD_SOFT_RESET 0xB6	   // Soft reset

bool sensorBmi160Init(void)
{
	uint8_t data[2];
	uint8_t status[1];
	uint8_t retries;

	// Check chip ID first
	if (!sensorBmi160Test())
	{
		UARTprintf("Chip ID test failed\n");
		return false;
	}

	// Soft reset
	retries = 3;
	while (retries--)
	{
		data[0] = CMD_SOFT_RESET;
		if (writeI2C(BMI160_I2C_ADDRESS, REG_CMD, data))
		{
			break;
		}
		UARTprintf("Soft reset failed, retrying...\n");
		SysCtlDelay(100000);
	}
	if (retries == 0)
	{
		UARTprintf("Soft reset failed after retries\n");
		return false;
	}
	SysCtlDelay(1000000); // ~100ms delay

	// Check PMU status after reset
	if (!readI2C(BMI160_I2C_ADDRESS, REG_PMU_STATUS, status, 1))
	{
		UARTprintf("Failed to read PMU status after reset\n");
		return false;
	}
	UARTprintf("PMU status after reset: 0x%02x\n", status[0]);

	// Set accelerometer to normal mode
	retries = 3;
	while (retries--)
	{
		data[0] = ACCEL_NORMAL_MODE;
		if (writeI2C(BMI160_I2C_ADDRESS, REG_CMD, data))
		{
			break;
		}
		UARTprintf("Failed to set normal mode, retrying...\n");
		SysCtlDelay(100000);
	}
	if (retries == 0)
	{
		UARTprintf("Failed to set normal mode after retries\n");
		return false;
	}
	SysCtlDelay(1000000); // ~100ms delay

	// Check PMU status after mode change
	if (!readI2C(BMI160_I2C_ADDRESS, REG_PMU_STATUS, status, 1))
	{
		UARTprintf("Failed to read PMU status after mode change\n");
		return false;
	}
	if ((status[0] & 0x10) != 0x10)
	{
		UARTprintf("Accelerometer not in normal mode after mode change: 0x%02x\n", status[0]);
		return false;
	}

	// Configure accelerometer: 100 Hz ODR
	data[0] = 0x28; // ODR = 100 Hz (0b1000)
	retries = 3;
	while (retries--)
	{
		if (writeI2C(BMI160_I2C_ADDRESS, REG_ACCEL_CONFIG, data))
		{
			break;
		}
		UARTprintf("Failed to configure accelerometer, retrying...\n");
		SysCtlDelay(100000);
	}
	if (retries == 0)
	{
		UARTprintf("Failed to configure accelerometer after retries\n");
		return false;
	}
	// Verify write
	if (!readI2C(BMI160_I2C_ADDRESS, REG_ACCEL_CONFIG, status, 1))
	{
		UARTprintf("Failed to read ACCEL_CONFIG\n");
		return false;
	}
	if (status[0] != 0x28)
	{
		UARTprintf("ACCEL_CONFIG mismatch: 0x%02x\n", status[0]);
		return false;
	}

	// Set range to ±4g
	data[0] = ACCEL_RANGE_4G;
	retries = 3;
	while (retries--)
	{
		if (writeI2C(BMI160_I2C_ADDRESS, REG_ACCEL_RANGE, data))
		{
			break;
		}
		UARTprintf("Failed to set range, retrying...\n");
		SysCtlDelay(100000);
	}
	if (retries == 0)
	{
		UARTprintf("Failed to set range after retries\n");
		return false;
	}
	// Verify write
	if (!readI2C(BMI160_I2C_ADDRESS, REG_ACCEL_RANGE, status, 1))
	{
		UARTprintf("Failed to read ACCEL_RANGE\n");
		return false;
	}
	if (status[0] != ACCEL_RANGE_4G)
	{
		UARTprintf("ACCEL_RANGE mismatch: 0x%02x\n", status[0]);
		return false;
	}

	// Final PMU status check
	if (!readI2C(BMI160_I2C_ADDRESS, REG_PMU_STATUS, status, 1))
	{
		UARTprintf("Failed to read final PMU status\n");
		return false;
	}
	if ((status[0] & 0x10) != 0x10)
	{
		UARTprintf("Accelerometer not in normal mode: 0x%02x\n", status[0]);
		return false;
	}

	sensorBmi160Enable(true);
	return true;
}

void sensorBmi160Enable(bool enable)
{
	uint8_t data[2];
	data[0] = enable ? ACCEL_NORMAL_MODE : 0x00;
	writeI2C(BMI160_I2C_ADDRESS, REG_CMD, data);
}

bool sensorBmi160ReadAccel(int16_t *accelData)
{
	uint8_t rawData[6] = {0};
	accelData[0] = accelData[1] = accelData[2] = 0;

	// Check data ready
	uint8_t status[1];
	if (!readI2C(BMI160_I2C_ADDRESS, REG_STATUS, status, 1))
	{
		UARTprintf("Failed to read status\n");
		return false;
	}
	if (!(status[0] & 0x40))
	{
		UARTprintf("Data not ready\n");
		return false;
	}

	// Read 6 bytes
	if (!readI2C(BMI160_I2C_ADDRESS, REG_ACCEL_DATA_X_LSB, rawData, 6))
	{
		UARTprintf("Failed to read accelerometer data\n");
		return false;
	}

	// Combine LSB and MSB
	accelData[0] = (int16_t)((rawData[1] << 8) | rawData[0]); // X-axis
	accelData[1] = (int16_t)((rawData[3] << 8) | rawData[2]); // Y-axis
	accelData[2] = (int16_t)((rawData[5] << 8) | rawData[4]); // Z-axis

	return true;
}

void sensorBmi160ConvertAccel(int16_t *accelData, float *absAccel)
{
	float ax = accelData[0] / 8192.0f;
	float ay = accelData[1] / 8192.0f;
	float az = accelData[2] / 8192.0f;
	*absAccel = sqrtf(ax * ax + ay * ay + az * az);
	if (*absAccel != *absAccel)
	{
		UARTprintf("Invalid absAccel: NaN\n");
		*absAccel = 0.0f;
	}
}

bool sensorBmi160Test(void)
{
	uint8_t chipId;
	if (!readI2C(BMI160_I2C_ADDRESS, REG_CHIP_ID, &chipId, 1))
	{
		UARTprintf("Chip ID read failed\n");
		return false;
	}
	if (chipId != CHIP_ID)
	{
		UARTprintf("Chip ID Incorrect: 0x%02x\n", chipId);
		return false;
	}
	UARTprintf("Chip ID Correct: 0x%02x\n", chipId);
	return true;
}