/* --------------------------------------------------------------------------
 *  queue_task.c  –  Task-C
 * -------------------------------------------------------------------------*/
#include <stdarg.h>
#include <stdbool.h>
#include <stdint.h>

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"
#include "utils/uartstdio.h"

/* Hardware includes. */
#include "inc/hw_ints.h"
#include "inc/hw_memmap.h"
#include "driverlib/sysctl.h"
#include "driverlib/gpio.h"
#include "driverlib/interrupt.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include "drivers/opt3001.h"
#include "drivers/i2cOptDriver.h"
#include "drivers/rtos_hw_drivers.h"
#include "grlib.h"
#include "drivers/Kentec320x240x16_ssd2119_spi.h"

#include "event_groups.h"

/* --------------------------------------------------------------------------
 *  Globals & RTOS objects
 * -------------------------------------------------------------------------*/
#define FILTER_SIZE 5
#define PLOT_BUFFER_SIZE 320 /* one pixel per reading (10 s) */

/* --- event bits ------------------------------------------------------- */
#define EVT_HIGH (1 << 0)
#define EVT_LOW (1 << 1)
#define EVT_TGL (1 << 2)

/* --- high/low thresholds (lux) ----------------------------------- */
#define HIGH_LUX 500.0f
#define LOW_LUX 40.0f

typedef struct
{
    float rawLux;
    float filtLux;
    uint32_t ts;
} SensorMessage;

static QueueHandle_t xSensorQ;
static SemaphoreHandle_t xUART;

static tContext gCtx;

/* event group handle */
static EventGroupHandle_t xEvt;

extern SemaphoreHandle_t xButtonSemaphore;

static uint32_t g_ui32TimeStamp = 0;

/* --------------------------------------------------------------------------
 *  Forward decl.
 * -------------------------------------------------------------------------*/
static void vSensorSamplingTask(void *p);
static void vDisplayTask(void *p);

// static void xButtonsHandler(void *p);

/* --------------------------------------------------------------------------
 *  Public API called from main()
 * -------------------------------------------------------------------------*/
void vcreateQueueTasks(void)
{
    /* --- Create RTOS objects ------------------------------------------ */
    xSensorQ = xQueueCreate(10, sizeof(SensorMessage));
    xUART = xSemaphoreCreateMutex();
    xEvt = xEventGroupCreate();
    configASSERT(xEvt); /* stop here if allocation fails */

    /* --- Init LCD once ------------------------------------------------- */
    Kentec320x240x16_SSD2119Init(configCPU_CLOCK_HZ);
    GrContextInit(&gCtx, &g_sKentec320x240x16_SSD2119);
    GrContextForegroundSet(&gCtx, ClrBlack);
    GrRectFill(&gCtx,
               &(tRectangle){0, 0,
                             GrContextDpyWidthGet(&gCtx) - 1,
                             GrContextDpyHeightGet(&gCtx) - 1});

    /* --- Create tasks -------------------------------------------------- */
    xTaskCreate(vSensorSamplingTask, "SNS", configMINIMAL_STACK_SIZE + 120,
                NULL, tskIDLE_PRIORITY + 2, NULL);
    xTaskCreate(vDisplayTask, "LCD", configMINIMAL_STACK_SIZE + 200,
                NULL, tskIDLE_PRIORITY + 3, NULL);
}

/* --------------------------------------------------------------------------
 *  Safe printf
 * -------------------------------------------------------------------------*/
static void safeUART(const char *fmt, ...)
{
    va_list ap;
    va_start(ap, fmt);
    if (xSemaphoreTake(xUART, (TickType_t)10))
    {
        UARTvprintf(fmt, ap);
        xSemaphoreGive(xUART);
    }
    va_end(ap);
}

// Interrupt Handler for Button Press
void xButtonsHandler(void)
{
    BaseType_t xToggleTaskWoken;
    uint32_t ui32Status;

    // print out the button press
    // safeUART("Button Pressed\r\n");

    // Initialize the semaphore
    xToggleTaskWoken = pdFALSE;

    // Read the buttons interrupt status to find the cause of the interrupt.
    ui32Status = GPIOIntStatus(BUTTONS_GPIO_BASE, true);

    // Clear the interrupt
    GPIOIntClear(BUTTONS_GPIO_BASE, ui32Status);

    // Debounce the input with 200ms filter
    if ((xTaskGetTickCount() - g_ui32TimeStamp) > 200)
    {
        // Log which button was pressed to trigger the ISR.
        if ((ui32Status & USR_SW1) == USR_SW1)
        {
            // Give the semaphore to unblock prvProcessSwitchInputTask.
            xSemaphoreGiveFromISR(xButtonSemaphore, &xToggleTaskWoken);
            safeUART("Button 1 pressed\r\n");

            // EventBits_t bits = xEventGroupGetBits(xEvt);
            // bits = bits&EVT_TGL;
            EventBits_t bits = xEventGroupGetBits(xEvt);
            if (bits & EVT_TGL)
            {
                xEventGroupClearBits(xEvt, EVT_TGL);
            }
            else
            {
                xEventGroupSetBits(xEvt, EVT_TGL);
            }
        }

        // This FreeRTOS API call will handle the context switch if it is required or have no effect if that is not needed. */
        portYIELD_FROM_ISR(xToggleTaskWoken);
    }

    /* Update the time stamp. */
    g_ui32TimeStamp = xTaskGetTickCount();
}

/* --------------------------------------------------------------------------
 *  Sensor Sampling Task
 * -------------------------------------------------------------------------*/

/* Helper Function */
bool sensorOpt3001ReadLux(float *pLux)
/* Returns true on success, false on I²C error. */
{
    uint16_t raw;
    if (readI2C(0x47, 0x00, (uint8_t *)&raw)) /* REG_RESULT = 0x00 */
    {
        raw = (raw >> 8) | (raw << 8);   /* endian swap       */
        sensorOpt3001Convert(raw, pLux); /* driver function   */
        if (*pLux < 0)
            *pLux = 0; /* clamp negative    */
        return true;
    }
    return false;
}

static void vSensorSamplingTask(void *p)
{
    const uint8_t I2C_ADDR = 0x47;
    float buf[FILTER_SIZE] = {0}, sum = 0;
    int idx = 0;
    TickType_t last = xTaskGetTickCount();
    SensorMessage msg;

    sensorOpt3001Init();
    for (;;)
    {
        uint16_t raw;
        float lux = 0;

        if (sensorOpt3001ReadLux(&lux) == false)
            lux = buf[(idx - 1) & (FILTER_SIZE - 1)];

        /* --- moving average ------------------------------------------ */
        sum -= buf[idx];
        sum += lux;
        buf[idx] = lux;
        idx = (idx + 1) % FILTER_SIZE;

        /* ---- HIGH / LOW threshold detection ------------------------- */
        if (msg.rawLux > HIGH_LUX)
            // set high event bit
            xEventGroupSetBits(xEvt, EVT_HIGH);
        else if (msg.rawLux < LOW_LUX)
            // set low event bit
            xEventGroupSetBits(xEvt, EVT_LOW);

        msg.rawLux = lux;
        msg.filtLux = sum / FILTER_SIZE;
        msg.ts = xTaskGetTickCount();

        xQueueSend(xSensorQ, &msg, (TickType_t)10);
        vTaskDelayUntil(&last, pdMS_TO_TICKS(100)); /* 10 Hz */
    }
}

/* --------------------------------------------------------------------------
 *  Display Task
 * -------------------------------------------------------------------------*/
static void vDisplayTask(void *p)
{
    uint16_t x = 0, yPrev = 239; /* start bottom-left */
    SensorMessage msg;

    for (;;)
    {
        if (xQueueReceive(xSensorQ, &msg, (TickType_t)10) == pdPASS)
        {
            /* ---- handle threshold warnings ------------------------------ */
            EventBits_t bits = xEventGroupGetBits(xEvt);

            if (bits & EVT_HIGH)
            {
                safeUART("WARNING: light too bright (>%d.%02d lux)\r\n", (int)msg.rawLux, (int)(msg.rawLux * 100) % 100);
                xEventGroupClearBits(xEvt, EVT_HIGH);
            }
            if (bits & EVT_LOW)
            {
                safeUART("WARNING: light too dim (<%d.%02d lux)\r\n", (int)msg.rawLux, (int)(msg.rawLux * 100) % 100);
                xEventGroupClearBits(xEvt, EVT_LOW);
            }

            /* Map 0-1000 lux  →  y = 200-40 px (flip for LCD coords) */
            float maxLux = 2000.0f;

            uint16_t y;

            if (bits & EVT_TGL)
            {
                // safeUART("Raw Mode\r\n");
                y = 200 - (uint16_t)((msg.rawLux / maxLux) * 160.0f);
                if (y > 200)
                    y = 200;
                if (y < 40)
                    y = 40;
            }
            if (!(bits & EVT_TGL))
            {
                // safeUART("Filtered Mode\r\n");
                y = 200 - (uint16_t)((msg.filtLux / maxLux) * 160.0f);
                if (y > 200)
                    y = 200;
                if (y < 40)
                    y = 40;
            }

            /* Draw vertical line segment --------------------------------*/
            GrContextForegroundSet(&gCtx, ClrWhite);
            GrLineDraw(&gCtx, x, yPrev, x + 1, y);
            yPrev = y;

            /* Wrap at right edge --------------------------------------- */
            x += 1;
            if (x >= PLOT_BUFFER_SIZE)
            {
                x = 0;
                /* clear plotting area */
                GrContextForegroundSet(&gCtx, ClrBlack);
                GrRectFill(&gCtx, &(tRectangle){0, 40, 500, 400});
            }
        }
    }
}
