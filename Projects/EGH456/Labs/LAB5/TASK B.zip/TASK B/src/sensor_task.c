#include <stdio.h>
#include <stdint.h>
#include <stdbool.h>
#include "FreeRTOS.h"
#include "task.h"
#include "timers.h"
#include "queue.h"
#include "driverlib/sysctl.h"
#include "drivers/opt3001.h"
#include "drivers/i2cOptDriver.h"
#include "utils/uartstdio.h"
#include "inc/hw_memmap.h"
#include "driverlib/uart.h"
#include "driverlib/pin_map.h"
#include <driverlib/gpio.h>

/* Structure to hold sensor data for queue transmission */
#ifndef SENSOR_DATA_H
#define SENSOR_DATA_H
struct SensorData
{
    uint16_t rawData;   /* Raw sensor reading */
    float filteredLux;  /* Filtered lux value */
    uint32_t timestamp; /* Timestamp in ticks */
};
#endif

/* Moving average filter parameters */
#define FILTER_SIZE 5
static float luxBuffer[FILTER_SIZE] = {0};
static uint8_t bufferIndex = 0;
static float luxSum = 0;

/* Timer handle for 10Hz sampling */
static TimerHandle_t xSensorTimer = NULL;

/* Extern queue handle defined in main.c */
extern QueueHandle_t xSensorDataQueue;
extern uint32_t g_ui32SysClock;

/* Function prototypes */
static void prvSensorReadTask(void *pvParameters);
static void prvDisplayTask(void *pvParameters);
static void prvConfigureUART(void);
static void prvSensorTimerCallback(TimerHandle_t xTimer);
static float prvApplyMovingAverage(float newLux);

/* Create the sensor and display tasks */
void vCreateSensorTask(void)
{
    /* Create the sensor read task */
    xTaskCreate(prvSensorReadTask, "SensorRead", 512, NULL, tskIDLE_PRIORITY + 1, NULL);
}

void vCreateDisplayTask(void)
{
    /* Configure UART before creating the display task */
    prvConfigureUART();

    /* Create the display task */
    xTaskCreate(prvDisplayTask, "Display", 256, NULL, tskIDLE_PRIORITY + 1, NULL);
}

static void prvConfigureUART(void)
{
    /* Enable GPIO port A which is used for UART0 pins */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_GPIOA);

    /* Configure the pin muxing for UART0 functions on port A0 and A1 */
    GPIOPinConfigure(GPIO_PA0_U0RX);
    GPIOPinConfigure(GPIO_PA1_U0TX);

    /* Enable UART0 */
    SysCtlPeripheralEnable(SYSCTL_PERIPH_UART0);

    /* Use the system clock for UART */
    UARTClockSourceSet(UART0_BASE, UART_CLOCK_SYSTEM);

    /* Select the alternate (UART) function for these pins */
    GPIOPinTypeUART(GPIO_PORTA_BASE, GPIO_PIN_0 | GPIO_PIN_1);

    /* Initialize the UART for console I/O */
    UARTStdioConfig(0, 9600, g_ui32SysClock);

    /* Small delay to ensure UART is ready */
    SysCtlDelay(g_ui32SysClock); /* ~1 second delay at 120MHz */
}

static void prvSensorReadTask(void *pvParameters)
{
    bool success;

    /* Initialize the OPT3001 sensor */
    success = sensorOpt3001Init();
    if (!success)
    {
        while (1)
            ; /* Fatal error */
    }

    /* Enable the sensor in continuous mode with 100ms conversion time */
    sensorOpt3001Enable(true);

    /* Test the sensor */
    success = sensorOpt3001Test();
    while (!success)
    {
        vTaskDelay(pdMS_TO_TICKS(1000)); /* Retry every 1 second */
        success = sensorOpt3001Test();
    }

    /* Create a timer for 10Hz sampling (100ms period) */
    xSensorTimer = xTimerCreate("SensorTimer", pdMS_TO_TICKS(100), pdTRUE, NULL, prvSensorTimerCallback);
    if (xSensorTimer == NULL)
    {
        while (1)
            ; /* Fatal error */
    }

    /* Start the timer */
    if (xTimerStart(xSensorTimer, 0) != pdPASS)
    {
        while (1)
            ; /* Fatal error */
    }

    /* Task can suspend itself as sampling is handled by the timer callback */
    vTaskSuspend(NULL);

    /* Should never reach here */
    for (;;)
        ;
}

static void prvSensorTimerCallback(TimerHandle_t xTimer)
{
    struct SensorData data;
    float lux;
    int retries = 3; /* Retry up to 3 times */
    bool readSuccess = false;

    /* Retry reading the sensor up to 3 times */
    while (retries > 0 && !readSuccess)
    {
        if (sensorOpt3001Read(&data.rawData))
        {
            /* Convert raw data to lux */
            sensorOpt3001Convert(data.rawData, &lux);
            readSuccess = true;
        }
        else
        {
            retries--;
            /* Small delay before retrying */
            vTaskDelay(pdMS_TO_TICKS(10));
        }
    }

    if (readSuccess)
    {
        /* Apply moving average filter */
        data.filteredLux = prvApplyMovingAverage(lux);
    }
    else
    {
        /* On failure after retries, use zero values */
        data.rawData = 0;
        data.filteredLux = 0;
    }

    /* Set timestamp */
    data.timestamp = xTaskGetTickCount();

    /* Send data to the queue */
    xQueueSend(xSensorDataQueue, &data, 0);
}

static float prvApplyMovingAverage(float newLux)
{
    /* Subtract the oldest value from the sum */
    luxSum -= luxBuffer[bufferIndex];

    /* Add the new value to the buffer and sum */
    luxBuffer[bufferIndex] = newLux;
    luxSum += newLux;

    /* Update the buffer index (circular buffer) */
    bufferIndex = (bufferIndex + 1) % FILTER_SIZE;

    /* Return the moving average */
    return luxSum / FILTER_SIZE;
}

static void prvDisplayTask(void *pvParameters)
{
    struct SensorData data;

    /* Small delay to allow SerialPlot to connect */
    vTaskDelay(pdMS_TO_TICKS(2000)); /* 2-second delay */

    for (;;)
    {
        /* Receive data from the queue */
        if (xQueueReceive(xSensorDataQueue, &data, portMAX_DELAY))
        {
            /* Convert raw data to lux for printing */
            float rawLux;
            sensorOpt3001Convert(data.rawData, &rawLux);

            /* Skip printing if both values are 0.00 */
            if (rawLux != 0.0f || data.filteredLux != 0.0f)
            {
                /* Print raw and filtered lux values in CSV format for SerialPlot */
                UARTprintf("%d.%02d,%d.%02d\n",
                           (int)rawLux, (int)(rawLux * 100) % 100,
                           (int)data.filteredLux, (int)(data.filteredLux * 100) % 100);
            }
        }
    }
}