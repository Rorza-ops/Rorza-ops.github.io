%%Code to test and compare path optimisation techniques


clear
clc
close all

Iterations = 100;

waypointsNumber = 10;

unoptimisedDistance = 0;

BFTime = 0;
BnBTime = 0;
NNTime = 0;

BFDistance = 0;
BnBDistance = 0;
NNDistance = 0;
count = 0;

for i = 1:Iterations
%Randomly generate starting point
startingPoint = [randi([-500 500], 1, 2), rand*2*pi];

%Will generate a set of waypoints with the starting position as the first
Waypoints = [startingPoint(1:2); randi([-500,500], waypointsNumber,2)];

%Waypoints = [  -302  -470; 0 387; -20 -472; 405 -10; 110 -332; 118 479; 360 213; 306 0; 77 -29; -317 -441; -260 182];


for j = 1:waypointsNumber
    unoptimisedDistance = unoptimisedDistance + norm(Waypoints(j,:) - Waypoints(j+1,:));
end
%{
tic
[BFPath, BFDist] = bruteForceOptimisation(Waypoints);
BFTime = BFTime + toc;
%}
tic
[BnBPath, BnBDist] = branchAndBoundOptimisation(Waypoints);
BnBTime = BnBTime + toc;

tic
[NNPath, NNDist] = nearestNeighbour(Waypoints);
NNTime = NNTime + toc;

%BFDistance = BFDistance + BFDist;
BnBDistance = BnBDistance + BnBDist;
NNDistance = NNDistance + NNDist;

if BnBPath == NNPath
    count = count+1;
end

fprintf('Iteration %.f complete\n', i);
end

correctness = (count/Iterations)*100;




% Display time results
fprintf('Unoptimised Distance: %.4fm\n\n', unoptimisedDistance/Iterations);

%disp('Brute Force')
%fprintf('   Time taken: %.4f seconds\n', BFTime/Iterations);
%fprintf('   Distance Achieved: %.4fm\n', BFDistance/Iterations);

disp('Branch and Bound')
fprintf('   Time taken: %.4f seconds\n', BnBTime/Iterations);
fprintf('   Distance Achieved: %.4fm\n', BnBDistance/Iterations);

disp('Nearest Neighbour')
fprintf('   Time taken: %.4f seconds\n', NNTime/Iterations);
fprintf('   Distance Achieved: %.4fm\n', NNDistance/Iterations);




%{
distance = 0;
for i =1:10

    distance = distance+norm(NNPath(i,:)-NNPath(i+1,:));
end
distance
%}
