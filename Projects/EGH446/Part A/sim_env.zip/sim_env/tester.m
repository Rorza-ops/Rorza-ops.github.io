%A = rand(6,6);
%myFunction('window', A, 3, 4)

%B = [1 2 3; 4 5 6; 7 0 9];
%myFunction('minval', B)

OG = zeros(100,100); OG(50:60,50:60) = 1;
imshow(OG)
OG = myFunction('inflate', OG);

DT = myFunction('distanceTransform', OG, [3 2]);

PATH = myFunction('robotPath', DT, [99 99]);
figure
imshow(DT/max(DT, [], "all"))
hold on
plot(PATH(:,1), PATH(:,2))