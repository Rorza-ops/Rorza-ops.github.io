speedLimits = [2.5, 5];


velocity = 2.5 + (speedLimits(2) - speedLimits(1))*min(max((1-abs(70-30)/1000), 0), 1);