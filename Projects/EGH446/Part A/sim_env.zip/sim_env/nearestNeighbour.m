function [Waypoints, totalDistance] = nearestNeighbour(waypoints)

    Waypoints = [waypoints(1,:); zeros(size(waypoints,1)-1,2)];

    waypoints(1,:) = [];
    totalDistance = 0;

    for i = 2:size(Waypoints,1)
        bestDistance = inf;
        for j = 1:size(waypoints,1)
            Distance = sqrt((waypoints(j, 1) - Waypoints(i-1, 1))^2 + (waypoints(j, 2) - Waypoints(i-1, 2))^2);
            if Distance < bestDistance
                bestDistance = Distance;
                Idx = j;
            end
        end
        totalDistance = totalDistance + bestDistance;
        Waypoints(i,:) = waypoints(Idx,:);
        waypoints(Idx,:) = [];
    end

end
