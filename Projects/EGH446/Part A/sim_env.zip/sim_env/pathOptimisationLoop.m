%%Code to test and compare path optimisation techniques


clear
clc
close all

waypointsNumber = 10;

%Randomly generate starting point
startingPoint = [randi([-500 500], 1, 2), rand*2*pi];

%Will generate a set of waypoints with the starting position as the first
Waypoints = [startingPoint(1:2); randi([-500,500],waypointsNumber,2)];
%Waypoints = load('idk.mat');
%Waypoints = Waypoints.Waypoints;
%Waypoints = [  -302  -470; 0 387; -20 -472; 405 -10; 110 -332; 118 479; 360 213; 306 0; 77 -29; -317 -441; -260 182];
%for i = 1:1000
tic
[BnBPath, BnBDistance] = branchAndBoundOptimisation(Waypoints);
BnBTime = toc;

tic
[BFPath, BFDistance] = nearestNeighbour(Waypoints);
%[BFPath, BFDistance] = bruteForceOptimisation(Waypoints);
BFTime = toc;
%{
tic
AlePath = BF_Optimiser(Waypoints);
AleTime = toc;

tic
[BF2Path, BF2Distance] = bruteForceOptimisation2(Waypoints);
BF2Time = toc;
%}
%{
if BnBPath ~= BFPath
    disp('Incorrect solution')
    break;
else
    fprintf('Iteration %d: Correct solution found\n', i)
    
end
%}
%}
%end
plotRoute(BnBPath, 'Branch and Bound')
plotRoute(BFPath, 'Brute Force')
%plotRoute(AlePath, 'Brute Force')
% Display time results
fprintf('Time taken for Branch and Bound: %.4f seconds\n', BnBTime);
fprintf('Time taken for Brute Force: %.4f seconds\n', BFTime);
%fprintf('Time taken for Ale: %.4f seconds\n', AleTime);
%fprintf('Time taken for Brute Force 2: %.4f seconds\n', BF2Time);
%{
time = toc;
yes = time/1000;
%yes = timesum/1000;
fprintf('Average time taken for Branch and Bound: %.4f seconds\n', yes);
%}