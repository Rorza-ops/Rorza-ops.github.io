% this wrapper function allows the assessment code to access your functions
function out = myFunction(op, varargin)
    switch op
        case 'window'
            out = window(varargin{:});
        case 'minval'
            out = minval(varargin{:});
        case 'inflate'
            out = inflate(varargin{:});
        case 'distanceTransform'
            out = distanceTransform(varargin{:});
        case 'robotPath'
            out = robotPath(varargin{:});
        otherwise
            fprintf('unknown function %s called\n', op);
    end
end
%----- YOUR CODE GOES BELOW HERE -----

function W = window(A, x, y) 
% Input:
%  A an arbitrary sized real matrix, at least 3x3.
%  x the x-coordinate (column index/horizontal) of the centre of the window.
%  y the y-coordinate (row index/vertical) of the centre of the window.
% Return:
%  W as 3x3 matrix which are the elements of A centered on the element (x,y).
%
% Should the window extend beyond the edges of the matrix the function must
% return an empty matrix [].
    
    if x < 2 || y < 2 || x > size(A,2)-1 || y > size(A,1)-1
        W = [];

    else
        W = A(y-1:y+1, x-1:x+1);
    end

end

function next = minval(M)
% Input:
%  M is a real 3x3 matrix
% Return:
%  next is a 1x2 matrix with elements [x, y] which are the column/horizontal and row/vertical coordinates relative to the centre
%       element, of the smallest element in the matrix.

    if all(isnan(M(:)))
        next = [];
    else

        ind = find(M' == min(M(:)), 1);

        [x,y] = ind2sub(size(M), ind);
        
        next = [x - 2, y - 2] ;
    end
end

function INF = inflate(OG) 
% Input:
%  OG an occupancy grid of arbitrary size
% Return:
% INF an inflated occupancy grid of same size as OG.
% of a 3x3 window of A centered at the corresponding element.  Elements of INF 
% that correspond to a window which "falls off the edge" of OG should be set to a value of 0.
    INF = zeros(size(OG));
    
    for x = 1:size(OG, 2)
        for y = 1:size(OG,1)
            sample = window(OG, x, y);
            if any(sample == 1, 'all')
                INF(y,x) = 1;
            end

        end
    end
end

function DT = distanceTransform(OG, GOAL) 
% Input:
%  OG is an occupancy grid of arbitrary size
%  GOAL is a 2-vector giving the goal in (column, row) coordinates.
% Return:
%   a matrix, the same size as OG, whose elements represent the distance of each cell from the goal 
%   computed using the Euclidean distance metric over a 3x3 window
    OG(OG == 1) = NaN;
    OG(OG == 0) = inf;
    OG(GOAL(2), GOAL(1)) = 0;

    Padded = NaN(size(OG, 1), size(OG, 2));
    Padded(2:size(OG, 1)-1, 2:size(OG, 2)-1) = OG(2:size(OG, 1)-1, 2:size(OG, 2)-1);

    distMatrix = [sqrt(2), 1, sqrt(2);...
                     1,    0,    1   ;...
                  sqrt(2), 1, sqrt(2)];

    frontier = 1;

    Left = max(GOAL(1)-frontier, 1);
    Right = min(GOAL(1)+frontier, size(OG,2));
    Up = max(GOAL(2)-frontier, 1);
    Down = min(GOAL(2)+frontier, size(OG,1));

    Mask = false(size(Padded));
    Mask(Up:Down, Left:Right) = true;
    [y,x] = find(Padded.*Mask == inf);

    wavefront = [y,x];

    for i = 1:size(wavefront,1)

        W = window(Padded, wavefront(i,2), wavefront(i,1));
        Padded(wavefront(i,1), wavefront(i,2)) = min(W + distMatrix, [], 'all');

    end     

    while ~isempty(wavefront)

        [~, idx] = sort(Padded(sub2ind(size(Padded), wavefront(:,1), wavefront(:,2))));
        current = wavefront(idx(1),:);
        wavefront(idx(1),:) = [];

        neighbours = [current(1)+1, current(2); current(1)-1, current(2); current(1), current(2)+1; current(1), current(2)-1];

        for i = 1:size(neighbours,1)
            if Padded(neighbours(i,1), neighbours(i,2)) == inf
                wavefront(end+1,:) = neighbours(i,:);

                W = window(Padded, neighbours(i,2), neighbours(i,1));

                Padded(neighbours(i,1), neighbours(i,2)) = min(W + distMatrix, [], 'all');
              
            end
        end
        
        wavefront = unique(wavefront, 'rows', 'stable'); 
    end

    DT = Padded;
end

function PATH = robotPath(DT, START) 
% Input:
%  DT a distance tranform matrix whose elements represent the distance of each cell from the goal
%    using some distance metric, or NaN if the cell is an obstacle.
%  START is a 2-vector giving the start in coordinate of the agent in (column,row) form. 
% Return:
%   PATH is an Nx2 matrix containing coordinates of the robot's path in (column,row) format.  The first row of PATH is the START coordinate and the last row is 
%    the GOAL coordinate.

    PATH = START;

    Padded = NaN(size(DT, 1)+2, size(DT, 2)+2);
    Padded(2:size(DT, 1)+1, 2:size(DT, 2)+1) = DT;

    while DT(PATH(end, 2), PATH(end, 1)) ~= 0
  
        W = window(Padded, PATH(end, 1)+1, PATH(end, 2)+1);
        Action = minval(W);

        PATH(end+1, :) = PATH(end, :) + Action;

    end
end