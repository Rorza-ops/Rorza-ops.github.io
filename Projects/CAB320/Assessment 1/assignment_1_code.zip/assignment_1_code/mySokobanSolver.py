
'''

    Sokoban assignment


The functions and classes defined in this module will be called by a marker script. 
You should complete the functions and classes according to their specified interfaces.

No partial marks will be awarded for functions that do not meet the specifications
of the interfaces.

You are NOT allowed to change the defined interfaces.
In other words, you must fully adhere to the specifications of the 
functions, their arguments and returned values.
Changing the interfacce of a function will likely result in a fail 
for the test of your code. This is not negotiable! 

You have to make sure that your code works with the files provided 
(search.py and sokoban.py) as your code will be tested 
with the original copies of these files. 

Last modified by 2022-03-27  by f.maire@qut.edu.au
- clarifiy some comments, rename some functions
  (and hopefully didn't introduce any bug!)

'''

# You have to make sure that your code works with 
# the files provided (search.py and sokoban.py) as your code will be tested 
# with these files
import search 
import time




# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -


def my_team():
    '''
    Return the list of the team members of this assignment submission as a list
    of triplet of the form (student_number, first_name, last_name)
    
    '''
    return [ (11038837, 'Kes', 'McLennan'),(10773398, 'Rory', 'Blair'),(10869069, 'Riley', 'Pederson') ]
    

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

#Yippee - Please dont deduct marks for the Yippee#


def taboo_cells(warehouse):
    '''  
    Identify the taboo cells of a warehouse. A "taboo cell" is by definition
    a cell inside a warehouse such that whenever a box get pushed on such 
    a cell then the puzzle becomes unsolvable. 
    
    Cells outside the warehouse are not taboo. It is a fail to tag an 
    outside cell as taboo.
    
    When determining the taboo cells, you must ignore all the existing boxes, 
    only consider the walls and the target  cells.  
    Use only the following rules to determine the taboo cells;
     Rule 1: if a cell is a corner and not a target, then it is a taboo cell.
     Rule 2: all the cells between two corners along a wall are taboo if none of 
             these cells is a target.
    
    @param warehouse: 
        a Warehouse object with the worker inside the warehouse

    @return
       A string representing the warehouse with only the wall cells marked with 
       a '#' and the taboo cells marked with a 'X'.  
       The returned string should NOT have marks for the worker, the targets,
       and the boxes.  
    '''
    ## Get Warehouse in readable condition ##
    warehouse_text = str(warehouse) # Conversion to String
    warehouse_array = [list(text.replace('$', ' ').replace('@', ' ')) for text in warehouse_text.split('\n')] # Convert to Nested List and replace entities

    yrange = len(warehouse_array) # Column Range
    xrange = len(warehouse_array[0]) # Row Range

    ## Rule 1 ##
    inside = False # All coordinates are considered to be not inside as none are proven to be so
    for y in range(yrange):
        for x in range(xrange):
            if not inside and warehouse_array[y][x] == '#': inside = True # Start of the checking process
            if inside:
                if all(empty.isspace() for empty in warehouse_array[y][x:]): break # breaks out of the for loop when continuous whitespace in detected
                if  warehouse_array[y][x] not in ['.','!','*','#']: # checks if any of these symbols appear in the nested list
                    # Identify corner Process
                    updown = False; leftright = False # everywhere are the given position is considered false as it has not be proven to be so
                    if warehouse_array[y-1][x] == '#' or warehouse_array[y+1][x] == '#': updown = True # Checks up and Down
                    if warehouse_array[y][x-1] == '#' or warehouse_array[y][x+1] == '#': leftright = True # Checks left and right
                    if updown == True and leftright == True: warehouse_array[y][x] = 'X' # If two statements above are true, it is are corner
                    
    ## Rule 2 ##
    for y in range(1, yrange):
        for x in range(1, xrange):
            if warehouse_array[y][x] == 'X': # Find existing corners
                for x2 in range(x+1, xrange):
                    if warehouse_array[y][x2] in ['.','*','!','#','X']:break # Check if any of the symbols in list appear in current position
                    # Identify Corner Process (checking with different x values.)
                    updown = False; leftright = False
                    if warehouse_array[y-1][x2] == '#' or warehouse_array[y+1][x2] == '#': updown = True
                    if warehouse_array[y][x2-1] == '#' or warehouse_array[y][x2+1] == '#': leftright = True
                    if updown == True and leftright == True: warehouse_array[y][x2] = 'X'
                for y2 in range(y+1, yrange):
                    if warehouse_array[y2][x] in ['.','*','!','#','X']:break
                    # Identify Corner Process (checking with different y values.)
                    updown = False; leftright = False
                    if warehouse_array[y2-1][x] == '#' or warehouse_array[y2+1][x] == '#': updown = True
                    if warehouse_array[y2][x-1] == '#' or warehouse_array[y2][x+1] == '#': leftright = True
                    if updown == True and leftright == True: warehouse_array[y2][x] = 'X'
                    
    ## Convert to Original Format ##
    warehouse_textfinal = '\n'.join(map(''.join, warehouse_array)) #Conversion to String

    for char in ['.', '!', '*']: # Remove other unimportant characters
        warehouse_textfinal = warehouse_textfinal.replace(char, ' ')

    return warehouse_textfinal

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

def coords_of_value(matrix, val):
    """
    Finds the coordinates of a value in a matrix / list of tuple

    @param warehouse: 
        a matrix to search 
    @param warehouse: 
        a value to match

    @return
       A list of tuples row and column coordinates where the given value occurs
    """
    return [(i, j) for i, row in enumerate(matrix) for j, cell in enumerate(row) if cell == val] # Iterates over list to process cells that match the given value

def warehouse_array(warehouse):
    """
    Converts the Warehouse object to a list of array 

    @param warehouse: 
        a Warehouse object with the worker inside the warehouse

    @return
       A list of lists that represents a warehouse as a 2D Array
    """
    return [list(row) for row in str(warehouse).split('\n')] # Creates a Nested List where the inner list represents the rows

def manhattan_distance_p2p(point1, point2):
    """
    Calculates the manhattan distance from one point to another

    @param warehouse: 
        two different points represented as tuples(x,y) on the puzzle 

    @return
       An integere representing the Manhattan distance between two points
    """
    return abs(point1[0] - point2[0]) + abs(point1[1] - point2[1]) # Manhattan Distance Formula

class SokobanPuzzle(search.Problem):
    '''
    An instance of the class 'SokobanPuzzle' represents a Sokoban puzzle.
    An instance contains information about the walls, the targets, the boxes
    and the worker.

    Your implementation should be fully compatible with the search functions of 
    the provided module 'search.py'. 
    
    '''
    
    #
    #         "INSERT YOUR CODE HERE"
    #
    #     Revisit the sliding puzzle and the pancake puzzle for inspiration!
    #
    #     Note that you will need to add several functions to 
    #     complete this class. For example, a 'result' method is needed
    #     to satisfy the interface of 'search.Problem'.
    #
    #     You are allowed (and encouraged) to use auxiliary functions and classes
    def __init__(self, warehouse):
        self.warehouse = warehouse # Stores Warehouse entities and layout
        current_setup = (tuple(warehouse.worker), tuple(warehouse.boxes)) # Tuple that contains worker and boxes postions
        # Inital state of the Puzzle
        self.initial = current_setup
        self.state = current_setup
        self.goal = (tuple(warehouse.worker), tuple(warehouse.targets)) # Final Goal State to Achieve

    def goal_test(self, state):
        """
        Check if all boxes are placed on the target positions.

        @param warehouse: 
            self (instance of SokobanPuzzle)
        @param warehouse: 
            state (Current state)

        @return
            True if equal, else False
        """
        return set(state[1]) == set(self.goal[1])

    def path_cost(self, accumulated_cost, prev_state, action, next_state):
        """
        Calculates the cost of moving from one state to another via an action,
        including weights for boxes if they are moved.

        @param warehouse: 
            accumulated_cost (cost from initial to current state)
        @param warehouse: 
            prev_state (previous state before action)
        @param warehouse: 
            action (movement to transition between previous and next state) 
        @param warehouse: 
            next_state (result after action is applied to the previous state.) 

        @return
            An integer that represents the move_cost added with the accumulated_cost
        """
        move_cost = 1 # Initial cost to move
        if prev_state[1] != next_state[1]: # Check if box has moved
            moved_box = None # Set to None as it is an unknown
            for box in prev_state[1]: # Goes through all positions of the boxes from the previous state
                if box not in next_state[1]: # Checks if the box has moved
                    moved_box = box # Gives value to 'moved_box'
                    break
            if moved_box: # Checks value
                box_idx = prev_state[1].index(moved_box) # Get postion
                move_cost += self.warehouse.weights[box_idx] # Adds weight to move cost
        return accumulated_cost + move_cost # Returns total

    def actions(self, state):
        """
        Determines possible actions for the worker based on the current state,
        avoiding walls, other boxes, and taboo cells.

        @param warehouse: 
            self (instance of SokobanPuzzle)
        @param warehouse: 
            state (Current state)

        @return
            A list that contains the possible moves that can be made
        """
        possible_moves = []
        worker_position = state[0]
        move_directions = {'Up': (0, -1), 'Down': (0, 1), 'Left': (-1, 0), 'Right': (1, 0)} # Defines values and their coordinates
        forbidden_places = set(coords_of_value(warehouse_array(self.warehouse), 'X')) # Identifies Taboo cells
        
        for direction, (dx, dy) in move_directions.items(): # Iterate of 'move_directions'
            new_position = (worker_position[0] + dx, worker_position[1] + dy) # New Position after movement
            further_position = (new_position[0] + dx, new_position[1] + dy) # Checks ahead of 'new_positon'
            if new_position in state[1]: # Checks for boxes
                if further_position not in self.warehouse.walls and further_position not in state[1] and further_position not in forbidden_places: # Checks further ahead for walls, boxes or taboo cells
                    possible_moves.append(direction) # Move
            elif new_position not in self.warehouse.walls and new_position not in forbidden_places: # Check if new positioning is a wall or taboo cell
                possible_moves.append(direction) # Move
        return possible_moves # Returns list

    def result(self, state, action):
        """
        Computes the new state resulting from applying an action to the current state.

        @param warehouse: 
            self (instance of SokobanPuzzle)
        @param warehouse: 
            state (Current state)
        @param warehouse: 
            action (movement to be applied)

        @return
            A Tuple which contains the new worker positions and A Tuple containing the new box positions
        """
        direction_offsets = {'Up': (0, -1), 'Down': (0, 1), 'Left': (-1, 0), 'Right': (1, 0)} # Define directions and coordinates
        worker_loc = list(state[0]) # Get Worker position as a list
        box_positions = list(map(list, state[1])) # Get boxes positions as a nested list

        dx, dy = direction_offsets[action] # Retrieve the change coordinates based on movement
        worker_loc[0] += dx # Update horizontal position corresponding to movement
        worker_loc[1] += dy # Update vertical position corresponding to movement
        for i, box in enumerate(box_positions): # Iterates over position of boxes
            if tuple(worker_loc) == tuple(box): # Check if worker is on top of a box
                # Update box coordinates
                box_positions[i][0] += dx
                box_positions[i][1] += dy
                break
        return (tuple(worker_loc), tuple(map(tuple, box_positions))) # Returns updated tuples of the workers and boxes positions

    def h(self, node):
        """
        Heuristic function that uses the Manhattan distance to estimate the cost from 
        the current state to the goal, incorporating box weights.

        @param warehouse: 
            self (instance of SokobanPuzzle) 
        @param warehouse: 
            node (represent node in graph search)

        @return
            An integer that represent the final estiamted cost
        """
        estimated_cost = 0 # Initalises cost as zero
        boxes = node.state[1] # Extract boxes from node state
        target_spots = self.warehouse.targets # Extract target positions from warehouse object
        box_weights = self.warehouse.weights # Extract the weight of each box from warehouse object

        for box in boxes: # Iterates over boes lsit
            closest_target_distance = min(manhattan_distance_p2p(box, target) for target in target_spots) # Calculate Manhattan Distance from closest target position to current box
            box_index = boxes.index(box) # Used to acquire weight factor based on the box
            weight_factor = box_weights[box_index] if box_weights else 1 # calculates the weight factor
            estimated_cost += (weight_factor * closest_target_distance) + manhattan_distance_p2p(node.state[0], box) # Calculates estimate cost every iteration.

        return estimated_cost # Returns final estimate cost

    
    

# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
def check_elem_action_seq(warehouse, action_seq):
    '''
    
    Determine if the sequence of actions listed in 'action_seq' is legal or not.
    
    Important notes:
      - a legal sequence of actions does not necessarily solve the puzzle.
      - an action is legal even if it pushes a box onto a taboo cell.
        
    @param warehouse: a valid Warehouse object

    @param action_seq: a sequence of legal actions.
           For example, ['Left', 'Down', Down','Right', 'Up', 'Down']
           
    @return
        The string 'Impossible', if one of the action was not valid.
           For example, if the agent tries to push two boxes at the same time,
                        or push a box into a wall.
        Otherwise, if all actions were successful, return                 
               A string representing the state of the puzzle after applying
               the sequence of actions.  This must be the same string as the
               string returned by the method  Warehouse.__str__()
    '''


    sokoban = SokobanPuzzle(warehouse) # Creates sokoban, a SokobanPuzzle object

    current_state = sokoban.state # Initialise state of the object

    for action in action_seq: # Iterate over action_seq
        if action not in sokoban.actions(current_state): # Checks if given action is legal
            return 'Impossible'
        current_state = sokoban.result(current_state, action) # Updates the current_state
    warehouse.boxes = current_state[1] # Update boxes postions
    warehouse.worker = current_state[0] # Update Worker postions

    return str(warehouse) # Return warehouse in string format

    
    


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -

def cost_to_move(warehouse, path):
    """
    Cost Calculation

    @param warehouse: 
        warehouse ()
    @param warehouse: 
        path (list of states that correspond to a path)

    @return
        An integer that represent the moving cost along the given path with weighted boxes included
    """
    cost = len(path) - 1  # Initialise base cost of 1

    if warehouse.weights: # Check if warehouse weighted boxes
        for i in range(len(path) - 1): # Iterate of states in path minus one
            current_state_boxes = path[i].state[1] # Retrieve boxes position from current state
            next_state_boxes = path[i + 1].state[1] # Retrieve boxes position from next state
            if current_state_boxes != next_state_boxes: # Check for box movement
                missing_box = None # Initialises missing_box as none as it is an unknown
                # Find the box that is in the current state but not in the next state
                for box in current_state_boxes:
                    if box not in next_state_boxes:
                        missing_box = box # Give value to missing_box
                        break
                
                if missing_box: # Check if missing_box has a value assigned
                    missing_box_index = current_state_boxes.index(missing_box) # Get position of missing box
                    missing_box_weight = warehouse.weights[missing_box_index] # Get weight of missing box
                    cost += missing_box_weight # Calulate cost for the specific iteration.

    return cost # Returns cost after loop has concluded

def solve_weighted_sokoban(warehouse):
    '''
    This function analyses the given warehouse.
    It returns the two items. The first item is an action sequence solution. 
    The second item is the total cost of this action sequence.
    
    @param 
     warehouse: a valid Warehouse object

    @return
    
        If puzzle cannot be solved 
            return 'Impossible', None
        
        If a solution was found, 
            return S, C 
            where S is a list of actions that solves
            the given puzzle coded with 'Left', 'Right', 'Up', 'Down'
            For example, ['Left', 'Down', Down','Right', 'Up', 'Down']
            If the puzzle is already in a goal state, simply return []
            C is the total cost of the action sequence C

    '''
    sokobanpuzzle = SokobanPuzzle(warehouse) # Create SokobanPuzzle object
    start_time = time.time()
    solution_node = search.astar_graph_search(sokobanpuzzle,sokobanpuzzle.h) # Run 'A Star Search Algorithm' to find a solution
    # solution_node = search.best_first_graph_search(sokobanpuzzle,sokobanpuzzle.h) # Run 'A Star Search Algorithm' to find a solution

    elapsed_time = time.time() - start_time # Time taken to compute

    # Print Results
    print("Solver took {:.6f} seconds".format(elapsed_time))
    if solution_node is None:
        return "Impossible", None 
    return solution_node.solution(), cost_to_move(warehouse, solution_node.path())


# - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
