import React from "react";
import { Button } from "reactstrap";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import Container from 'react-bootstrap/Container';
import Row from 'react-bootstrap/Row';
import Col from 'react-bootstrap/Col';
import "./styles.css"

export default function SingleMovie() {
    const navigate = useNavigate();
    const [rowData, setRowData] = useState([]);
    const [searchParams] = useSearchParams();
    const ID = searchParams.get("title");
    const [Movie, setMovie] = useState();
    const columns = [
        { headerName: "Role", field: "category" },
        { headerName: "Name", field: "name" },
        { headerName: "Characters", field: "characters" }
    ];
    useEffect(() => {
        const createDataSourceSingleMovie = async () => {
            const url = `http://sefdb02.qut.edu.au:3000/movies/data/${ID}`
            const response = await fetch(url);
            const json = await response.json();
            console.log(json);
            setMovie(json);
            setRowData(json.principals);
            return {
                category: json.principals.category,
                name: json.principals.name,
                characters: json.principals.characters
            }
        };
        createDataSourceSingleMovie();
    }, [ID])

    if (!Movie) {
        return <p> loading </p>
    }
    const subtitle = {
        padding: "0px 0px 0px 0px",
        margin: "0px 0px 0px 0px"
    }
    const subtitle2 = {
        padding: "0px 0px 0px 0px",
        margin: "110px 0px 0px 0px"
    }
    const detailbackground = {
        backgroundColor: "rgb(200, 200, 200)",
        padding: "10px 10px 10px 10px",
        margin: "110px 0px 10px 0px",
        border: "groove",
        width: "600px"
    }
    const detailbackgroundr = {
        backgroundColor: "rgb(200, 200, 200)",
        padding: "10px 10px 10px 10px",
        margin: "0px 0px 0px 0px",
        border: "groove",
        width: "370px"
    }
    const GENRES = {
        padding: "0px 0px 0px 0px",
        margin: "0px 0px 0px 0px",
    }
    return (
        <div className="App">
            <Container fluid>
                <Row>
                    <Col xs={3}>
                        <h1 style={{ paddingBottom: "20px" }}>
                            {Movie.title}
                        </h1>
                        <img src={Movie.poster} className="App-logo" alt="Movie Poster" />
                        <div style={detailbackgroundr}>
                            <h4>{Movie.ratings[0].source}: {Movie.ratings[0].value}</h4>
                            <h4>{Movie.ratings[1].source}: {Movie.ratings[1].value}</h4>
                            <h4>{Movie.ratings[2].source}: {Movie.ratings[2].value}</h4>
                        </div>
                        <Button
                            color="info"
                            size="sm"
                            className="mt-3"
                            onClick={() => navigate("/movies")}>
                            Back to Movies
                        </Button>
                    </Col>
                    <Col style={detailbackground}>
                        <h4 style={subtitle}>Year: {Movie.year}</h4>
                        <h4 style={subtitle}>Runtime: {Movie.runtime} Minutes</h4>
                        <h4 style={subtitle}>Country: {Movie.country}</h4>
                        <h4 style={subtitle}>Box Office: ${Movie.boxoffice}</h4>
                        <h4 style={subtitle}>Genres:</h4>
                        {Movie.genres.map(genre => {
                            return <p style={subtitle}>{genre}</p>
                        })}
                        <h4 style={GENRES}>Plot: </h4> <p style={subtitle}>{Movie.plot}</p>
                    </Col>
                    <Col>
                        <h4 style={subtitle2}>Crew Members Table: </h4>
                        <div
                            className="ag-theme-balham"
                            style={{
                                height: "325px",
                                width: "600px",
                                margin: "0px 0px 0px 0px"
                            }}
                        >
                            <AgGridReact
                                columnDefs={columns}
                                rowData={rowData}
                                pagination={true}
                                paginationAutoPageSize={7}
                                onRowClicked={(row) => navigate(`/people?title=${row.data.id}`)}
                            />
                        </div>
                    </Col>
                </Row>
            </Container>
        </div>
    );
}
