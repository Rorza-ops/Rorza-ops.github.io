// the footer
export default function Footer() {
    return (
        <footer style={{ padding: "0px 0px 30px 0px" }}>
            <span>
                All data is from IMDB, Metacritic and RottenTomatoes.
                <br />
                &copy; 2023 Rory Blair{" "}
            </span>
        </footer>
    );
}
