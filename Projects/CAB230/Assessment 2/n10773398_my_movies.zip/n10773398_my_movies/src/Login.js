import { useState } from "react";
import { useNavigate } from "react-router-dom";
export default function Loggin() {
    const navigate = useNavigate();
    const [innerEmail, setInnerEmail] = useState("");
    const [innerPassword, setInnerPassword] = useState("");
    const login = () => {
        const url = `http://sefdb02.qut.edu.au:3000/user/login`;

        return fetch(url, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({ email: "mike@gmail.com", password: "password" }),
        })
            .then((res) =>
                res.json().then((res) => {
                    localStorage.setItem("token", res.bearerToken.token);
                    console.log(res);
                })
            )
            .catch((error) => console.log(error));
    };

    const handlesubmit = async () => {
        if (!login()) {
            <p> loading </p>
        }
        else {
            login();
            navigate("/")
        }
    }

    return (
        <div>
            <h1>Login</h1>
            <h3 style={{ padding: "0px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Email: </h3>
            <input
                aria-labelledby="search-button"
                name="search"
                id="search1"
                type="search"
                value={innerEmail}
                onChange={(e) => setInnerEmail(e.target.value)}
            />
            <h3 style={{ padding: "15px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Password: </h3>
            <input
                aria-labelledby="search-button"
                name="search"
                id="search1"
                type="search"
                value={innerPassword}
                onChange={(e) => setInnerPassword(e.target.value)}
                style={{ margin: "0px 0px 20px 0px" }}
            />
            <br></br>
            <button
                id="search-button"
                type="button"
                onClick={handlesubmit}
                style={{ padding: "2px 2px 2px 2px", margin: "0px 0px 20px 0px" }}
            >
                Login
            </button>
        </div>
    );
}