import "./styles.css";
import "ag-grid-community/styles//ag-grid.css";
import "ag-grid-community/styles//ag-theme-alpine.css";
import { useMemo, useState } from "react";
import { AgGridReact } from "ag-grid-react";
import { useNavigate } from "react-router-dom";
import { Container, Row, Col } from "react-bootstrap";

const paginationPageSize = 100;

export default function AppMovie() {
    const [gridApi, setGridApi] = useState(null);
    const [innerSearch, setInnerSearch] = useState("");
    const [innerSearch2, setInnerSearch2] = useState("");
    const navigate = useNavigate();
    const createDataSource = async () => {
        const dataSource = {
            getRows: (params) => {
                let pageNo = params.endRow / paginationPageSize;
                let url = `http://sefdb02.qut.edu.au:3000/movies/search?page=${pageNo}`;
                if (innerSearch) {
                    url += `&title=${innerSearch}`;
                }
                if (innerSearch2) {
                    url += `&year=${innerSearch2}`;
                }
                console.log(params);
                console.log("pageNo", pageNo);
                console.log("url", url);
                fetch(url)
                    .then((response) => response.json())
                    .then((response) => {
                        console.log(response);
                        params.successCallback(response.data, response.pagination.total);
                    });
            }
        };
        return dataSource;
    };

    const onGridReady = async (params) => {
        setGridApi(params.api);
        const dataSource = await createDataSource();
        params.api.setDatasource(dataSource);
    };

    const handlesubmit = async () => {
        console.log(innerSearch);
        console.log(innerSearch2);
        const dataSource = await createDataSource();
        gridApi.setDatasource(dataSource);
    }

    const defaultColDef = useMemo(() => {
        return {
            editable: false,
            enableRowGroup: false,
            enablePivot: false,
            enableValue: true,
            sortable: false,
            resizable: true,
            filter: false,
            flex: 1,
            minwidth: 200
        };
    }, []);

    const columnDefs = useMemo(() => {
        return [
            { headerName: "Title", field: "title" },
            { headerName: "Year", field: "year" },
            { headerName: "IMDB Rating", field: "imdbRating" },
            { headerName: "Rotten Tomatoes", field: "rottenTomatoesRating" },
            { headerName: "Metacritics", field: "metacriticRating" },
            { headerName: "Rated", field: "classification" }
        ];
    }, []);

    const gridOptions = {
        columnDefs: columnDefs,
        defaultColDef: defaultColDef,
        rowModelType: "infinite",
        paginationPageSize: paginationPageSize,
        pagination: true,
        onGridReady: onGridReady,
        cacheBlockSize: paginationPageSize,
        suppressBrowserResizeObserver: true
    };

    return (
        <div className="App">
            <div className="ag-theme-alpine" style={{
                height: "70vh",
                width: "100%"
            }}>
                <div style={{ padding: "0px 0px 0px 0px", margin: "0px 0px 0px 0px" }}>
                    <Container>
                        <Row>
                            <Col sm={3}>
                                <h3 style={{ padding: "15px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Title: </h3>
                                <input
                                    aria-labelledby="search-button"
                                    name="search"
                                    id="search1"
                                    type="search"
                                    value={innerSearch}
                                    onChange={(e) => setInnerSearch(e.target.value)}
                                />
                            </Col>
                            <Col sm={3}>
                                <h3 style={{ padding: "15px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Year: </h3>
                                <input
                                    aria-labelledby="search-button"
                                    name="search"
                                    id="search1"
                                    type="search"
                                    value={innerSearch2}
                                    onChange={(e) => setInnerSearch2(e.target.value)}
                                    style={{ margin: "0px 0px 20px 0px" }}
                                />
                            </Col>
                        </Row>
                    </Container>
                    <br></br>
                    <button
                        id="search-button"
                        type="button"
                        onClick={handlesubmit}
                        style={{ padding: "10px 10px 10px 10px", margin: "0px 0px 20px 0px" }}
                    >
                        Search
                    </button>
                </div>
                <AgGridReact
                    onRowClicked={(row) => navigate(`/movie?title=${row.data.imdbID}`)} gridOptions={gridOptions}>
                </AgGridReact>
            </div>
        </div >
    );
}
