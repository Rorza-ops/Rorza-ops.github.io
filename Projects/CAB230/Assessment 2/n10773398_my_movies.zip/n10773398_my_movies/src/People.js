import React from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useState, useEffect } from "react";
import { AgGridReact } from "ag-grid-react";
import "./styles.css"

export default function Person() {
    const navigate = useNavigate();
    const [rowData, setRowData] = useState([]);
    const [searchParams] = useSearchParams();
    const ID = searchParams.get("title");
    const [Person, setPerson] = useState();
    const columns = [
        { headerName: "Movie Title", field: "movieName" },
        { headerName: "Role", field: "category" },
        { headerName: "Characters", field: "characters" },
        { headerName: "Rating", field: "imdbRating" }
    ];
    useEffect(() => {
        const createDataSourcePerson = async () => {
            const url = `http://sefdb02.qut.edu.au:3000/people/${ID}`
            const token = localStorage.getItem("token")
            const response = await fetch(url, {
                method: "GET", // *GET, POST, PUT, DELETE, etc.
                headers: {
                    "Content-Type": "application/json",
                    "Authorization": `Bearer ${token}`
                },
            });
            const json = await response.json();
            console.log(json);
            setPerson(json);
            setRowData(json.roles);
            if (json.deathYear == null && json.birthYear == null) {
                json.birthYear = "Unknown"
                json.deathYear = json.birthYear
            }
            if (json.deathYear == null) {
                json.deathYear = "Still Alive"
            }
            if (json.birthYear == null) {
                json.birthYear = "Unknown"
            }
            return {
                movieName: json.roles.movieName,
                category: json.roles.category,
                characters: json.roles.characters,
                imdbRating: json.roles.imdbRating
            }
        };
        createDataSourcePerson();
    }, [ID])

    if (!Person) {
        return <p> If Nothing Loads, please Login and try again</p>
    }
    const subtitle = {
        padding: "0px 0px 0px 0px",
        margin: "0px 0px 0px 0px"
    }
    const detailbackground = {
        backgroundColor: "rgb(200, 200, 200)",
        padding: "10px 10px 10px 10px",
        margin: "0px 0px 10px 0px",
        border: "groove",
        width: "400px"
    }
    return (
        <div className="App">
            <div>
                <h1 style={{ paddingBottom: "0px", margin: "20px 0px 0px 0px" }}> {Person.name} </h1>
            </div>
            <div style={detailbackground}>
                <h4 style={subtitle}>Year of Birth: {Person.birthYear}</h4>
                <h4 style={subtitle}>Year of Death: {Person.deathYear}</h4>
            </div>
            <div
                className="ag-theme-balham"
                style={{
                    height: "300px",
                    width: "800px"
                }}
            >
                <AgGridReact
                    columnDefs={columns}
                    rowData={rowData}
                    pagination={true}
                    paginationAutoPageSize={7}
                    onRowClicked={(row) => navigate(`/movie?title=${row.data.movieId}`)}
                />
            </div>
        </div>
    );
}
