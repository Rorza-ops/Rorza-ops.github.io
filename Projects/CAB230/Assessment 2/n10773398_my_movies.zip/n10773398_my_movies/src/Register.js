import { useState } from "react";
import { useNavigate } from "react-router-dom";
export default function Reggister() {
    const navigate = useNavigate();
    const [innerEmail, setInnerEmail] = useState("");
    const [innerPassword, setInnerPassword] = useState("");
    const [innerCPassword, setInnerCPassword] = useState("");
    const register = () => {
        const url = `http://sefdb02.qut.edu.au:3000/user/register`;
        if (innerCPassword === innerPassword) {
            return fetch(url, {
                method: "POST", // *GET, POST, PUT, DELETE, etc.
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ email: innerEmail, password: innerPassword }),
            })
                .then((res) =>
                    res.json().then((res) => {
                        console.log(res);
                    })
                )
                .catch((error) => console.log(error));
        }
    };

    const handlesubmit = async () => {
        if (!register()) {

        }
        else {
            register();
            navigate("/login")
        }
    }

    return (
        <div>
            <h1>Register</h1>
            <h3 style={{ padding: "0px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Email: </h3>
            <input
                aria-labelledby="search-button"
                name="search"
                id="search1"
                type="search"
                value={innerEmail}
                onChange={(e) => setInnerEmail(e.target.value)}
            />
            <h3 style={{ padding: "15px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Password: </h3>
            <input
                aria-labelledby="search-button"
                name="search"
                id="search1"
                type="search"
                value={innerPassword}
                onChange={(e) => setInnerPassword(e.target.value)}
            />
            <h3 style={{ padding: "15px 0px 0px 0px", margin: "0px 0px 0px 0px" }}> Confirm Password: </h3>
            <input
                aria-labelledby="search-button"
                name="search"
                id="search1"
                type="search"
                value={innerCPassword}
                onChange={(e) => setInnerCPassword(e.target.value)}
                style={{ margin: "0px 0px 20px 0px" }}
            />
            <br></br>
            <button
                id="search-button"
                type="button"
                onClick={handlesubmit}
                style={{ padding: "2px 2px 2px 2px", margin: "0px 0px 20px 0px" }}
            >
                Register
            </button>
        </div>
    );
}