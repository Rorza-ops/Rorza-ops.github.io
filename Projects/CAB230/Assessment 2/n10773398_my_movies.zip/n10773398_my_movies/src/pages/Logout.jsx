import React from "react";
import Loggout from "../Logout";
import "../styles.css";
const background = {
    backgroundImage: "linear-gradient(180deg, white, black)",
    padding: "0px 50px 50px 100px",
    minHeight: "450px",
    height: "600px",
    maxHeight: "1200px"
}
export default function Logout() {
    return (
        <div style={background}>
            <Loggout />
        </div>
    );
}
