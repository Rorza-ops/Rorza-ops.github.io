import React from "react";
import "../styles.css";
import Reggister from "../Register";
const background = {
    backgroundImage: "linear-gradient(180deg, white, black)",
    padding: "0px 50px 50px 100px",
    margin: "0px 0px 0px 0px",
    minHeight: "450px",
    height: "600px",
    maxHeight: "1200px"
}
export default function Register() {
    return (
        <div style={background}>
            <Reggister />
        </div>
    );
}
