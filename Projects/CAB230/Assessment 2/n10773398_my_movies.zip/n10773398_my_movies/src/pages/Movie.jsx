import "../styles.css";
import "ag-grid-community/styles//ag-grid.css";
import "ag-grid-community/styles//ag-theme-alpine.css";
import SingleMovie from "../Movie";

export default function Movie() {
    const background = {
        backgroundImage: "linear-gradient(180deg, white, black)",
        padding: "0px 50px 50px 50px",
        height: "1000px"
    }
    return (
        <main style={background}>
            <SingleMovie />
        </main>
    );
}