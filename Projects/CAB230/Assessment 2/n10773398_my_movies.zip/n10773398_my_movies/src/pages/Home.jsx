import React from "react";

export default function Home() {
    return (
        <main>
            <Hero />
            <Features />
        </main>
    );
}

// hero content
const Hero = () => (
    <section className="hero2">
        <section className="hero">
            {/* content for the hero */}
            <div className="hero__content">
                <h1 className="hero__title">Rory Blair's</h1>
                <p className="hero__subtitle">Fabulous Movie Searching Website</p>

                <a href="/movies">Movies</a>
            </div>
        </section>
    </section>
);

// features section
function Features() {
    /* The information for our features in JSON
    so we can reduce the amount of repetitive JSX and reuse one component instead */
    const featuresData = [
        {
            heading: "Browse Movies",
            text:
                "Be able to browse a selection of movies from the Internet Movie Database.",
            img: { src: "img/Picture1.png", alt: "Camera Icon" }
        },
        {
            heading: "View Movie Details",
            text:
                "Be able to view a particular movies details, such as runtime and the crew member, without a worry.",
            img: { src: "img/Picture2.png", alt: "Movie Reel Icon" }
        },
        {
            heading: "View a crew members profile",
            text:
                "Be able to see a particular person's profile, including there DOB and the movies they have been apart of",
            img: { src: "img/Picture3.png", alt: "Actor Icon" }
        }
    ];

    const style1 = {
        backgroundImage: "linear-gradient(180deg, rgb(248, 248, 248), black)",
        color: "white",
    }
    const style2 = {
        padding: "70px 0px 0px 0px",
    }
    const style3 = {
        padding: "0px 0px 0px 0px",
        margin: "0px 0px 0px 0px"
    }
    return (
        <article className="features" style={style1}>
            <article className="features">
                <div className="features__header" style={style2}>
                    <h2 style={style3}>Our Promise</h2>
                </div>
                <div className="features__box-wrapper">
                    {
                        // display the information for each of our features in their own Box
                        featuresData.map((feature) => (
                            <FeatureBox feature={feature} />
                        ))
                    }
                </div>
            </article>
        </article>
    );
}

// Display a Feature box when passed in the information for the feature
const FeatureBox = ({ feature }) => (
    <div className="features__box">
        <img src={feature.img.src} alt={feature.img.alt} />
        <h5>{feature.heading}</h5>
        <p>{feature.text}</p>
    </div>
);
