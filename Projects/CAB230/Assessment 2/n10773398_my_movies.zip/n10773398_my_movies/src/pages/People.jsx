import "../styles.css";
import "ag-grid-community/styles//ag-grid.css";
import "ag-grid-community/styles//ag-theme-alpine.css";
import Person from "../People";

export default function People() {
    const background = {
        backgroundImage: "linear-gradient(180deg, white, black)",
        padding: "0px 50px 50px 50px",
        height: "800px"
    }
    return (
        <main style={background}>
            <Person />
        </main>
    );
}