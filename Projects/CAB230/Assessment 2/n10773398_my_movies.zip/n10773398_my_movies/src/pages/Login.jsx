import React from "react";
import Loggin from "../Login";
import "../styles.css";
const background = {
    backgroundImage: "linear-gradient(180deg, white, black)",
    padding: "0px 50px 50px 100px",
    minHeight: "450px",
    height: "600px",
    maxHeight: "1200px"
}
export default function Login() {
    return (
        <div style={background}>
            <Loggin />
        </div>
    );
}
