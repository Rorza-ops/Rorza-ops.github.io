import "../styles.css";
import "ag-grid-community/styles//ag-grid.css";
import "ag-grid-community/styles//ag-theme-alpine.css";
import AppMovie from "../Movies";

const outside_table = {
    padding: "0px 0px 0px 50px"
}

export default function Movies() {
    const background = {
        backgroundImage: "linear-gradient(180deg, white, black)",
        padding: "0px 50px 50px 50px",
        height: "800px"
    }
    return (
        <main style={background}>
            <h1 style={outside_table}> Movies</h1>
            <AppMovie />
        </main>
    );
}