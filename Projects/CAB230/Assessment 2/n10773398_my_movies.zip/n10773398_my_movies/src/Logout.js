import { useNavigate } from "react-router-dom";
export default function Loggout() {
    const navigate = useNavigate();
    const logout = () => {
        const url = `http://sefdb02.qut.edu.au:3000/user/logout`;
        const token = localStorage.getItem("token")
        return fetch(url, {
            method: "POST", // *GET, POST, PUT, DELETE, etc.
            headers: {
                "Content-Type": "application/json",
                "Authorization": `Bearer ${token}`
            },
            body: JSON.stringify({ email: "", password: "" }),
        })

            .then((res) =>
                res.json().then((res) => {
                    localStorage.setItem("token", "");
                    console.log(res);
                })
            )
            .catch((error) => console.log(error));
    };

    const handlesubmit = async () => {
        if (!logout()) {
            <p> loading </p>
        }
        else {
            logout();
            navigate("/")
        }
    }

    return (
        <div>
            <h1>Logout</h1>

            <button
                id="search-button"
                type="button"
                onClick={handlesubmit}
                style={{ padding: "2px 2px 2px 2px", margin: "0px 0px 20px 0px" }}
            >
                Login
            </button>
        </div>
    );
}