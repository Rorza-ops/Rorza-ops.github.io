var express = require('express');
var router = express.Router();

router.get('/movies', function (req, res, next) {
    res.render('movies', { title: 'Lots of Movies available' });
});

router.get("/search", async function (req, res, next) {
    console.log('getting movies!')
    const { title, year, page } = req.query
    if (title && year && year.length != 4) {
        res.status(400).json({ "error": true, "message": "Invalid year format. Format must be yyyy." });
        return;
    }
    if (year && year.length != 4 && isNaN(year)) {
        res.status(400).json({ "error": true, "message": "Invalid year format. Format must be yyyy." });
        return;
    }
    if (page && isNaN(page)) {
        res.status(400).json({
            error: true,
            message: "Invalid page format. page must be a number.",
        });
        return;
    }
    let query = req.db
        .from('basics')
        .select(
            "primaryTitle AS title",
            "year",
            "tconst AS imdbID",
            "imdbRating",
            "rottenTomatoesRating",
            "metacriticRating",
            "rated AS classification")

    if (title && !year) {
        query
            .andWhere('primaryTitle', 'like', `%${title}%`)
    }
    if (year && !title) {
        query
            .andWhere('year', '=', year)
    }
    if (!title && !year) {
        query
    }
    if (title && year) {
        query
            .andWhere('year', '=', year)
            .andWhere('primaryTitle', 'like', `%${title}%`)
    }
    query.orderBy("tconst", "asc").paginate({
        perPage: 100,
        currentPage: page ? +page : 1,
        isLengthAware: true,
    }).then((rows) => {
        const movies =
            rows.data.map((row) => {
                return {
                    "title": row.title,
                    "year": row.year,
                    "imdbID": row.imdbID,
                    "imdbRating": parseFloat(row.imdbRating),
                    "rottenTomatoesRating": parseFloat(row.rottenTomatoesRating),
                    "metacriticRating": parseFloat(row.metacriticRating),
                    "classification": row.classification,
                };
            });
        res.json({ data: movies, pagination: rows.pagination });
    });
});

router.get("/data/:id", async function (req, res) {
    console.log('getting movie')
    const charactersParser = (str) => {
        if (str === "") {
            return [

            ];
        }
        const replaced = str.replaceAll(`["`, "").replaceAll(`"]`, "");
        const split = replaced.split('","');
        return split;
    };
    const MID = req.params.id;
    const queryMovies = req.db.from("basics").select("*").where('tconst', MID);
    queryMovies.then(movies => {
        if (movies.length < 1) {
            res.status(400).json();
            return;
        }
    })
    if (MID.length != 9) {
        res.status(404).json({ error: true, message: "Invalid query parameters: year. Query parameters are not permitted" });
        return;
    }
    let principals = await req.db
        .from('principals')
        .select("nconst AS id", "category", "name", "characters")
        .where('tconst', MID)
    principals = principals.map(row => {
        return {
            "id": row.id,
            "category": row.category,
            "name": row.name,
            "characters": charactersParser(row.characters)
        }
    })
    let ratings = await req.db
        .from('ratings')
        .select("source", 'value')
        .where('tconst', MID)
    ratings = ratings.map(row => {
        return {
            "source": row.source,
            "value": parseFloat(row.value)
        }
    })
    req.db
        .from('basics')
        .select("primaryTitle AS title",
            "year",
            "runtimeMinutes AS runtime",
            "genres",
            "country",
            "boxoffice",
            "poster",
            "plot")
        .where('tconst', MID)
        .then((rows) => {
            rows = rows.map(row => {
                return {
                    "title": row.title,
                    "year": row.year,
                    "runtime": row.runtime,
                    "genres": row.genres.split(","),
                    "country": row.country,
                    "principals": principals,
                    "ratings": ratings,
                    "boxoffice": row.boxoffice,
                    "poster": row.poster,
                    "plot": row.plot
                }
            })
            if (rows.length != 1 && rows.length === 0) {
                res.status(400).json();
            }
            else {
                res.json(rows[0])
            }
        })
});
module.exports = router;