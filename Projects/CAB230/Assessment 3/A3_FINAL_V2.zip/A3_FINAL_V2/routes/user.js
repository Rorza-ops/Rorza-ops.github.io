var express = require('express');
var router = express.Router();
const jwt = require('jsonwebtoken');
const bcrypt = require('bcrypt');
const authorization = require('../middleware/authorization');

router.get('/user', function (req, res, next) {
  res.render('user', { title: 'Lots of Movies available' });
});

router.post('/register', function (req, res, next) {
  const email = req.body.email;
  const password = req.body.password;
  if (!email || !password) {
    res.status(400).json({
      error: true,
      message: "Request body incomplete, both email and password are required"
    });
    return;
  }
  const queryUsers = req.db.from("users").select("*").where("email", "=", email);
  queryUsers.then(users => {
    if (users.length > 0) {
      res.status(409).json({
        "error": true,
        "message": "User already exists"
      });
    }
    const saltRounds = 10;
    const hash = bcrypt.hashSync(password, saltRounds);
    return req.db.from("users").insert({ email, hash });
  })
    .then(() => {
      res.status(201).json({ "message": "User created" });
    })
});


router.post('/login', function (req, res, next) {
  const { email, password, longExpiry, bearerExpiresInSeconds, refreshExpiresInSeconds } = req.body;
  if (!email || !password) {
    res.status(400).json({
      "error": true,
      "message": "Request body incomplete, both email and password are required"
    });
    return;
  }
  const queryUsers = req.db.from("users").select("*").where("email", "=", email);
  queryUsers
    .then(users => {
      if (users.length === 0) {
        res.status(401).json({
          "error": true,
          "message": "Incorrect email or password"
        });
        return;
      }
      console.log("User exists in table");
      const user = users[0];
      return bcrypt.compare(password, user.hash);
    })
    .then(match => {
      if (!match) {
        return res.status(401).json();
      }
      console.log("Passwords match");
      const bexp = Math.floor(Date.now() / 1000) + bearerExpiresInSeconds;
      const rexp = Math.floor(Date.now() / 1000) + refreshExpiresInSeconds;
      const btoken = jwt.sign({ email, bexp }, process.env.JWT_SECRET);
      const rtoken = jwt.sign({ email, rexp }, process.env.JWT_SECRET_REFRESH);
      res.status(200).json({
        "bearerToken": {
          "token": btoken,
          "token_type": "Bearer",
          "expires_in": 600
        },
        "refreshToken": {
          "token": rtoken,
          "token_type": "Refresh",
          "expires_in": 86400
        }
      });
    });
});


router.post('/refresh', function (req, res) {
  const refreshToken = req.body.refreshToken;
  if (!refreshToken) {
    res.status(400).json({
      error: true,
      message: "Request body incomplete, refresh token required"
    });
    return;
  }
  try {
    jwt.verify(refreshToken, process.env.JWT_SECRET_REFRESH);
  } catch (e) {
    if (e.name === "TokenExpiredError") {
      res.status(401).json(
        {
          error: true,
          message: "JWT token has expired"
        });
      return;
    }
    else {
      res.status(401).json(
        {
          error: true,
          message: "Invalid JWT token"
        });
      return;
    }
  }
  console.log("Passwords match");
  const bexp = Math.floor(Date.now() / 1000) + 600;
  const rexp = Math.floor(Date.now() / 1000) + 86400;
  const btoken = jwt.sign({ bexp }, process.env.JWT_SECRET);
  const rtoken = jwt.sign({ rexp }, process.env.JWT_SECRET_REFRESH);
  res.status(200).json({
    "bearerToken": {
      "token": btoken,
      "token_type": "Bearer",
      "expires_in": 600
    },
    "refreshToken": {
      "token": rtoken,
      "token_type": "Refresh",
      "expires_in": 86400
    }
  });
});


router.post('/logout', function (req, res, next) {
  const refreshToken = req.body.refreshToken;
  if (!refreshToken) {
    res.status(400).json({
      error: true,
      message: "Request body incomplete, refresh token required"
    });
    return;
  }
  try {
    jwt.verify(refreshToken, process.env.JWT_SECRET_REFRESH);
  } catch (e) {
    if (e.name === "TokenExpiredError") {
      res.status(401).json(
        {
          error: true,
          message: "JWT token has expired"
        });
      return;
    }
    else {
      res.status(401).json(
        {
          error: true,
          message: "Invalid JWT token"
        });
      return;
    }
  }
  console.log("Passwords match");
  const btoken = ''
  const rtoken = ''
  res.status(200).json({
    error: false,
    message: "Token successfully invalidated"
  });
  return;
});


router.get('/:email/profile', authorization, function (req, res) {
  if (!req.params.email) {

  }
  if (!("authorization" in req.headers)) {
    req.db.from('users')
      .select(
        "email",
        "firstName",
        "lastName")
      .where('email', '=', req.params.email)
      .then((rows) => {
        res.json(rows)
      })
  }
  else {
    req.db.from('users')
      .select(
        "email",
        "firstName",
        "lastName",
        "dob",
        "address")
      .where('email', '=', req.params.email)
      .then((rows) => {
        res.json(rows)
      })
      .catch((err) => {
        console.log(err);
        res.json({ "Error": true, "Message": "Error in MySQL query" })
      })
  }
}
);


router.put('/:email/profile', function (req, res, next) {
  const { email, firstName, lastName, dob, address } = req.body;
  const isISOString = val => {
    const d = new Date(val);
    return !Number.isNaN(d.valueOf()) && d.toISOString() === val;
  };
  const currDate = Date.now();
  const dt = new Date(currDate)
  console.log(dt.getFullYear())
  if (isISOString(dob)) {
    res.status(400).json({
      error: true,
      message: "Invalid input: dob must be a real date in format YYYY-MM-DD."
    });
    return;
  }
  if (dob > dt.getTime) {
    res.status(400).json({
      error: true,
      message: "Invalid input: dob must be a date in the past."
    });
    return;
  }
  if (typeof firstName !== 'string' || typeof lastName !== 'string' || typeof address !== 'string') {
    res.status(400).json({
      error: true,
      message: "Request body invalid: firstName, lastName and address must be strings only."
    });
    return;
  }
  if (!email || !firstName || !lastName || !dob || !address) {
    res.status(400).json({
      error: true,
      message: "Request body incomplete: firstName, lastName, dob and address are required."
    });
    return;
  }
  const queryUsers = req.db.from("users").select("*").where("email", "=", email);
  if (email != rows.email) {
    queryUsers
      .update({
        email: email,
        firstName: firstName,
        lastName: lastName,
        dob: dob,
        address: address
      })
      .then(rows => res.status(200).json(rows))
  }
});
module.exports = router;
