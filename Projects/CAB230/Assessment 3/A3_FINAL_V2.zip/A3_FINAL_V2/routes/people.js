var express = require('express');
var router = express.Router();
var knex = require('knex');
const authorization = require("../middleware/authorization");

router.get('/people', function (req, res, next) {
    res.render('people', { title: 'Lots of people available' });
});

router.get("/:id", authorization, async function (req, res) {
    console.log('getting people')
    const charactersParser = (str) => {
        if (str === "") { return []; }
        const replaced = str.replaceAll(`["`, "").replaceAll(`"]`, "");
        const split = replaced.split('","');
        return split;
    };
    const PID = req.params.id;
    if (PID.length != 9 && authorization) {
        res.status(404).json({
            "error": true,
            "message": "Invalid query parameters: year. Query parameters are not permitted"
        });
    }

    const query = req.db
        .from('names')
        .select("primaryName AS name",
            "birthYear",
            "deathYear");
    var lengthth = Object.keys(query).length;
    if (lengthth < 1) {
        res.status(400).json(
            {
                "error": true,
                "message": "received value must not be null nor undefined"
            });
        return;
    }
    let roles = await req.db
        .from('basics')
        .join('principals', 'basics.tconst', 'principals.tconst')
        .select('basics.primaryTitle AS movieName', 'basics.tconst AS movieId', 'principals.category', 'principals.characters', 'basics.imdbRating')
        .where('principals.nconst', PID)
    roles = roles.map(row => {
        return {
            "movieName": row.movieName,
            "movieId": row.movieId,
            "category": row.category,
            "characters": charactersParser(row.characters),
            "imdbRating": parseFloat(row.imdbRating)
        }
    });
    query.where('nconst', PID)
        .then((rows) => {
            rows = rows.map(row => {
                return {
                    "name": row.name,
                    "birthYear": row.birthYear,
                    "deathYear": row.deathYear,
                    roles
                }
            })
            res.json(rows[0]);
        })
});
module.exports = router;